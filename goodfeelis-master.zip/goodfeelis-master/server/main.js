const GRAPH_DATA_DAYS = 14;
const LES_THRESHOLD = 1000 * 60 * 60 * 20;

import { Jobs } from 'meteor/msavin:sjobs';

let countries = ["US", "GB", "CO"];

import webpush from 'web-push';
import { Meteor } from 'meteor/meteor';
import { check, Match } from 'meteor/check';
import AWS from 'aws-sdk';
import { Mongo } from 'meteor/mongo';
import { HTTP } from 'meteor/http';
import { DDP } from 'meteor/ddp-client';
import { Random } from 'meteor/random';
import moment from 'moment-timezone';
import { DDPRateLimiter } from 'meteor/ddp-rate-limiter';

let AdminDeletionCopies = new Mongo.Collection("admindeletioncopies");

const {EMOTION_META, ALLOWED_EMOTIONS, ANALYTICS_TIMEZONE, AGE_BRACKETS} = Meteor.settings.public;
const {ERROR_PASSWORD, IP_DATA_KEY} = Meteor.settings;

AWS.config.credentials = Meteor.settings.awsCredentials;

let ErrorLogs = new Mongo.Collection("errorLogs");

import enLang from '/imports/locales/en.json';
import esLang from '/imports/locales/es.json';

const localeFiles = {en:enLang, es:esLang};

import notifyUser from '/imports/api/server/notifyUser.js';
import ResearchCampaigns, { CampaignData }  from '/imports/api/ResearchCampaigns';
import nameFormat from '/imports/api/Profiles/format.js';
import EmotionalData, { EmotionalDataV2 } from '/imports/api/EmotionalData';
import EmotionalDataSchema from '/imports/api/EmotionalData/schema.js';
import Analytics from '/imports/api/Analytics';
import Profiles from '/imports/api/Profiles/Profiles';
import Occupations from '/imports/api/occupations';
import APIAccounts from '/imports/api/APIAccounts';
import {processAction} from '/imports/api/server/gamification';
import getTownList, {getTown, loadTowns} from '/imports/api/server/getTownList';

class Profile {
  constructor(profileKey) {
    this.profileKey = profileKey;
    this.points = 0;
    this.uploads = {total:0};
    this.name = null;
    this.avatar = null;
  }
}

Analytics.remove({$and:[{$or:[{type:"country"}, {type:"daily"}, {type:"hourly"}, {type:"minutely"}]}, {v:{$ne:4}}]}, {multi:true});

webpush.setGCMAPIKey("AAAAw-qfP1A:APA91bEtb6SHnZZqVcDLaCbzpY6OB0zERFT7yP_zBaV9Vvch0T0WTLsWYdldNoZ_U-ueZrtyfq73JedhpEi1E5OTYIxj4ABUQiqrhno6I46uqBt_0pFrC7wdNAId4OYrosTLP7mejNUG");
webpush.setVapidDetails(
  "mailto:support@feelenials.com",
  Meteor.settings.public.vapidPublic,
  Meteor.settings.vapidPrivate,
);

let _createCountryAnalytic = (country, emotion) => {
  if(Analytics.find({$and:[{type:"country"}, {country}]}).count() === 0) {
    Analytics.insert({v:4, type:"country", country, emotions:{[emotion]:1}});
  }
  else {
    Analytics.update({country}, {$inc:{["emotions." + emotion]:1}});
  }
};

let _createGenderHappinessAnalytic = (gender, day, value) => {
  let find = {$and:[{type:"genderHappiness"}, {gender}, {day}]};

  if(Analytics.find(find).count() === 0) {
    Analytics.insert({type:"genderHappiness", gender, day, value});
  }
  else {
    value.forEach(v => {
      Analytics.update(find, {$addToSet:{value:v}});
    });
  }
};

const processByDayAnalytic = name => {
  try {
    let m = moment().startOf("day");
    let day = m.format("YYYY-MM-DD");

    if(Analytics.findOne({$and:[{type:name}, {day}]})) {
      Analytics.update({$and:[{type:name}, {day}]}, {$inc:{value:1}});
    }
    else {
      Analytics.insert({
        type:name,
        value:1,
        day,
        date:m.toDate()
      });
    }
  }
  catch(e) {
    console.error(e);
  }
}

let determineBracket = (age) => AGE_BRACKETS.find(({min, max}) => (age >= min && age <= max));

let _processTimeSeriesAnalytics = function (_id, emotion, demographicData, idFormat, incAmnt, incType, aType) {
  let dailyAnalyticId = moment().format(idFormat);
  let ageBracket = determineBracket(demographicData.age).label;

  if(Analytics.find({id:dailyAnalyticId}, {fields:{_id:1}}).count() !== 0) {
    console.log("Updating existing analytic", dailyAnalyticId);
    Analytics.update({id:dailyAnalyticId}, {$inc:{"value.total":1, ["value." + emotion]:1, ["value." + (ageBracket + "happiness")]:emotion === "HAPPY" ? 1 : 0}});
  }
  else {
    console.log("Creating new analytic", dailyAnalyticId);
    let startDate = moment().tz(ANALYTICS_TIMEZONE).startOf(incType);
    let endDate = startDate.clone().add(incAmnt, incType);
    let id = dailyAnalyticId;
    let value = {total:1};
    Object.keys(EMOTION_META).forEach(e => value[e] = 0);
    AGE_BRACKETS.forEach(a => value[a.label] = 0);
    value[ageBracket + "happiness"] = (emotion === "HAPPY" ? 1 : 0);
    value[emotion] = 1;
    let aObj = {id, startDate:startDate.toDate(), endDate:endDate.toDate(), type:aType, value};
    Analytics.insert(aObj);
  }

  EmotionalData.update({_id}, {$set:{analyticsProcessedDaily:true, analyticsProcessedHourly:true, analyticsProcessedMinutely:true}});
};

let processAnalytics = function ({_id, emotion, country, demographicData, Emotions}) {
  try {
    _processTimeSeriesAnalytics(_id, emotion, demographicData, "MMDDYY", 1, "day", "daily");
  }
  catch(e) {console.error(e);}
  try {
    _processTimeSeriesAnalytics(_id, emotion, demographicData, "MMDDYYHH", 1, "hour", "hourly");
  }
  catch(e) {console.error(e);}
  try {
    _processTimeSeriesAnalytics(_id, emotion, demographicData, "MMDDYYHH:mm", 1, "minute", "minutely");
  }
  catch(e) {console.error(e);}

  generateCountryAnalyticsData: {
    if(typeof(country) === "string") {
      _createCountryAnalytic(country, emotion);
    }
  }

  EmotionalData.update({_id}, {$set:{analyticsProcessedCountry:true, analyticsProcessedGenderHappiness:true}});
};

let popularActivityRecalc = function () {
  if(Analytics.find({type:"popularActivity"}).count() < 1) {
    Analytics.insert({type:"popularActivity", value:null});
  }

  let submissions = EmotionalDataV2.find({date:{$gte:new Date(new Date() - 1000 * 60 * 60 * 4)}}, {fields:{"meta.activity":1}}).fetch();
  let activities = submissions.map(s => s.meta.activity);

  let total = 0, activityCounts = {};

  activities.forEach(a => {
    activityCounts[a] = activityCounts[a] || 0;
    activityCounts[a]++;
    total++;
  });


  let value = {
    total,
    activityCounts,
  };

  Analytics.update({type:"popularActivity"}, {$set:{value}});
};

Jobs.register({
  loadTowns,
  emotionReminder:function (userId, force) {
    let user = Meteor.users.findOne({_id:userId});

    if(force || (new Date() - user.les) > (LES_THRESHOLD - 60000)) {
      let {wisdom} = user;
      let myPosition = Meteor.users.find({wisdom:{$gt:wisdom}}).count() + 1;
      let lang = ["en", "es"].includes(user.pushLanguage) ? user.pushLanguage : "en";

      notifyUser(
        userId,
        localeFiles[lang]["We haven't seen you in a while"],
        localeFiles[lang]["You are #$ on the leaderboard, submit your emotion to earn 2 feelicoins and 10 wisdom!"].replace(/\$/, myPosition),
      );
    }
  }
});

const ADMINS = ["nate"];

let verifyTotalUsersAnalytic = () => {
  let totalUsers = Analytics.findOne({type:"totalUsers"});
  try {
    check(totalUsers.value, Match.Integer);
  }
  catch(e) {
    Analytics.update({type:"totalUsers"}, {$set:{value:Meteor.users.find({}).count()}});
  }
}

Meteor.startup(() => {
  verifyTotalUsersAnalytic();
});

Meteor.startup(() => {
  // Jobs.run("loadTowns", {singular:true});

  // ADMINS.forEach(username => {
  //   Meteor.users.update({username}, {$set:{admin:true}});
  // });

  // try {
  //   Analytics.remove({$or:[{type:"occupation"}, {type:"daily"}, {type:"minutely"}, {type:"hourly"}]}, {multi:true});
  //   EmotionalData.update({}, {$set:{analyticsProcessedDaily:false, analyticsProcessedHourly:false, analyticsProcessedMinutely:false, analyticsProcessedOccupation:false}}, {multi:true});

  //   let firstRecord = EmotionalData.findOne({}, {sort:{date:1}, fields:{date:1}});
  //   let initDate = firstRecord ? firstRecord.date : new Date();
  //   initDate = moment(initDate).tz(ANALYTICS_TIMEZONE).startOf("day");

  //   generateCountryAnalytics: {

  //     EmotionalData.update({}, {$set:{analyticsProcessedCountry:false}}, {multi:true});
  //     Analytics.remove({type:"country"}, {multi:true});

  //     EmotionalData.find({$and:[{country:{$type:"string"}}, {analyticsProcessedCountry:{$ne:true}}]}, {fields:{country:1, emotion:1}}).forEach(({_id, country, emotion}) => {
  //       _createCountryAnalytic(country, emotion);
  //       EmotionalData.update({_id}, {$set:{analyticsProcessedCountry:true}});
  //     });
  //   }

  //   generateOccupationAnalytics: {
  //     let occupations = {};
  //     Occupations.forEach(o => occupations[o] = {});

  //     EmotionalData.find({$and:[{"demographicData.occupation":{$type:"string"}}, {analyticsProcessedOccupation:{$ne:true}}]}, {fields:{_id:1, Emotions:1, demographicData:1, date:1, emotion:1}}).forEach(({_id, emotion:primaryEmotion, Emotions, demographicData, date}) => {
  //       EmotionalData.update({_id}, {$set:{analyticsProcessedOccupation:true}});

  //       if(!occupations.hasOwnProperty(demographicData.occupation)) {
  //         return;
  //       }

  //       occupations[demographicData.occupation].total = occupations[demographicData.occupation].total || 0;
  //       occupations[demographicData.occupation][primaryEmotion] = occupations[demographicData.occupation][primaryEmotion] || 0;

  //       occupations[demographicData.occupation].total += 1;
  //       occupations[demographicData.occupation][primaryEmotion] += 1;
  //     });

  //     Object.keys(occupations).forEach(occupation => {
  //       Analytics.insert({
  //         type:"occupation",
  //         occupation,
  //         value:occupations[occupation]
  //       });
  //     });
  //   }

  //   generateGenderHappinessAnalytics: {
  //     let genders = {
  //       male:{},
  //       female:{},
  //       other:{},
  //     };

  //     EmotionalData.find({$and:[{"Emotions":{type:"array"}}, {"demographicData.gender":{$type:"string"}}, {analyticsProcessedGenderHappiness:{$ne:true}}]}, {fields:{_id:1, Emotions:1, demographicData:1, date:1, emotion:1}}).forEach(({_id, emotion:primaryEmotion, Emotions, demographicData, date}) => {
  //       let { gender } = demographicData;

  //       let day = moment(date).format("YYMMDD");
  //       (!genders[gender][day]) && (genders[gender][day] = []);

  //       genders[gender][day].push({value:Emotions.find(e => e.Type === "HAPPY").Confidence, primaryEmotion});
  //       EmotionalData.update({_id}, {$set:{analyticsProcessedGenderHappiness:true}});
  //     });

  //     Object.keys(genders).forEach(gender => {
  //       Object.keys(genders[gender]).forEach(day => {
  //         _createGenderHappinessAnalytic(gender, day, genders[gender][day]);
  //       });
  //     });
  //   }

  //   generateDailyAnalytics: {
  //     let startDate = initDate.clone();
  //     let endDate = startDate.clone().add(1, "day");

  //     while(startDate.valueOf() < new Date().valueOf()) {
  //       let id = startDate.format("MMDDYY");
  //       let value = {};

  //       if(!Analytics.findOne({$and:[{id}, {type:"daily"}]})) {
  //         let query = {$and:[{analyticsProcessedDaily:{$ne:true}}, {date:{$gte:startDate.toDate()}}, {date:{$lt:endDate.toDate()}}]};
  //         value.total = EmotionalData.find(query).count();
  //         Object.keys(EMOTION_META).map(e => {
  //           value[e] = EmotionalData.find({$and:[{analyticsProcessedDaily:{$ne:true}}, {emotion:e, date:{$gte:startDate.toDate()}}, {date:{$lt:endDate.toDate()}}]}).count();
  //         });
  //         AGE_BRACKETS.forEach(a => value[a.label + "happiness"] = EmotionalData.find({$and:[{emotion:"HAPPY"}, {analyticsProcessedDaily:{$ne:true}}, {"demographicData.age":{$gte:a.min}}, {"demographicData.age":{$lte:a.max}}, {date:{$lt:endDate.toDate()}}]}).count());

  //         let aObj = {v:4, id, category:moment(startDate).format("ddd"), startDate:startDate.toDate(), endDate:endDate.toDate(), type:"daily", value};

  //         Analytics.insert(aObj);
  //         EmotionalData.update(query, {$set:{analyticsProcessedDaily:true}}, {multi:true});
  //       }

  //       startDate = startDate.add(1, "day");
  //       endDate = endDate.add(1, "day");
  //     }
  //   }


  //   generateHourlyAnalytics: {
  //     let startDate = moment().tz(ANALYTICS_TIMEZONE).subtract(72, "hours").startOf("hour");
  //     let endDate = startDate.clone().add(1, "hour");

  //     while(startDate.valueOf() < new Date().valueOf()) {
  //       let id = startDate.format("MMDDYYHH");
  //       let value = {};

  //       if(!Analytics.findOne({$and:[{id}, {type:"hourly"}]})) {
  //         let query = {$and:[{analyticsProcessedMinutely:{$ne:true}}, {date:{$gte:startDate.toDate()}}, {date:{$lt:endDate.toDate()}}]};
  //         value.total = EmotionalData.find(query).count();
  //         Object.keys(EMOTION_META).map(e => {
  //           value[e] = EmotionalData.find({$and:[{analyticsProcessedMinutely:{$ne:true}}, {emotion:e, date:{$gte:startDate.toDate()}}, {date:{$lt:endDate.toDate()}}]}).count();
  //         });

  //         let aObj = {v:4, id, startDate:startDate.toDate(), endDate:endDate.toDate(), type:"hourly", value};

  //         Analytics.insert(aObj);
  //         EmotionalData.update(query, {$set:{analyticsProcessedMinutely:true}}, {multi:true});
  //       }

  //       startDate = startDate.add(1, "hour");
  //       endDate = endDate.add(1, "hour");
  //     }
  //   }

  //   generateMinutelyAnalytics: {
  //     let startDate = moment().tz(ANALYTICS_TIMEZONE).subtract(60, "minute").startOf("minute");
  //     let endDate = startDate.clone().add(1, "minute");

  //     while(startDate.valueOf() < new Date().valueOf()) {
  //       let id = startDate.format("MMDDYYHH:mm");
  //       let value = {};

  //       if(!Analytics.findOne({$and:[{id}, {type:"minutely"}]})) {
  //         let query = {$and:[{analyticsProcessedHourly:{$ne:true}}, {date:{$gte:startDate.toDate()}}, {date:{$lt:endDate.toDate()}}]};
  //         value.total = EmotionalData.find(query).count();
  //         Object.keys(EMOTION_META).map(e => {
  //           value[e] = EmotionalData.find({$and:[{analyticsProcessedHourly:{$ne:true}}, {emotion:e, date:{$gte:startDate.toDate()}}, {date:{$lt:endDate.toDate()}}]}).count();
  //         });

  //         let aObj = {v:4, id, startDate:startDate.toDate(), endDate:endDate.toDate(), type:"minutely", value};

  //         Analytics.insert(aObj);
  //         EmotionalData.update(query, {$set:{analyticsProcessedHourly:true}}, {multi:true});
  //       }

  //       startDate = startDate.add(1, "minute");
  //       endDate = endDate.add(1, "minute");
  //     }
  //   }
  // }
  // catch(e) {
  //   console.error(e);
  // }

  try {
    Analytics.remove({type:"totalUsers"}, {multi:true});
    Analytics.remove({type:"usersGainedForDay"}, {multi:true});

    let users = Meteor.users.find({}, {fields:{createdAt:1}}).fetch();
    Analytics.insert({type:"totalUsers", value:users.length});
    let dayAnalytics = {};
    users.forEach(({createdAt}) => {
      let m = moment(createdAt).startOf("day");
      let day = m.format("YYYY-MM-DD");
      if(!dayAnalytics[day]) {
        dayAnalytics[day] = {
          type:"usersGainedForDay",
          value:0,
          day,
          date:m.toDate()
        };
      }
      dayAnalytics[day].value++;
    });
    Object.values(dayAnalytics).forEach(a => Analytics.insert(a));
  }
  catch(e) {
    console.error(e);
  }

  // try {
  //   popularActivityRecalc();
  //   Meteor.setInterval(popularActivityRecalc, 1000 * 60 * 10);
  // }
  // catch(e) {
  //   console.error(e);
  // }

});

Meteor.methods({

  "downloadCampaignData": function (campaignId) {
    check(campaignId, String);

    if(Meteor.user().admin !== true) {
      throw new Meteor.Error(400);
    }

    return CampaignData.find({campaignId}, {sort:{date:1}}).fetch();
  },

  "deleteUser": function ({username}) {
    check(username, String);

    if(Meteor.user().admin !== true) {
      throw new Meteor.Error(400);
    }

    let user = Accounts.findUserByUsername(username);

    AdminDeletionCopies.insert(user);

    Meteor.users.remove({_id:user._id});
  },

  "loadTowns": function () {
    if(Meteor.user().admin !== true) {
      throw new Meteor.Error(400);
    }

    loadTowns();
  },

  "addAdmin": function (username) {
    check(username, String);

    if(Meteor.user().admin !== true) {
      throw new Meteor.Error(400);
    }

    let user = Accounts.findUserByUsername(username);

    console.log(`${user.username} (${user._id}) added as admin`);

    Meteor.users.update({_id:user._id}, {$set:{admin:true}});
  },

  "changeUsername": function (newUsername) {
    check(newUsername, String);

    let existingAccount = Accounts.findUserByUsername(newUsername);

    if(existingAccount) {
      throw new Meteor.Error(400, "That username is already taken");
    }

    Meteor.users.update({_id:this.userId}, {$set:{username:newUsername}});
  },

  "createCampaign": function ({name, description, registrationCode, hiddenProperties}) {
    check(name, String);
    check(description, String);
    check(registrationCode, String);
    check(hiddenProperties, [String]);

    if(Meteor.user().admin !== true) {
      throw new Meteor.Error(400);
    }

    registrationCode = registrationCode.toLowerCase();

    ResearchCampaigns.insert({name, description, registrationCode, hiddenProperties});
  },

  "deleteCampaign": function (campaignId) {
    check(campaignId, String);

    if(Meteor.user().admin !== true) {
      throw new Meteor.Error(400);
    }

    ResearchCampaigns.remove({_id:campaignId});
    Meteor.users.update({campaigns:campaignId}, {$pull:{campaigns:campaignId}});
  },

  "setTown": function (townId) {
    check(townId, String);

    let town = getTown(townId);

    if(!town) {
      throw new Meteor.Error(400);
    }

    Meteor.users.update({_id:this.userId}, {$set:{location:town.loc, city:town.name, state:town.adminCode}});
  },

  "saveSED": function (sed) {
    check(sed, {
      specialGroup:String,
      vulnerableGroup:String,
      informationSource:String,
      fitness:String,
      nutrition: {
        foodAccessibility:String,
        foodQuantity:String,
        foodQuality:String
      },
      household: { civilStatus:String, livingSituation:String, pets:String},
      dependency:String,
      industry:String
    });

    Meteor.users.update({_id:this.userId}, {$set:{sed, hasSED:true}});
  },

  getTownList,

  "joinCampaignWithCode": function (registrationCode) {
    check(registrationCode, String);

    registrationCode = registrationCode.toLowerCase();

    let campaign = ResearchCampaigns.findOne({registrationCode});

    if(!campaign) {
      throw new Meteor.Error(400);
    }

    let currentUser = Meteor.users.findOne({_id:this.userId}, {fields:{campaigns:1}});
    let { campaigns } = currentUser;

    if(!campaigns || !campaigns.includes(campaign._id)) {
      Meteor.users.update({_id:this.userId}, {$addToSet:{campaigns:campaign._id}});
      ResearchCampaigns.update({_id:campaign._id}, {$inc:{participants:1}});
    }
  },

  "input:pad": function ({demographicData, value}) {
    check(demographicData, Object);
    check(value, {feeling:String, emotion:String, symptom:String, activity:String});

    let ip = this.connection.clientAddress, country = null;

    check(ip, String);
    if(ip === "127.0.0.1") {
      throw new Error('local-ip');
    }
    try {
      let {data} = HTTP.get(`https://api.ipdata.co/${ip}1?api-key=${IP_DATA_KEY}`);
      country = data.country_code;
    }
    catch(e) {
      if(e.response.statusCode === 403) {
        throw new Error("Failed to determine user's location");
      }
      else {
        country = null;
      }
    }

    let currentUser = Meteor.users.findOne({_id:this.userId}, {fields:{_id:0, city:1, state:1, location:1, sed:1, campaigns:1}});

    Meteor.defer(() => {
      let eDataObj = {
        date:new Date(),
        emotion:value.emotion,
        feeling:value.feeling,
        smiling:null,
        demographicData,
        sourceName:"Feelenials App",
        country,
        ...value,
        ...currentUser
      };

      let _id = EmotionalData.insert(eDataObj);

      processAnalytics({_id, ...eDataObj});
    });

    let v2DataObj = {
      type:"feeling",
      date:new Date(),
      meta: {
        type:"individual",
        age:demographicData.age,
        gender:demographicData.gender,
        occupation:demographicData.occupation,
        symptom:value.symptom,
        activity:value.activity,
        ...(currentUser ? {
          sed:currentUser.sed,
          state:currentUser.state,
          city:currentUser.city,
        } : {}),
        location: {
          country,
          ...((currentUser && currentUser.location) || {})
        },
      },
      value:{emotion:value.emotion, feeling:value.feeling},
      _version:1
    };

    if(currentUser && currentUser.campaigns && currentUser.campaigns.length > 0) {
      Meteor.defer(() => {
        currentUser.campaigns.forEach(cid => {
          // TODO Remove Hidden Properties
          CampaignData.insert({campaignId:cid, ...v2DataObj});
          ResearchCampaigns.update({_id:cid}, {$inc:{emotionsCollected:1}});
        });
      });
    }



    try {
      EmotionalDataSchema(v2DataObj);
    }
    catch(e) {
      console.error("Emotional Data object doesn't fit schema", v2DataObj, e);
      return;
    }

    let emotionSubmissionId = EmotionalDataV2.insert(v2DataObj);


    if(this.userId) {
      Meteor.users.update({_id:this.userId}, {$set:{latestActivity:value.activity, latestFeeling:value.feeling}, $inc:{"uploads.total":1, ["uploads." + value.feeling]:1, ["uploads." + value.emotion]:1}});
    }

    Meteor.defer(() => {
      Meteor.users.update({_id:this.userId}, {$addToSet:{"emotionSubmissions":emotionSubmissionId}});
      Analytics.update({type:"popularActivity"}, {$inc:{["value.activityCounts." + value.activity]:1, "value.total":1}});
    });

    return processAction(this.userId, "captureEmotion:button");
  },

  "err": function (err) {
    console.error(err);
  },

  "addRegistrationCode": function ({campaignId, code}) {
    check(campaignId, String);
    check(code, String);

    let currentUser = Meteor.user({fields:{admin:1}});

    if(currentUser.admin !== true) {
      throw new Meteor.Error(403);
    }

    let campaign = ResearchCampaigns.findOne({_id:campaignId});

    if(!Array.isArray(campaign.registrationCode)) {
      campaign.registrationCode = [campaign.registrationCode];
    }

    campaign.registrationCode.push(code);

    ResearchCampaigns.update({_id:campaignId}, {$set:{registrationCode:campaign.registrationCode}});
  },

  "setDemographicData": function (demographicData) {
    check(demographicData, {age:Match.Integer, occupation:String, gender:String, v:Match.Optional(String)});
    Meteor.users.update({_id:this.userId}, {$set:{demographicData}});
  },

  "getLeaderboardPosition": function () {
    let myProfile = Meteor.users.findOne({_id:this.userId}, {fields:{wisdom:1}});
    let {wisdom} = myProfile;
    let myPosition = Meteor.users.find({wisdom:{$gt:wisdom}}).count() + 1;
    return {myPosition};
  },

  "saveProfile:name": function ({name, profileKey}) {
    check(name, String);
    check(profileKey, String);

    if(!nameFormat.test(name)) {
      throw new Meteor.Error(400, "Your name can only contain letters, numbers, underscores, and dashes");
    }

    let existingProfile = Profiles.findOne({name}, {fields:{_id:1}});

    if(existingProfile) {
      throw new Meteor.Error(400, "That name is already being used by someone else. Try a different name");
    }

    Profiles.update({profileKey}, {$set:{name}});
  },

  "profiles:register": function () {
    let profileKey = Random.secret(50);
    while(Profiles.findOne({key:profileKey})) {
      profileKey = Random.secret(50);
    }

    Profiles.insert(new Profile(profileKey));

    return {profileKey};
  },

  "error": function (e, deviceInfo) {
    let headers;

    try {
      headers = this.connection.httpHeaders;
    }
    catch(e) {
      headers = {};
    }

    let eLogObj = {error:e, deviceInfo, headers};
    let errorId = ErrorLogs.insert(eLogObj);

    console.warn("Error received from client", eLogObj);

    return errorId;
  },

  "retrieveErrors": function (password) {
    check(password, String);

    if(ERROR_PASSWORD !== password) {
      console.warn("Incorrect password for retrieveErrors", this.connection);
      throw new Meteor.Error(500);
    }
    else {
      console.info("retrieveErrors", this.connection);
    }

    return ErrorLogs.find({}).fetch();
  },

  "savePushSub": function (sub, language) {
    check(sub, String);
    check(language, String);
    Meteor.users.update({_id:this.userId}, {$addToSet:{webPushSubs:sub}, $set:{pushLanguage:language}});
  },

  "saveNativePushToken": function (token, language) {
    check(token, String);
    check(language, String);
    Meteor.users.update({_id:this.userId}, {$addToSet:{nativePushTokens:token}, $set:{pushLanguage:language}});
  },

  "testNotf": function () {
    Jobs.run("emotionReminder", this.userId, true, {in:{seconds:15}});
  }

});


let _emotionalDataPublishFields = {_id:1, date:1, emotion:1, smiling:1, gender:1, demographicData:1, country:1};

Meteor.publish("campaignCode", function (code) {
  check(code, String);

  code = code.toLowerCase();

  return ResearchCampaigns.find({registrationCode:code}, {fields:{registrationCode:1, name:1, description:1}});
});

Meteor.publish("analytics:admin", function () {
  return Analytics.find({$or:[{type:"activeUsersByDay"}, {type:"visitsByDay"}, {type:"userVisitsByDay"}, {type:"usersGainedForDay"}, {type:"totalUsers"}]});
});

Meteor.publish("analytics:popularActivity", function () {
  return Analytics.find({type:"popularActivity"});
});

Meteor.publish("analytics:daily", function () {
  return Analytics.find({$and:[{type:"daily"}]}, {sort:{startDate:-1}, limit:7});
});

Meteor.publish("analytics:hourly", function () {
  return Analytics.find({$and:[{type:"hourly"}]}, {sort:{startDate:-1}, limit:8});
});

Meteor.publish("analytics:minutely", function () {
  return Analytics.find({$and:[{type:"minutely"}]}, {sort:{startDate:-1}, limit:15});
});

Meteor.publish("analytics:countries", function () {
  return Analytics.find({$and:[{type:"country"}]});
});

Meteor.publish("analytics:occupations", function () {
  return Analytics.find({$and:[{type:"occupation"}]});
});

Meteor.publish("analytics:genderHappiness", function () {
  return Analytics.find({$and:[{type:"genderHappiness"}]});
});

Meteor.publish("liveData", function () {
  return EmotionalData.find({date:{$gte:new Date(new Date().valueOf() - 1000 * 60)}}, {fields:_emotionalDataPublishFields});
});

Meteor.publish("listData", function () {
  return EmotionalDataV2.find({}, {fields:{}, limit:100, sort:{date:-1}});
});

Meteor.publish("myProfile", function (profileKey) {
  check(profileKey, String);

  return Profiles.find({profileKey});
});

Meteor.publish("leaderboard", function () {
  return Meteor.users.find({}, {fields:{username:1, feelicoins:1, wisdom:1}, sort:{wisdom:-1}, limit:50});
});

Meteor.publish("researchCampaignsList", function () {
  let currentUser = Meteor.users.findOne({_id:this.userId});

  if(currentUser.admin !== true) {
    this.error(new Meteor.Error(403));
    return [];
  }

  return ResearchCampaigns.find({});
});

//emotionSubmissions
Meteor.publish("myEmotionSubmissions", function () {
  let currentUser = Meteor.users.findOne({_id:this.userId}, {fields:{emotionSubmissions:1}});

  if(!currentUser) {
    this.ready();
    return [];
  }

  currentUser.emotionSubmissions = currentUser.emotionSubmissions || [];
  return EmotionalDataV2.find({$and:[{_id:{$in:currentUser.emotionSubmissions}}, {date:{$gte:new Date(new Date() - 1000 * 60 * 60 * 24 * 9)}}]});
});

Meteor.publish("myCampaigns", function () {
  let currentUser = Meteor.users.findOne({_id:this.userId}, {fields:{campaigns:1}});

  return ResearchCampaigns.find({_id:{$in:currentUser.campaigns || []}}, {fields:{name:1, description:1}});
});

Meteor.publish(null, function () {
  return Meteor.users.find({_id:this.userId}, {fields:{campaigns:1, securityQuestions:1, latestActivity:1, latestFeeling:1, demographicData:1, feelicoins:1, wisdom:1, city:1, state:1, hasSED:1}});
});

Accounts.onCreateUser((options, user) => {
  const customizedUser = Object.assign({/*default values*/}, user);

  if(!/^[a-zA-Z0-9]*$/.test(customizedUser.username)) {
    throw new Meteor.Error("validation-error", "Usernames can only contain letters and numbers");
  }

  try {
    check(options.demographicData, {gender:String, age:Match.Integer, occupation:String});
    customizedUser.demographicData = options.demographicData;
  }
  catch(e) {
    customizedUser.demographicData = null;
  }

  customizedUser.campaigns = [];

  try {
    check(options.campaignRegistrationCode, String);
    let {campaignRegistrationCode:code} = options;
    code = code.toLowerCase();
    let campaign = ResearchCampaigns.findOne({registrationCode:code});
    if(campaign) {
      customizedUser.campaigns.push(campaign._id);
      ResearchCampaigns.update({_id:campaign._id}, {$inc:{participants:1}});
    }
  }
  catch(e) {}

  let { email, username } = options;

  Meteor.defer(() => {
    try {
      Analytics.update({type:"totalUsers"}, {$inc:{value:1}});

      let m = moment().startOf("day");
      let day = m.format("YYYY-MM-DD");

      if(Analytics.findOne({$and:[{type:"usersGainedForDay"}, {day}]})) {
        Analytics.update({$and:[{type:"usersGainedForDay"}, {day}]}, {$inc:{value:1}});
      }
      else {
        Analytics.insert({
          type:"usersGainedForDay",
          value:1,
          day,
          date:m.toDate()
        });
      }
    }
    catch(e) {
      console.error(e);
    }
  });

  return customizedUser;
});


console.log(process.env.MONGO_URL);
Meteor.onConnection(() => {processByDayAnalytic("visitsByDay");});
Accounts.onLogin(info => {let {user} = info;processByDayAnalytic("userVisitsByDay");let day = moment().format("YYYYMMDD");if(user.visitDays && user.visitDays.includes(day)) {return;}Meteor.users.update({_id:user._id}, {$addToSet:{visitDays:day}});processByDayAnalytic("activeUsersByDay");});
