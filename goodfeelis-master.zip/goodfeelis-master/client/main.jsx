import React from 'react';
import { Meteor } from 'meteor/meteor';
import { Reload } from 'meteor/reload';
import { render } from 'react-dom';
import App from '/imports/ui/App'

Meteor.startup(() => {
  render(<App />, document.getElementById('react-target'));
});

Accounts.onLogout(() => {
    window.localStorage.removeItem("demographicData");
});

if(!Meteor.isDevelopment) {
  Reload._onMigrate(() => [false]);
}