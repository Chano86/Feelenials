import { Meteor } from 'meteor/meteor';
const c = Meteor;

const hashPassword = function(e) {
  return Accounts._hashPassword(e.trim().toLowerCase()).digest
}

const setQuestions = function(t) {
  var s = t.q
    , n = t.a;
  e.call("ndev:security-questions:setQuestions", {
      q: s,
      a: i(n)
  }, (function(e) {
      e ? n(e) : s()
  }
  ))
};

const startResetPassword = function(e) {
  return c.call("ndev:security-questions:startResetPassword", e, (function(e, n) {
      e ? t(e) : s(n)
  }
  ))
};

const validateAnswers = function(s, a) {
  return e.call("ndev:security-questions:validateAnswers", s, a, (function(e, s) {
      e ? n(e) : t(s)
  }
  ))
};

const resetPassword = function(e, s) {
  return c.call("ndev:security-questions:resetPassword", e, Accounts._hashPassword(s), (function(e, s) {
      e ? i(e) : t(s)
  }
  ))
};

export default ({
  setQuestions,
  startResetPassword,
  validateAnswers,
  resetPassword
});