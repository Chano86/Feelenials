import { Meteor } from 'meteor/meteor';

let config = {
    questionsField: "securityQuestions",
    questionsCount: 2
};

let setConfig = function (newConfig) {
    Object.assign(config, newConfig);
};

Meteor.methods({
    "ndev:security-questions:setQuestions": function (qaPairs) {
        check(qaPairs, [{
        q: String,
        a: String
        }]);
        check(qaPairs.length, config.questionsCount);
        let Qs = [];
        qaPairs.forEach(_ref => {
        let {
            q
        } = _ref;

        if (Qs.includes(q)) {
            throw new Meteor.Error(400, "You cannot use the same question more then once");
        } else {
            Qs.push(q);
        }
        });

        if (!this.userId) {
        throw new Meteor.Error(404, "Must be logged in");
        }

        Meteor.users.update({
        _id: this.userId
        }, {
        $set: {
            [config.questionsField]: qaPairs.map(i => i.q),
            "services.securityQuestions": qaPairs
        }
        });
        return 200;
    },
    "ndev:security-questions:startResetPassword": function (query) {
        check(query, Match.OneOf({
        id: String
        }, {
        username: String
        }));

        let user = Accounts._findUserByQuery(query);

        if (!user) {
        throw new Meteor.Error(404, "User not found");
        }

        if (!user.services.securityQuestions) {
        throw new Meteor.Error(400, "No security questions set");
        }

        let questions = user.services.securityQuestions.map(_ref2 => {
        let {
            q,
            a
        } = _ref2;
        return q;
        });
        check(questions, [String]);
        return questions;
    },
    "ndev:security-questions:validateAnswers": function (query, answers) {
        check(answers, [String]);
        check(query, Match.OneOf({
        id: String
        }, {
        username: String
        }));

        let user = Accounts._findUserByQuery(query);

        if (!user) {
        throw new Meteor.Error(404, "User not found");
        }

        if (!user.services.securityQuestions) {
        throw new Meteor.Error(400, "No security questions set");
        }

        check(answers.length, user.services.securityQuestions.length);

        try {
        let validAnswers = user.services.securityQuestions.map(_ref3 => {
            let {
            a
            } = _ref3;
            return a;
        });
        answers.forEach((answer, index) => check(answer, validAnswers[index]));
        } catch (e) {
        throw new Meteor.Error(403, "Incorrect answer to a security question");
        }

        const token = Random.secret();
        const tokenRecord = {
        token,
        email: null,
        when: new Date(),
        reason: "reset",
        isSecurityQuestion: true
        };
        Meteor.users.update({
        _id: user._id
        }, {
        $set: {
            'services.password.reset': tokenRecord
        }
        });
        return token;
    },
    "ndev:security-questions:resetPassword": function (token, password) {
        check(token, String);
        check(password, {
        digest: String,
        algorithm: String
        });
        let user = Meteor.users.findOne({
        "services.password.reset.token": token
        });

        if (!user) {
        throw new Meteor.Error(400, "Token Expired");
        }

        let tokenRecord = user.services.password.reset;

        if (new Date(new Date() - 1000 * 60 * 5) >= tokenRecord.when) {
        throw new Meteor.Error(400, "Token Expired");
        }

        Accounts.setPassword(user._id, password);
    }
});

export default ({
    setConfig
});
