import { check, Match } from 'meteor/check';

let validate = function (obj) {    
    check(obj, {
        type:"feeling",
        date:Date,
        meta: {
            type:"individual",
            
            age:Number,
            gender:Match.OneOf("female", "male", "other"),
            occupation:String,
            
            symptom:Match.Optional(String),
            activity:Match.Optional(String),
            
            sed:Match.Optional({
                specialGroup:String,
                vulnerableGroup:String,
                informationSource:String,
                fitness:String,
                nutrition: {
                    foodAccessibility:String,
                    foodQuantity:String,
                    foodQuality:String
                },
                household: {
                    civilStatus:String,
                    livingSituation:String,
                    pets:String
                },
                dependency:String,
                industry:String
            }),
            
            city:Match.Optional(String),
            state:Match.Optional(String),
            location:{
                country:String,
                type:"Point",
                coordinates:[Number]
            },
        },
        value:{feeling:String, emotion:String},
        _version:1
    });
};

export default validate;
