import { Mongo } from 'meteor/mongo';

export default new Mongo.Collection("emotionalData");
export let EmotionalDataV2 = new Mongo.Collection("emotionalDataV2");