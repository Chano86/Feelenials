import { Meteor } from 'meteor/meteor';
import { Mongo } from 'meteor/mongo';
const {IP_DATA_KEY} = Meteor.settings;

const TownsDB = new Mongo.Collection("towns");

console.log(TownsDB.findOne());

export let loadTowns = function () {
    let townsList = require('all-the-cities');
    if(TownsDB.find({}).count() !== townsList.length) {
        let length = townsList.length;
        townsList.forEach((t,i) => {
            if(TownsDB.find({cityId:t.cityId}).count() === 0) {
                console.log("Inserting", i, "/", length, `${Math.trunc((i/length)*100)}%`);
                TownsDB.insert(t);
            }
            else {
                console.log("Skipping", i, "/", length, `${Math.trunc((i/length)*100)}%`);
            }
        });
    }
    else {
        console.info(`All ${townsList.length} towns are in the database. Nice!`);
    }
    
    this.success && this.success();
};

TownsDB._collection.rawCollection().createIndex({loc:"2dsphere"});
TownsDB._collection.rawCollection().createIndex({name:"text"});

export let getTown = function (townId) {
    return TownsDB.findOne({_id:townId}, {fields:{adminCode:1, name:1, loc:1}});
};

let getTownList = function (name) {

    let ip = this.connection.clientAddress, country = null;
    
    if(ip === "127.0.0.1") {
        ip = this.connection.httpHeaders["x-forwarded-for"].split(",")[0];
    }
    
    
    let {data} = HTTP.get(`https://api.ipdata.co/${ip}?api-key=${IP_DATA_KEY}`);
    let {latitude:lat, longitude:lng} = data;
    
    console.log(ip, [lat,lng]);
    
    // name
    let query = {
        loc: {
            $near: {
                $geometry:{type:"Point", coordinates:[lng,lat]},
                $minDistance:0,
            }
        }
    };
    
    if(typeof(name) === "string") {
        query["name"] = new RegExp(name, "gi");
    }
    
    let towns = TownsDB.find(
        query,
        {fields:{loc:1, name:1}, limit:100}
    ).fetch();
    
    console.log(towns.length);
    
    return {towns};
};

export default getTownList;