let wisdomTable = {
    "captureEmotion:button":10,
    "captureEmotion:voice":10,
    "captureEmotion:photo":10,
    "captureEmotion:addMoreInfo":5,
    "share":20,
    "referral":20
};

let feelicoinsTable = {
    "captureEmotion:button":2,
    "captureEmotion:voice":2,
    "captureEmotion:photo":2,
    "captureEmotion:addMoreInfo":1,
    "share":5,
    "referral":10
};

let cooldownTable = { // in minutes
    "captureEmotion:button":1, // 5
    "captureEmotion:voice":1, // 5
    "captureEmotion:photo":1, // 5
    "captureEmotion:addMoreInfo":1, // 5
    "share":1, // 5
    "referral":0
};

let feelicoins = (userId, action) => feelicoinsTable[action];
let wisdom = (userId, action) => wisdomTable[action];

let processAction = function (userId, action) {
    let user = Meteor.users.findOne({_id:userId}, {fields:{cooldowns:1}});
    
    if(!user) {
        return;
    }
    
    if(user.cooldowns && user.cooldowns.hasOwnProperty(action) && user.cooldowns[action] > new Date()) {
        // Cooldown has not passed
        return "cooldown";
    }
    
    let cooldownEnd = (new Date() + (cooldownTable[action] * 60 * 1000));
    
    Meteor.users.update({_id:userId}, {
        $inc: {
            "feelicoins":feelicoins(userId, action),
            "wisdom":wisdom(userId, action),
        },
        $set: {
            ["cooldowns." + action]:cooldownEnd
        }
    });
    
    return {feelicoins:feelicoinsTable[action], wisdom:wisdomTable[action]};
};

export { processAction, cooldownTable };