                                                        const fcmServerKey = "AAAAw-qfP1A:APA91bEdfC0yqlmPCfzWcQG7G2HnZYvSzGzQicliVAauf0ay9GUfDkEXPiatgmssW5e20X3XINWlusMCBwomTggawywN6FlWzXfnrNfuyCThnscCbrZZCI1MUZ49t5oBJzZCZL7VhYx4";

import webpush from 'web-push';

export default function (userId, title, body) {
    let currentUser = Meteor.users.findOne({_id:userId}, {fields:{webPushSubs:1, nativePushTokens:1}});
    
    (currentUser.webPushSubs || []).forEach(sub => {
      webpush.sendNotification(
          JSON.parse(sub),
          JSON.stringify({title, body})
         );
    });    
    
    (currentUser.nativePushTokens || []).forEach(token => {
        HTTP.post("https://fcm.googleapis.com/fcm/send", {
          headers:{"Content-Type":"application/json", "Authorization":"key=" + fcmServerKey},
          data:{
            to:token,
            notification:{
              title, body, sound:"default"
            },
            data:{"type":"test"}
          }
        });        
    });
    
    return 200;
}