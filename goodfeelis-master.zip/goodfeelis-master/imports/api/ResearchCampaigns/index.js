import { Mongo } from 'meteor/mongo';

export default new Mongo.Collection("researchcampaigns");
export let CampaignData = new Mongo.Collection("campaignData");