export default (binaryStream, demographicData, profileKey) => new Promise((resolve, reject) => {
        try {
            let xhr = new XMLHttpRequest();
            xhr.open('POST', `/api/scan-file?demographicData=${encodeURI(JSON.stringify(demographicData))}&profileKey=${profileKey}`, true);
            xhr.onload = function(e) {
              resolve(JSON.parse(e.target.response));
            };
            xhr.send(binaryStream);
        }
        catch(e) {
            reject(e);
        }
    });