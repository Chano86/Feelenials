import { Meteor } from 'meteor/meteor';
import React from 'react';

let getDeviceInfo = () => {
  try {
    return window.navigator.vendor + " " + window.navigator.userAgent;
  }
  catch(e) {
    return "Unknown";
  }
};

let report = function (e, callback) {
  try {
    Meteor.call("error", {...e, str:JSON.stringify(e), name:e.name, message:e.message}, getDeviceInfo(), (e, errorId) => {
      if(typeof(callback) === "function") {
        callback(errorId);
      }
    });
  }
  catch(e) {
    alert("There was an error, please contact support.");
    console.error(e);
  }
};

let ErrorPage = (props) => (
  <div>
    <h2>Something Went Wrong</h2>
    <p>Sorry! There was an unexpected error. Please contact Feelenials support</p>
    {props.hasOwnProperty("errorId") ? <b>When contacting support, provide them this error id: {props.errorId}</b> : null}
    <br/><br/>
    <code style={{color:"red", fontWeight:"bold", fontSize:25}}>
      {props.error && props.error.toString()}
    </code>
    <br/>
    <code>
      {props.errorInfo && JSON.stringify(props.errorInfo)}
    </code>
  </div>  
);

class ErrorBoundary extends React.Component {
  constructor(props) {
    super(props);
    this.state = { hasError: false };
  }

  static getDerivedStateFromError(error) {
    return { hasError: true };
  }

  componentDidCatch(error, errorInfo) {
    this.setState({error, errorInfo});
    report({error, errorInfo}, (errorId) => {
      this.setState({errorId});
    });
  }

  render() {
    if(this.state.hasError) {
      return <ErrorPage {...this.state}/>;
    }

    return this.props.children; 
  }
}

export default report;
export { ErrorBoundary, ErrorPage };