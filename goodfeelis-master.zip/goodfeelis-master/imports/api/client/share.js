/*
    Twitter: Text
    Facebook: URL and Text
    LinkedIn: Title, Text, URL, and Source (e.g. Feelenials or GoodFeelis)
*/

let share = function ({text, url, title, source}) {
    let twitter = "https://twitter.com/intent/tweet" + encodeURI(`?text=${text}`);
    let facebook = "https://www.facebook.com/sharer/sharer.php" + encodeURI(`?href=${url}&description=${text}`);
    let linkedin = "https://www.linkedin.com/shareArticle" + encodeURI(`?mini=true&url=${url}&title=${title}&summary=${text}&source=${source}`);
    
    return {
        twitter,
        facebook,
        linkedin
    };
};

export default share;