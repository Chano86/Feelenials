let activities = [
    {
        id:"workingFromHome",
        label:"Working from Home",
        icon:"/icons/working.png"
    },
    {
        id:"workingFromOffice",
        label:"Working from Office",
    },    
    {
        id:"studyingAtHome",
        label:"Studying at Home",
        icon:"/icons/books.png"
    },
    {
        id:"studyingFromSchool",
        label:"Studying at School/University",
    },    
    {
        id:"playingGames",
        label:"Playing Games",
        icon:"/icons/jigsaw.png"
    },
    {
        id:"talkingToFriends",
        label:"Talking to Friends"
    },
    {
        id:"talkingToFamily",
        label:"Talking to Family"
    },
    {
        id:"artsAndCrafts",
        label:"Arts & Crafts"
    },
    {
        id:"buyingGroceries",
        label:"Buying Groceries"
    },
    {
        id:"Commuting",
        label:"commuting"
    },
    {
        id:"socialMedia",
        label:"Spending time on social media"
    },
    {
        id:"dogWalking",
        label:"Walking my Dog"
    },
    {
        id:"hospital",
        label:"Hospital Visit"
    },
    {
        id:"news",
        label:"Reading/Listening to the news"
    },
    {
        id:"exercise",
        label:"Exercise"
    },
    {
        id:"relaxing",
        label:"Relaxing"
    },    
    {
        id:"housekeeping",
        label:"Housekeeping"
    },
    {
        id:"shoppingOnline",
        label:"Shopping Online"
    },    {
        id:"shoppingRetail",
        label:"Shopping In-Person"
    },
    {
        id:"cooking",
        label:"Cooking"
    },    
    {
        id:"listeningToMusic",
        label:"Listening to Music"
    },      
    {
        id:"dancing",
        label:"Dancing"
    },      
    {
        id:"visitingPeople",
        label:"Visiting Family/Friends"
    },
    {
        id:"eating",
        label:"Eating"
    },
    {
        id:"gardening",
        label:"Gardening"
    },
    {
        id:"reading",
        label:"Reading"
    },    
    {
        id:"meditating",
        label:"Meditating"
    },    
    {
        id:"dating",
        label:"Dating"
    },        
    {
        id:"banking",
        label:"Banking"
    },            
    {
        id:"watchingVideoContent",
        label:"Watching TV/Streaming"
    },
    {
        id:"nothing",
        label:"Nothing"
    },    
    
];

export default activities;