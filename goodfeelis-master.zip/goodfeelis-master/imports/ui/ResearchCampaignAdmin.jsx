import React from 'react';
import { withTracker } from 'meteor/react-meteor-data';

import t from './t';
import ResearchCampaigns from '/imports/api/ResearchCampaigns';
import DownloadCampaignData from './DownloadCampaignData';

class ResearchCampaignAdmin extends React.Component {
    
    state = {};
    
    submit = () => {
        let name = document.getElementById("campaignName").value;
        let description = document.getElementById("campaignDescription").value;
        let registrationCode = document.getElementById("registrationCode").value;
        
        let hiddenProperties = [];
        document.querySelectorAll(".hiddenProperty:checked").forEach(a => hiddenProperties.push(a.id));
        
        Meteor.call("createCampaign", {name, description, registrationCode, hiddenProperties}, err => {
            if(err) {
                alert(err.reason);
            }
            else {
                document.getElementById("campaignName").value = "";
                document.getElementById("campaignDescription").value = "";
                document.getElementById("registrationCode").value = "";
            }
        });
    }
    
    deleteCampaign = campaignId => {
        if(confirm("Delete this campaign?")) {
            Meteor.call("deleteCampaign", campaignId);
        }
    }
    
    addRegistrationCode = campaignId => {
        let code = prompt("Enter the new registration code...");
        
        if(code) {
            Meteor.call("addRegistrationCode", {campaignId, code});
        }
    }
    
    render() {
        
        if(this.state.downloadCampaignData) {
            return <DownloadCampaignData campaignId={this.state.downloadCampaignData}/>
        }
        
        return (
            <div style={{height:"100%", width:"100%"}}>
                
                <h2>Create Research Campaign</h2>
                
                <div style={{width:"50%", padding:20}}>
                    <div className="V2Input">
                        <input type="text" id="campaignName" placeholder={t("Enter campaign name...")} className="V2InputElement"/>
                    </div>
                </div>

                <div style={{width:"50%", padding:20}}>
                    <div className="V2Input">
                        <input type="text" id="campaignDescription" placeholder={t("Enter campaign description...")} className="V2InputElement"/>
                    </div>
                </div>
                
                <div style={{width:"50%", padding:20}}>
                    <div className="V2Input">
                        <input type="text" id="registrationCode" placeholder={t("Enter the registration code... (case insensitive)")} className="V2InputElement"/>
                    </div>
                </div>                
                
                <div style={{padding:20}}>
                    <h3>Check boxes below to REMOVE those metadata properties from the raw data</h3>
                    <div>age <input id="age" className="hiddenProperty" type="checkbox"/></div>
                    <div>gender <input id="gender" className="hiddenProperty" type="checkbox"/></div>
                    <div>occupation <input id="occupation" className="hiddenProperty" type="checkbox"/></div>
                    <div>symptom <input id="symptom" className="hiddenProperty" type="checkbox"/></div>
                    <div>activity <input id="activity" className="hiddenProperty" type="checkbox"/></div>
                    <div>specialGroup <input id="specialGroup" className="hiddenProperty" type="checkbox"/></div>
                    <div>vulnerableGroup <input id="vulnerableGroup" className="hiddenProperty" type="checkbox"/></div>
                    <div>informationSource <input id="informationSource" className="hiddenProperty" type="checkbox"/></div>
                    <div>fitness <input id="fitness" className="hiddenProperty" type="checkbox"/></div>
                    <div>foodAccessibility <input id="foodAccessibility" className="hiddenProperty" type="checkbox"/></div>
                    <div>foodQuantity <input id="foodQuantity" className="hiddenProperty" type="checkbox"/></div>
                    <div>foodQuality <input id="foodQuality" className="hiddenProperty" type="checkbox"/></div>
                    <div>civilStatus <input id="civilStatus" className="hiddenProperty" type="checkbox"/></div>
                    <div>livingSituation <input id="livingSituation" className="hiddenProperty" type="checkbox"/></div>
                    <div>pets <input id="pets" className="hiddenProperty" type="checkbox"/></div>
                    <div>dependency <input id="dependency" className="hiddenProperty" type="checkbox"/></div>
                    <div>industry <input id="industry" className="hiddenProperty" type="checkbox"/></div>
                    <div>city:<input id="city" className="hiddenProperty" type="checkbox"/></div>
                    <div>state : <input id="state" className="hiddenProperty" type="checkbox"/></div>
                </div>
                
                <button onClick={this.submit}>Create</button>
                
                <h2>Research Campaigns ({!this.props.loading && this.props.campaigns.length})</h2>
                {this.props.loading ?
                    <div>Loading...</div>
                :
                    <table>
                        <tr>
                            <th>Name</th>
                            <th>Description</th>
                            <th>Registration Code</th>
                            <th>Participants</th>
                            <th>Emotions Collected</th>
                            <th>Actions</th>
                        </tr>
                        {this.props.campaigns.map(c => <tr>
                            <td>{c.name}</td>
                            <td>{c.description}</td>
                            <td>{Array.isArray(c.registrationCode) ? c.registrationCode.join(", ") : c.registrationCode} <a href="#" onClick={() => this.addRegistrationCode(c._id)}>+</a></td>
                            <td>{c.participants || 0}</td>
                            <td>{c.emotionsCollected || 0}</td>
                            <td><button onClick={() => this.setState({downloadCampaignData:c._id})}>Download Data</button> <button onClick={() => this.deleteCampaign(c._id)}>Delete</button></td>
                        </tr>)}
                    </table>
                }
            </div>
        );
    }
}

export default withTracker(() => {
    
    let handle = Meteor.subscribe("researchCampaignsList");
    let campaigns = ResearchCampaigns.find().fetch();
    
    return {
        loading:!handle.ready(),
        campaigns
    };
    
})(ResearchCampaignAdmin);