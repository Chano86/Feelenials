let language = window.localStorage.language || window.navigator.language.slice(0, 2).toLowerCase();

export {language};

import en from '/imports/locales/en.json';
import es from '/imports/locales/es.json';

let languages = {en, es};

export default function (key) {
    let myLanguage = languages[language];
    if(languages[language] && myLanguage.hasOwnProperty(key)) {
        return myLanguage[key];
    }
    else {
        let enLanguage = languages.en;
        if(enLanguage.hasOwnProperty(key)) {
            return enLanguage[key];
        }
        else {
            return key;
        }
    }
}
