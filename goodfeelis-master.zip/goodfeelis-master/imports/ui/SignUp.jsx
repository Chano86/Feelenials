import React from 'react';

import { Meteor } from 'meteor/meteor';
import { Accounts } from 'meteor/accounts-base';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faUser, faLock } from '@fortawesome/free-solid-svg-icons';

import PhoneView from './FlatUI/PhoneView';
import t from './t';
import occupations from '/imports/api/occupations.js';

import { LoggingInHold } from './App.jsx';

const {REGISTER_NOTICE} = Meteor.settings.public;

class Register extends React.Component {
    
    submit = () => {
        let gender = document.getElementById("gender").value;
        let age = Number(document.getElementById("age").value);
        let occupation = document.getElementById("occupation").value;
        let v = "2";
        
        if(age === 0 || isNaN(age)) {
            return alert("Please enter your age");
        }

        if(gender === "select") {
            return alert("Please select your gender");
        }

        if(occupation === "select") {
            return alert("Please select your occupation");
        }

        window.localStorage.setItem("demographicData", JSON.stringify({gender, age, occupation, v}));        
        
        window.location.reload();
    }
    
    render() {
        
        return <PhoneView>
            <div className="V2Header">
                {/*TODO Caret*/}
                <div className="V2HeaderText">
                    {t("Demographic Information")}
                </div>
            </div>
            <div className="V2Content">
                <div className="V2Title">
                    {t("Demographic Information").split(" ")[0]}<br/>
                    {t("Demographic Information").split(" ")[1]}
                </div>
                <div className="V2Subtitle">
                    {t("This is only collected for the purpose of creating demographic reports")}
                </div>
                <div className="V2Input">
                    <input id="age" placeholder={t("Enter your age...")} type="number" className="V2InputElement"/>
                </div>
                <div style={{height:40}}/>
                <div className="V2Input">
                    <select className="V2InputElement" id="gender">
                        <option style={{color:"#808080"}} value={"select"}>{t("Select your gender...")}</option>
                        <option value="male">{t("Male")}</option>
                        <option value="female">{t("Female")}</option>
                        <option value="other">{t("Other/Non-Binary")}</option>
                    </select>
                </div>
                <div style={{height:40}}/>
                <div className="V2Input">
                    <select className="V2InputElement" id="occupation">
                        <option style={{color:"#808080"}} value={"select"}>{t("Select your occupation...")}</option>
                        {occupations.map(occupation => <option value={occupation}>{t(occupation)}</option>)}
                    </select>
                </div>                
                <div style={{height:40}}/>
                
                <button onClick={this.submit} className="V2Button">{t("Continue")}</button>
            </div>
        </PhoneView>;
    }
    
}

export default Register;