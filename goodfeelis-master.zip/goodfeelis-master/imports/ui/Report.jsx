import React, { Component } from 'react';
import { withTracker } from 'meteor/react-meteor-data';
import moment from 'moment';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faFemale, faMale, faArrowRight, faTimes, faSearch, faChevronLeft, faChevronRight } from '@fortawesome/free-solid-svg-icons';
import { HTTP } from 'meteor/http';
import { geoCentroid } from "d3-geo"
import { withRouter } from "react-router-dom";

import EmotionalData from '/imports/api/EmotionalData';
import Analytics from '/imports/api/Analytics';
import {EmotionLineChart} from './WorldEmotion';
import occupations, {_fixTranslation} from '/imports/api/occupations.js';
import Header from '/imports/ui/Header.jsx';
import Footer from '/imports/ui/Footer.jsx';
import PhoneView from './FlatUI/PhoneView';
import WorldChart from './WorldChart';
import Splash from './Splash.jsx';
import ShareButton from './ShareButton';

import t from './t';
const geoUrl =
  "https://raw.githubusercontent.com/zcreativelabs/react-simple-maps/master/topojson-maps/world-110m.json";
let geoData = null;
window.fetch(geoUrl).then(r => r.json().then(d => geoData = d));

const {EMOTION_META, ALLOWED_EMOTIONS} = Meteor.settings.public;

let mode = arr => {
  let counts = {};
  arr.forEach(i => {counts[i] ? counts[i]++ : counts[i]=1;});
  return Object.keys(counts).sort((a,b) => counts[b] - counts[a])[0];
};

let FillIcon = ({height=40, topColor, bottomColor, icon, percent}) => (
  <div style={{fontSize:height, position:"relative", height}}>
    <div style={{overflow:"hidden", height:(100 - percent) + "%"}}>
      <FontAwesomeIcon style={{height, color:topColor}} icon={icon}/>
    </div>
    <div style={{height:percent + "%", overflow:"hidden", position:"relative"}}>
      <FontAwesomeIcon style={{position:"absolute", left:"calc(50% - 7.5px)", bottom:-2, height, color:bottomColor}} icon={icon}/>
    </div>
  </div>  
);

let ReportHeader = withRouter(({history, active}) => (
  <div style={{position:"relative", paddingTop:15, boxShadow:"0 4px 22px 0 #00000058", background:"linear-gradient(to right, #41017b, #7500e5)", borderBottomLeftRadius:10, borderBottomRightRadius:10, overflow:"auto"}}>
    <div style={{lineHeight:"14px", textAlign:"center", fontWeight:"bold", fontSize:14, color:"white", fontFamily:'"Rubik", sans-serif'}}>{t("Dashboard")}</div>
    <div className="tabs" style={{height:55, display:"flex", flexDirection:"row", alignItems:"center"}}>
      <div onClick={() => history.push("/report/personal")} style={{height:"100%", width:"100%", position:"relative", display:"flex", flexDirection:"column", justifyContent:"center"}}>
        <div style={{fontSize:12, color:active === "personal" ? '#37fbbb' : "white", textAlign:"center", fontWeight:"bold"}}>{t("Personal Report")}</div>
        {active === "personal" && <div style={{width:"100%", display:"flex", alignItems:"center", justifyContent:"center", position:"absolute", bottom:0, textAlign:"center"}}><div style={{display:"inline-block", height:2, width:65, backgroundColor:"#37fbbb"}}/></div>}
      </div>
      <div onClick={() => history.push("/report/global")} style={{height:"100%", width:"100%", position:"relative", display:"flex", flexDirection:"column", justifyContent:"center"}}>
        <div style={{fontSize:12, color:active === "global" ? '#37fbbb' : "white", textAlign:"center", fontWeight:"bold"}}>{t("Global Report")}</div>
        {active === "global" && <div style={{width:"100%", display:"flex", alignItems:"center", justifyContent:"center", position:"absolute", bottom:0, textAlign:"center"}}><div style={{display:"inline-block", height:2, width:65, backgroundColor:"#37fbbb"}}/></div>}
      </div>
    </div>
  </div>  
));

export { ReportHeader };

class Info extends Component {
  state = {
    date:new Date(),
    timeReport:"daily"
  }
  
  componentDidMount() {
    this.interval = setInterval(() => {
      this.setState({date:new Date()});
    }, 5000);
  }
  
  componentWillUnmount() {
    clearInterval(this.interval);
  }
  
  searchForCountry = () => {
    let text = document.getElementById("countrySearch").value;
    
    if(!geoData || !window.panToCountry) {
      return;
    }
    
    if(text.length < 2) {
      return window.resetWorldMapPan();
    }
    
    text = text.toLowerCase().trim();
    let countryData = geoData.objects.ne_110m_admin_0_countries.geometries.map(g => g.properties);
    
    let country;
    if(text.length === 2) {
      country = countryData.find(({ISO_A2}) => (ISO_A2.toLowerCase() === text));
    }
    else {
      let matches = countryData.filter(({
        NAME, NAME_LONG, ABBREV, FORMAL_EN, ISO_A2
      }) => {
        return (
          NAME.toLowerCase().includes(text)
          || NAME_LONG.toLowerCase().includes(text)
          || ABBREV.toLowerCase().includes(text)
          || FORMAL_EN.toLowerCase().includes(text)
          || ISO_A2.toLowerCase().includes(text)
        );
      });
      
      if(matches.length > 1) {
        country = countryData.find(({
          NAME_LONG, FORMAL_EN
        }) => {
          return (
            NAME_LONG.toLowerCase().includes(text)
            || FORMAL_EN.toLowerCase().includes(text)
          );
        });      
      }
      else {
        country = matches[0];
      }
    }
    
    if(country) {
      let countryCode = country.ISO_A2;
      window.panToCountry(countryCode);
      this.setState({zoomedCountry:countryCode});
    }
    else {
      this.resetCountry();
    }
    
    document.getElementById("countrySearch").blur();
  }
  
  resetCountry = () => {
    this.setState({zoomedCountry:null});
    window.resetWorldMapPan();
  }
  
  charts = ["minutely", "daily", "hourly"];
  
  previousLineChart = () => {
    let currentIndex = this.charts.indexOf(this.state.timeReport);
    let newIndex = currentIndex-1;
    if(newIndex < 0) {
      newIndex = this.charts.length-1;
    }
    console.log(currentIndex, newIndex);
    this.setState({timeReport:this.charts[newIndex]});
  }
  
  nextLineChart = () => {
    let currentIndex = this.charts.indexOf(this.state.timeReport);
    let newIndex = currentIndex+1;
    if(newIndex > (this.charts.length-1)) {
      newIndex = 0;
    }
    console.log(currentIndex, newIndex);
    this.setState({timeReport:this.charts[newIndex]});
  }  
  
  render() {
    let { analyticsData, liveData, listData, loading } = this.props;
    let {timeReport} = this.state;
    
    if(loading) {
      return <Splash/>;
    }
    
    console.log(this.props.dailyAnalytics)
    
    let charts = {
      "daily": {
        type:"daily",
        data:this.props.dailyAnalytics,
        title:t("Emotions by Day")
      },
      "hourly": {
        type:"hourly",
        data:this.props.hourlyAnalytics,
        title:t("Emotions by Hour")
      },
      "minutely": {
        type:"minutely",
        data:this.props.minutelyAnalytics,
        title:t("Emotions by Minute")
      },      
    }
    
    let {zoomedCountry} = this.state, countryName;
    if(zoomedCountry) {
      let countryCode = zoomedCountry;
      let countryData = geoData.objects.ne_110m_admin_0_countries.geometries.map(g => g.properties);
      zoomedCountry = this.props.countryAnalytics.find(a => a.country === zoomedCountry);
      countryName = countryData.find(({ISO_A2}) => ISO_A2 === countryCode).NAME;
      
      if(typeof(zoomedCountry) === "object") {
        zoomedCountry = {...zoomedCountry, ...zoomedCountry.emotions};
        zoomedCountry.total = 0;
        Object.keys(EMOTION_META).forEach(key => zoomedCountry.total+=(zoomedCountry[key] || 0));
        console.log(zoomedCountry);
      }
    }
    
    let primaryActivity, primaryPercent;
    if(this.props.popularActivityAnalytics) {
      let {activityCounts, total} = this.props.popularActivityAnalytics.value;
      if(total > 0) {
        primaryActivity = Object.keys(activityCounts).sort((a,b) => activityCounts[b] - activityCounts[a])[0];
        primaryPercent = (activityCounts[primaryActivity] / total) * 100;
      }
    }
    
    return (
      <PhoneView>
        <ShareButton/>
        <ReportHeader active="global"/>
        <div style={{padding:10, paddingTop:24, paddingBottom:0, fontFamily:'"Rubik", sans-serif'}}>
          <div style={{display:"flex", flexDirection:"row", alignItems:"center"}}>
            <div style={{fontWeight:"bold", fontSize:10, lineHeight:"18px", textAlign:"center", color:"white", width:80, height:18, backgroundColor:"#27005b", borderRadius:9}}>
              {t("World map")}
            </div>
            <div style={{width:10}}/>
            <div className={" WorldMapInput " + (this.state.WorldMapInputactive ? " Active " : "")}>
              {countryName ?
                <FontAwesomeIcon icon={faTimes} color="#242424" style={{marginLeft:8, fontSize:12, marginRight:8}} onClick={() => {this.resetCountry();document.getElementById("countrySearch").value="";}}/>
              :
                <FontAwesomeIcon icon={faSearch} color="#242424" style={{fontSize:12, marginRight:8}} />
              }
              <input id="countrySearch" onFocus={() => this.setState({WorldMapInputactive:true})} onBlur={() => this.setState({WorldMapInputactive:false})} onKeyDown={e => e.key === "Enter" && this.searchForCountry()} style={{flexGrow:1}} placeholder={t("Search country")} className="maskedInput"/>
              <div onClick={evt => {evt.stopPropagation(); this.searchForCountry()}} className="WorldMapInputButton" style={{cursor:"pointer", height:18, width:19, paddingRight:1, borderRadius:"50%", fontSize:8, display:"flex", alignItems:"center", justifyContent:"center", opacity:((!countryName || this.state.WorldMapInputactive) ? 1 : 0.1)}}>
                <FontAwesomeIcon icon={faArrowRight}/>
              </div>
            </div>
          </div>
          
          <div style={{height:14}}/>
          
          <div style={{height:((Math.min(500, window.innerWidth) - 20) * 180 / 280), backgroundColor:"#f7f7f7", position:"relative", overflow:"auto"}}>
            <WorldChart data={this.props.countryAnalytics}/>
            {countryName ?
              <div style={{position:"absolute", width:"100%", bottom:10, textAlign:"center"}}>{countryName}</div>
            : null}
          </div>
          <div style={{height:50, display:"flex", flexDirection:"column", justifyContent:"center"}}>
            {countryName ?
              zoomedCountry ?
                <div style={{display:"flex", flexDirection:"row", justifyContent:"space-around", alignItems:"center"}}>
                  {Object.values(EMOTION_META).map(({id, title, color}) => <div className="LegendItem" style={{display:"inline-block"}} key={title}>
                    <div className="LegendCircle" style={{backgroundColor:color}}/>
                    <div className="LegendLabel" style={{textAlign:"center"}}>{t(title)}<br/>({Math.trunc((zoomedCountry[id] / zoomedCountry.total)*100) || 0}%)</div>
                  </div>)}
                </div>
              :
              <div style={{textAlign:"center", fontSize:12, paddingTop:7.5, paddingBottom:7.5, color:"#242424"}}>
                {t("No Emotions From #COUNTRY Yet").replace(/#COUNTRY/gi, countryName)}
              </div>
            :
              <div style={{textAlign:"center", fontSize:12, paddingTop:7.5, paddingBottom:7.5, color:"#242424"}}>
                {t("Showing Most Powerful Emotions by Country")}
              </div>
            }
          </div>
        </div>
        
        <div style={{backgroundColor:"#41017b", paddingTop:10}}>
          
          <div style={{height:25, display:"flex", alignItems:"center", justifyContent:"center", color:"white"}}>
            <div style={{paddingRight:20, width:"25%", textAlign:"right"}} onClick={this.previousLineChart}><FontAwesomeIcon icon={faChevronLeft}/></div>
            <div style={{width:"50%", textAlign:"center"}}>
            {charts[this.state.timeReport].title}
            </div>
            <div style={{paddingLeft:20, width:"25%", textAlign:"left"}} onClick={this.nextLineChart}><FontAwesomeIcon icon={faChevronRight}/></div>
          </div>
  
          <EmotionLineChart textColor="white" {...charts[timeReport]} date={new Date()} chartType="area" height={250} stacked={false} gradient={false}/>
        </div>
        
        <div style={{display:"flex", flexDirection:"row", justifyContent:"center", paddingTop:15}}>
          {/*<div style={{width:"50%", paddingLeft:24, paddingRight:5}}>
            <div style={{paddingBottom:5, color:"#8d8d8d", fontSize:10, textAlign:"center"}}>Gender</div>
            <div className="ReportHalfRect">
              <div style={{width:"100%", display:"flex", flexDirection:"row", justifyContent:"space-between"}}>
                <div style={{width:"calc(100%/3)"}}>
                  <FillIcon icon={faFemale} percent={25} topColor="#dadada" bottomColor="blue"/>
                  <div style={{height:1}}/>
                  <div style={{color:"#8d8d8d", fontSize:8}}>Female</div>
                </div>
                <div style={{width:"calc(100%/3)"}}>
                  <FillIcon icon={faMale} percent={50} topColor="#dadada" bottomColor="blue"/>
                  <div style={{height:1}}/>
                  <div style={{color:"#8d8d8d", fontSize:8}}>Female</div>
                </div>
                <div style={{width:"calc(100%/3)"}}>
                  <div>
                    <div style={{width:"50%"}}>
                      <FillIcon icon={faMale} percent={75} topColor="#dadada" bottomColor="blue"/>
                    </div>
                    <div style={{width:"50%"}}>
                      <FillIcon icon={faFemale} percent={75} topColor="#dadada" bottomColor="blue"/>
                    </div>
                  </div>
                  <div style={{height:1}}/>
                  <div style={{color:"#8d8d8d", fontSize:8}}>Female</div>
                </div>
              </div>
            </div>
          </div>*/}
          <div style={{width:"50%", paddingLeft:5, paddingRight:24}}>
            <div style={{paddingBottom:5, color:"#8d8d8d", fontSize:10, textAlign:"center"}}>{t("Main activity")}</div>
            <div className="ReportHalfRect">
              {this.props.popularActivityAnalytics && (
                primaryActivity ?
                  <div>
                    <div style={{fontWeight:"bold", fontSize:16, lineHeight:"18px"}}>{Math.trunc(primaryPercent)}%</div>
                    <div style={{height:6}}/>
                    <div style={{fontSize:12, lineHeight:"12px"}}>{t(primaryActivity)}</div>
                  </div>
                :
                <div>{t("No Data")}</div>
              )}
            </div>
          </div> 
        </div>
        <div style={{height:15}}/>
      </PhoneView>
    );
  }
}

export default withTracker(() => {
  let liveHandle = Meteor.subscribe("liveData");
  let graphHandleD = Meteor.subscribe("analytics:daily");
  let graphHandleH = Meteor.subscribe("analytics:hourly");
  let graphHandleM = Meteor.subscribe("analytics:minutely");
  let graphHandleC = Meteor.subscribe("analytics:countries");
  Meteor.subscribe("analytics:popularActivity");
  
  let countryAnalytics = Analytics.find({type:"country"}).fetch();
  let dailyAnalytics = Analytics.find({type:"daily"}, {sort:{startDate:1}}).fetch();
  let hourlyAnalytics = Analytics.find({type:"hourly"}, {sort:{startDate:1}}).fetch();
  let minutelyAnalytics = Analytics.find({type:"minutely"}, {sort:{startDate:1}}).fetch();
  let popularActivityAnalytics = Analytics.findOne({type:"popularActivity"});
  
  return {
    liveData:EmotionalData.find({}, {sort:{date:-1}}).fetch(),
    dailyAnalytics, hourlyAnalytics, minutelyAnalytics, countryAnalytics,
    loading:(!graphHandleC.ready() || !graphHandleD.ready() || !graphHandleH.ready() || !graphHandleM.ready()),
    popularActivityAnalytics
  };
})(Info);
