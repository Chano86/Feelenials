import React from 'react';

import SwitchLanguageButton from './SwitchLanguageButton';
import PhoneView from './FlatUI/PhoneView';

import t from './t.js';

class CookieDisclaimer extends React.Component {
    
    state = {
        showDetails:false
    }
    
    continue = () => {
        window.localStorage.setItem("cookieConsent", 1);
        window.localStorage.setItem("gameCookieConsent", "true");
        window.location.reload();
    }
    
    render() {
        return <PhoneView>
            <div className="V2Content" style={{display:"flex", flexDirection:"column", justifyContent:"center", height:"100%"}}>
                <div className="V2Title">
                    {t("Welcome to GoodFeelis")}<br/>
                </div>

                <div className="V2Subtitle" style={{maxWidth:"none"}}>
                    {t("By clicking the button below, you agree to GoodFeelis' use of essential cookies")}
                </div>
                
                <button onClick={this.continue} className="V2Button">{t("Continue")}</button>
                
                <div style={{height:40}}/>

                <SwitchLanguageButton/>
            </div>
        </PhoneView>;
    }
}

export default CookieDisclaimer;