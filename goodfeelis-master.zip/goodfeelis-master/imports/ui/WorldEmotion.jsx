const MOBILE_WIDTH_CUTOFF = 800;

import React from 'react';
import { withTracker } from 'meteor/react-meteor-data';
import Chart from "react-apexcharts";
import ApexCharts from 'apexcharts';
import { check, Match } from 'meteor/check';
import moment from 'moment';
import { Tab, Tabs, TabList, TabPanel } from 'react-tabs';
import 'react-tabs/style/react-tabs.css';

import WorldChart from './WorldChart';
import LiveChart from '/imports/ui/LiveChart.jsx';
import t from './t';

const {EMOTION_META, ALLOWED_EMOTIONS} = Meteor.settings.public;

let createDateArrays = function (qty, format, mFormat, date) {
    let dates = [];
    
    while(qty !== 0) {
        qty--;
        let start = moment(date).subtract(qty, format).startOf(format);
        let end = start.clone().endOf(format);
        let label = start.format(mFormat);
        dates.push({start:start.toDate(), end:end.toDate(), label});
    }
    
    return dates;
};

let _dateArrayOptions = {
    "daily":[7, "day", (window.innerWidth <= MOBILE_WIDTH_CUTOFF ? "ddd" : "ddd")],
    "hourly":[8, "hour", (window.innerWidth <= MOBILE_WIDTH_CUTOFF ? "ha" : "h:mm a")],
    "minutely":[10, "minute", (window.innerWidth <= MOBILE_WIDTH_CUTOFF ? "h:mm a" : "h:mm a")],
    "secondly":[15, "second", (window.innerWidth <= MOBILE_WIDTH_CUTOFF ? "ss" : "h:mm:ss a")],
};

class GenericTimeSeriesChart extends React.Component {
    render() {
        let {data, series, title, height} = this.props;
        
        let chartType = "line";
        let stacked = false;
        
        return (
            <div>
            <Chart
                options={{
                    title:{
                        text:title,
                        align:"center",
                        offsetY:10,
                        style: {
                            fontSize:"20px"
                        }
                    },
                    chart: {
                        height,
                        type:chartType,
                        stacked,
                        toolbar:{
                            show:false
                        },
                        id:this.props.id,
                        group:this.props.group
                    },
                    animations: {
                        enabled: true,
                        easing: 'linear',
                        dynamicAnimation: {
                          speed: 1000
                        }
                    },                    
                    dataLabels: {
                        enabled: false,
                    },
                    stroke: {
                        curve: 'smooth'
                    },
                    xaxis: {
                        type: 'datetime',
                        max:new Date(),
                        range:1209600000,
                        // categories:chart1Categories,
                        hideOverlappingLabels:true
                    },
                    // yaxis: {
                    //     max:dataType === "live" ? 100 : undefined
                    // },
                }}
                series={series ? series : [{name:title, data}]}
                type={chartType}
                height={height}
            />
            </div>
        );        
    }
}

class EmotionLineChart extends React.Component {
    render() {
        let { gradient, data, dataType, type, title, date, chartType, stacked, height } = this.props;
        let chart1Categories = [], chart1Data = [];
        
        let analytics = data.filter(d => d.type === type);
        let options = _dateArrayOptions[type];

        analytics.forEach(a => {
            chart1Categories.push(a.category ? t(a.category) : t(moment(a.startDate).format(options[2]))); 
        });
        
        Object.keys(EMOTION_META).forEach(emotion => {
            chart1Data.push({
                name:t(EMOTION_META[emotion].title),
                data:analytics.map(a => a.value[emotion])
            });
        });
        
        try {
            check(chart1Data, [{name:String, data:[Match.OneOf({x:Number, y:Number}, Number)]}]);
        }
        catch(e) {
            console.error(e, chart1Data);
            return <h2>Cannot load this chart right now</h2>;
        }
        
        return (
            <div>
            <Chart
                options={{
                    title:{
                        align:"center",
                        offsetY:10,
                        style: {
                            fontSize:"0px",
                            color:this.props.textColor
                        }
                    },
                    chart: {
                        height,
                        type:chartType,
                        stacked,
                        toolbar:{
                            show:false
                        }
                    },
                    animations: {
                        enabled: true,
                        easing: 'linear',
                        dynamicAnimation: {
                          speed: 1000
                        }
                    },                    
                    dataLabels: {
                        enabled: false,
                        style: {
                            colors:Object.values(EMOTION_META).map(e => e.color)
                        }
                    },
                    stroke: {
                        curve: 'smooth'
                    },
                    xaxis: {
                        categories:chart1Categories,
                        hideOverlappingLabels:true,
                        labels: {
                            style: {
                                colors:"#ffffff"
                            }
                        }
                    },
                    yaxis: {
                        max:dataType === "live" ? 100 : undefined,
                        labels: {
                            style: {
                                color:"white"
                            }
                        }
                    },
                    legend: {
                        labels: {
                            colors:"white"
                        }
                    },
                    fill: gradient ? {
                        type: 'gradient',
                        gradient: {
                            shade: 'light',
                            type: "vertical",
                            shadeIntensity: 0.75,
                            inverseColors: true,
                            opacityFrom: 1,
                            opacityTo: 0,
                            stops: [0, 80, 90],
                            colorStops: []                            
                        }
                    } : {},
                }}
                series={chart1Data}
                type={chartType}
                height={height}
            />
            </div>
        );        
    }
}

export { EmotionLineChart };

class WorldEmotion extends React.Component {
    
    componentDidMount() {
        this.interval = setInterval(() => {
            this.setState({date:new Date()});
        }, 2500);
    }
    
    componentWillUnmount() {
        clearInterval(this.interval);
    }
    
    state = {
        date:new Date(),
        selectedChart:"secondly"
    }
    
    render() {
        let { liveData, countryAnalytics, analyticsData, dailyAnalytics, hourlyAnalytics, minutelyAnalytics } = this.props;
        let { selectedChart } = this.state;
        let { date } = new Date();
        
        let height = (window.innerHeight - 40) / 2 - 10; 
        
        let charts = {
            "secondly":<LiveChart/>,
            "minutely":<EmotionLineChart date={date} type="minutely" data={minutelyAnalytics} dataType="analytics" title="Emotions by Minute" chartType="area" height={height} stacked={false} gradient={true}/>,
            "hourly":<EmotionLineChart date={date} type="hourly" data={hourlyAnalytics} dataType="analytics" title="Emotions by Hour" chartType="area" height={height} stacked={false} gradient={true}/>,
            "daily":<EmotionLineChart date={date} type="daily" data={dailyAnalytics} dataType="analytics" title="Emotions by Day" chartType="area" height={height} stacked={false} gradient={true}/>
        };
        
        if(window.innerWidth <= MOBILE_WIDTH_CUTOFF) {
            return (
                <div>
                    <div id="worldChartContainer" style={{height:"50vh"}}>
                        <WorldChart data={countryAnalytics}/>
                    </div>

                    <div style={{textAlign:"center", paddingTop:20}}>
                        <div onClick={() => this.setState({selectedChart:"secondly"})} className={selectedChart === "secondly" ? "switchActive" : "switchDisabled"}>Seconds</div>
                        <div onClick={() => this.setState({selectedChart:"minutely"})} className={selectedChart === "minutely" ? "switchActive" : "switchDisabled"}>Minutes</div>
                        <div onClick={() => this.setState({selectedChart:"hourly"})} className={selectedChart === "hourly" ? "switchActive" : "switchDisabled"}>Hours</div>
                        <div onClick={() => this.setState({selectedChart:"daily"})} className={selectedChart === "daily" ? "switchActive" : "switchDisabled"}>Days</div>
                    </div>
                    
                    <div style={{padding:20}}>
                        {charts[selectedChart]}
                    </div>
                </div>                
            );
        }
        
        return (
            <div style={{padding:20}}>
                <div id="worldChartContainer" style={{height:"80vh"}}>
                    <WorldChart data={countryAnalytics}/>
                </div>
                
                <div style={{width:"50%", display:"inline-block"}}>
                    <LiveChart/>
                </div>
                <div style={{width:"50%", display:"inline-block"}}>
                    <EmotionLineChart date={date} type="minutely" data={minutelyAnalytics} title="Emotions by Minute" chartType="area" height={height} stacked={false} gradient={false}/>
                </div>
                <div style={{width:"50%", display:"inline-block"}}>
                    <EmotionLineChart date={date} type="hourly" data={hourlyAnalytics} title="Emotions by Hour" chartType="area" height={height} stacked={false} gradient={false}/>
                </div>
                <div style={{width:"50%", display:"inline-block"}}>
                    <EmotionLineChart date={date} type="daily" data={dailyAnalytics} title="Emotions by Day" chartType="area" height={height} stacked={false} gradient={false}/>
                </div>
                <div style={{width:"50%", display:"inline-block"}}>
                    <GenericTimeSeriesChart height={height} title="Community Growth" data={this.props.userGrowthAnalytics.map(({value, date}) => ({x:date.valueOf(), y:value}))}/>
                </div>
            </div>
        );
    }
}

export { GenericTimeSeriesChart };
export default WorldEmotion;