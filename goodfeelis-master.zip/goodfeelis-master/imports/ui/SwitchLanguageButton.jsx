import React from 'react';

import t, {language} from './t';

let text = t("switch-language");
const onClick = () => {
    if(language === "en") {
        window.localStorage.language = "es";
    }
    else {
        window.localStorage.language = "en";
    }
    window.location.reload();
};

let SwitchLanguageButton = () => {
    return (
        <div onClick={onClick} className="V2Subtitle" style={{textAlign:"center", maxWidth:"100%"}}><a href="#">{text}</a></div>
    );
};

export default SwitchLanguageButton;