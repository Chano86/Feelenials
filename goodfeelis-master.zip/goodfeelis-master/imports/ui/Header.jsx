import React from 'react';
import { Meteor } from 'meteor/meteor';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faLock, faCamera, faSmileBeam, faSadCry } from '@fortawesome/free-solid-svg-icons';
import { faSurprise, faSmileWink } from '@fortawesome/free-regular-svg-icons';
import { withTracker } from 'meteor/react-meteor-data';
import { withRouter } from "react-router";

import nameFormat from '/imports/api/Profiles/format.js';

const { POINTS_NAME } = Meteor.settings.public;

const PointsName = points => points === 1 ? POINTS_NAME.slice(0, -1) : POINTS_NAME;

class Points extends React.Component {
    
    state = {vibrate:false, createProfile:false}
    
    componentDidMount() {
        let gameCookieConsent = window.localStorage.getItem("gameCookieConsent");
        if(!gameCookieConsent) {
            this.setState({gameDisabled:true});
            return;
        }
        
        let profileKey = window.localStorage.getItem("profileKey");
        
        Meteor.call("getLeaderboardPosition", {profileKey}, (err, res) => {
            if(err) {
                console.error(err);
                this.setState({myLeaderboardPosition:"???"});
            }
            else {
                this.setState({myLeaderboardPosition:res.myPosition});
            }
        });
    }
    
    componentDidUpdate(oldProps) {
        if(this.props.currentUser && oldProps.currentUser) {
            if(this.props.currentUser.feelicoins > oldProps.currentUser.feelicoins) {
                this.setState({coinEarn:true, coinEarnAmount:(this.props.currentUser.feelicoins - oldProps.currentUser.feelicoins)});
                window.setTimeout(() => {
                    this.setState({coinEarn:false, coinEarnAmount:null});
                }, 1500);
                
                let {profileKey} = this.props.currentUser;
                
                Meteor.call("getLeaderboardPosition", {profileKey}, (err, res) => {
                    if(err) {
                        console.error(err);
                        this.setState({myLeaderboardPosition:"???"});
                    }
                    else {
                        this.setState({myLeaderboardPosition:res.myPosition});
                    }
                });                
            }
        }
    }
    
    createProfile = () => {
        this.setState({createProfile:true});
    }
    
    logout = () => {
        Meteor.logout();
        if(window.sessionStorage.getItem("skipAccount") === "true") {
            window.sessionStorage.removeItem("skipAccount");
            window.location.reload();
        }
    }
    
    render() {
        let points = null;
        
        let { currentUser } = this.props;
        
        let { coinEarn, coinEarnAmount, createProfile } = this.state;
        
        let options = {};
        options.showCapture = this.props.showCapture || false;
        
        return (
            <React.Fragment>
                <div className="FeelenialsHeader">
                    <img onClick={() => window.location.href="https://landing.feelenials.com/"} className="FeelenialsHeaderLogo" src="/logo-white.png"/>
                    {currentUser ?
                        <div onClick={() => this.props.history.push("/leaderboard")} className={" HeaderPointsText " + (coinEarn ? " CoinEarn " : "")}>
                            {coinEarn ? <div className="DisappearUpwards">+{coinEarnAmount}</div> : null}
                            <div style={{height:"2em"}}>
                                <div className={" pointsCount " + (coinEarn ? " Vibrate " : "")}><div>{currentUser.feelicoins || 0}</div></div>
                                &nbsp;&nbsp;
                                <div className={" greenPointsCount "}><div>{currentUser.wisdom || 0}</div></div>
                            </div>
                        </div>        
                    : null}
                    <div className="FeelenialsHeaderButtons">
                        <div className="FeelenialsHeaderButton RetakePhotoButton" onClick={this.logout}>
                          <label>
                            {window.innerWidth <= 500 ? <FontAwesomeIcon icon={faLock} fixedWidth={true}/> : "Logout"}
                          </label>
                        </div>
                        {options.showCapture ?
                            <div className="FeelenialsHeaderButton RetakePhotoButton" onClick={() => this.props.history.push("/")}>
                              <label>
                                {window.innerWidth <= 500 ? <FontAwesomeIcon icon={faSmileWink} fixedWidth={true}/> : "Capture Another Photo"}
                              </label>
                            </div>
                        : null}
                    </div>
                </div>
            </React.Fragment>
        );        
    }
};

export default withRouter((withTracker(props => {
    
    return {
        currentUser:Meteor.user()
    };
    
})(Points)));