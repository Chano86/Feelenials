import React from 'react';
import { withTracker } from 'meteor/react-meteor-data';
import { ReactiveVar } from 'meteor/reactive-var';

import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faSmileWink, faChartBar, faQuestionCircle } from '@fortawesome/free-regular-svg-icons';
import { faSync, faTimes, faCheck, faHome, faTrophy, faLock, faCogs } from '@fortawesome/free-solid-svg-icons';

import Profiles from '/imports/api/Profiles/Profiles';
import reportError, { ErrorBoundary } from '/imports/api/client/reportError.js';
import {
  BrowserRouter as Router,
  Switch,
  Route,
  Link,
  withRouter
} from "react-router-dom";
import { createBrowserHistory } from 'history';

import enableNotifications from './push.js';
import Admin from './Admin.jsx';
import ResearchCampaignAdmin from './ResearchCampaignAdmin.jsx';
import TownSelect from './TownSelect.jsx';
import PhoneView from './FlatUI/PhoneView';
import Splash from './Splash.jsx';
import SocioeconomicData from './SocioeconomicData.jsx';
import Roulette from './UploadNew.jsx';
import Report from './Report.jsx';
import PersonalReport from './PersonalReport.jsx';
import SignUp from './SignUp.jsx';
import DataList from './DataList.jsx';
import LiveChart from './LiveChart.jsx';
import Leaderboard from './Leaderboard.jsx';
import Home from './Home.jsx';
import Settings from './Settings.jsx';
import CookieDisclaimer from './CookieDisclaimer.jsx';
import Register from './Accounts/Register.jsx';
import Login from './Accounts/Login.jsx';
import ResetPassword from './Accounts/ResetPassword.jsx';
import {language} from './t';

let ProfileKey = new ReactiveVar(null);
let LoggingInHold = new ReactiveVar(false);

export { LoggingInHold };

let zehidden = false;
const DESKTOP_PATHS = ["/data-list", "/rsa", "/mngmnt"];

let _tabs = [
  {
    path:"/home",
    link:"/home",
    icon:faHome
  },
  {
    path:"/",
    link:"/",
    icon:faSmileWink
  },
  {
    path:/\/report*/,
    link:"/report/global",
    icon:faChartBar
  },
  {
    path:"/leaderboard",
    link:"/leaderboard",
    icon:faTrophy,
    pointsBadge:true
  },
  {
    path:"/settings",
    link:"/settings",
    icon:faCogs
  },  
  {
    path:"/support",
    onClick:() => window.zE.activate({hideOnClose:true}),
    icon:faQuestionCircle
  },
]

let Tabs = withRouter(({history, location, currentUser}) => {
  let {pathname} = location;
  
  let width = (100 / _tabs.length);
  
  return <div style={{height:50, display:"flex", flexDirection:"row", justifyContent:"space-evenly", alignItems:"center"}}>
    {_tabs.map(({path, link, icon, onClick, pointsBadge}) => {
      let isActive = typeof(path) === "string" ? pathname === path : path.test(pathname);
      
      return <div onClick={onClick ? onClick : () => history.push(link)} style={{display:"flex", justifyContent:"center", alignItems:"center", height:"100%", fontSize:25, borderTop:(isActive ? "1px #41017b solid" : "1px #eee solid"), color:(isActive ? "#41017b" : "#dadada"), width:(width + "%"), textAlign:"center"}}>
        <div style={{display:"inline-block"}}>
          <FontAwesomeIcon icon={icon}/>
          {(pointsBadge && currentUser && currentUser.wisdom && currentUser.wisdom > 0) && <div style={{position:"relative"}}>
            <div style={{backgroundColor:"#41017b", fontSize:12, color:"white", paddingLeft:5, paddingRight:5, position:"absolute", borderRadius:10, opacity:0.7, bottom:-2.5, right:-5}}>
              {currentUser ? currentUser.wisdom : 0}
            </div>
          </div>}
        </div>
      </div>
    })}
  </div>;
});

class App extends React.Component {
  
  history = createBrowserHistory();
  
  state = {
    skipAccount:window.sessionStorage.getItem("skipAccount") === "true"
  }
  
  skipAccount = () => {
    window.sessionStorage.setItem("skipAccount", "true");
    this.setState({skipAccount:true});
  }
  
  notfs = () => {
    let sp = new window.URLSearchParams(window.location.search);
    let isNative = sp.get("native") === "1";
    
    if(isNative) {
      this.setState({native:true});
      window.isNative = true;
      
      let fcmToken = sp.get("fcmToken");
      
      if(!fcmToken) {
        this.setState({notificationsRejected:true});
        window.notificationsRejected = true;
      }
      else {
        Meteor.call("saveNativePushToken", fcmToken, language || "en", () => {
          this.setState({notificationsEnabled:true});          
        });
      }        
    }
    else {
      enableNotifications();
    }    
  }
  
  componentDidMount() {
    if(this.props.currentUser) {
      this.hasPromptedNotf = true;
      this.notfs();
    }
  }
  
  componentDidUpdate(oldProps) {
    if(this.props.currentUser && !this.hasPromptedNotf) {
      this.hasPromptedNotf = true;
      this.notfs();
    }
  }
  
  hasPromptedNotf = false;
  
  createGameId = () => {
    let profileKey = window.localStorage.getItem("profileKey");
    
    if(!profileKey) {
      Meteor.call("profiles:register", (err, res) => {
        if(err) {
          alert("Unable to create your anonymous player profile: " + err.reason);
        }
        else {
          window.localStorage.setItem("profileKey", res.profileKey);
          ProfileKey.set(res.profileKey);
        }
      });
    }
    else {
      ProfileKey.set(profileKey);
    }    
  }
  
  router = () => {
    if(!zehidden) {
      window.zE('webWidget', 'hide');
      zehidden = true;
    }
    
    return <Router history={this.history}>
      <div style={{height:"calc(100% - 50px)", overflow:"auto"}}>
        <Switch>
          <Route path="/report/personal" component={PersonalReport}/>
          <Route path="/report/global" render={p => <Report {...this.props} {...p}/>}/>
          <Route path="/leaderboard" render={p => <Leaderboard {...this.props} {...p}/>}/>
          <Route path="/roulette" render={p => <Roulette {...this.props} {...p}/>}/>
          <Route path="/live-chart" render={p => <LiveChart {...this.props} {...p}/>}/>
          <Route path="/dashboard" render={p => <Dashboard {...this.props} {...p}/>}/>
          <Route path="/report" render={p => <Report {...this.props} {...p}/>}/>
          <Route path="/home" render={p => <Home {...this.props} {...p}/>}/>
          <Route path="/sed" render={p => <SocioeconomicData {...this.props} {...p}/>}/>
          <Route path="/settings" render={p => <Settings {...this.props} {...p}/>}/>
          <Route path="/reset-password" component={ResetPassword}/>
          <Route path="/data-list" render={p => <DataList {...this.props} {...p}/>}/>
          <Route path="/rsa" render={p => <ResearchCampaignAdmin {...this.props} {...p}/>}/>
          <Route path="/mngmnt" component={Admin}/>
          <Route path="/register/:code" render={p => <Register createAccount={true} {...this.props} {...p}/>}/>
          <Route path="/r/:code" render={p => <Register createAccount={true} {...this.props} {...p}/>}/>
          <Route path="/" render={p => <Roulette {...this.props} {...p}/>}/>
        </Switch>
      </div>
      <Tabs {...this.props}/>
    </Router>;
  }
  
  render() {
    let {loggingIn, loggingInHold} = this.props, {pathname} = window.location, demographicData = null, parsed = null;
    let cookieConsent = window.localStorage.getItem("cookieConsent");
    
    if(!cookieConsent) {
      return <CookieDisclaimer/>;
    }
    
    if(loggingIn && !loggingInHold) {
      return <Splash/>; // TODO Loader
    }
    
    demographicData = window.localStorage.getItem("demographicData");
    try {
      parsed = JSON.parse(demographicData);
    }
    catch(e) {
      parsed = null;
    }
    
    let collectDemographicData = demographicData === null || parsed === null || parsed.v !== "2";
  
    if(!this.props.currentUser && !this.state.skipAccount) {
      
      return <Router>
        <Switch>
          <Route path="/register" render={p => <Register collectDemographicData={collectDemographicData} createAccount={true} {...this.props}/>}/>
          <Route path="/register/:code" render={p => <Register collectDemographicData={collectDemographicData} createAccount={true} {...this.props} {...p}/>}/>
          <Route path="/r/:code" render={p => <Register collectDemographicData={collectDemographicData} createAccount={true} {...this.props} {...p}/>}/>
          <Route path="/reset-password" render={p => <ResetPassword/>}/>
          <Route render={p => <Login onSkip={this.skipAccount} {...this.props}/>}/>
        </Switch>      
      </Router>;
    }
    
    if(collectDemographicData) {
      if(this.props.currentUser && this.props.currentUser.demographicData) {
        window.localStorage.setItem("demographicData", JSON.stringify(this.props.currentUser.demographicData));
        demographicData = this.props.currentUser.demographicData;
      }
      else {
        return <SignUp/>;
      }
    }
    
    if(typeof(demographicData) !== "object") {
      try {
        demographicData = JSON.parse(demographicData);
      }
      catch(e) {
        console.error(e);
      }
    }
    
    if(this.props.currentUser && !this.props.currentUser.demographicData) {
      console.log(demographicData);
      Meteor.call("setDemographicData", demographicData);
    }
    
    if(this.props.currentUser && !this.props.currentUser.hasSED && !window.sessionStorage.skipSED && !Meteor.settings.public.skipSED) {
      return <PhoneView><SocioeconomicData showSkip={true}/></PhoneView>
    }
    
    if(this.props.currentUser && (!this.props.currentUser.city || !this.props.currentUser.state) && !window.localStorage.skipCity && !Meteor.settings.public.skipCity) {
      return <PhoneView><TownSelect/></PhoneView>;
    }
    
    if(DESKTOP_PATHS.includes(this.history.location.pathname)) {
      return this.router();
    }
    
    return (
      <PhoneView>
        {this.router()}
        {this.state.native && <div style={{position:"fixed", bottom:10, left:10, width:200, backgroundColor:(this.state.notificationsEnabled ? "green" : (this.state.notificationsRejected ? "red" : "#eee")), padding:10}}>
          {(!this.state.notificationsEnabled && !this.state.notificationsRejected) ?
            <div style={{color:"#121212"}}><FontAwesomeIcon icon={faSync} spin/> Enabling notifications...</div>
          :
            this.state.notificationsEnabled ?
              <div style={{color:"white"}}><FontAwesomeIcon icon={faCheck}/> Notifications Ready!</div>
              :
              <div style={{color:"white"}}><FontAwesomeIcon icon={faTimes}/> Notifications Error</div>
          }
        </div>}
      </PhoneView>
    );
  }
}

export default withTracker(() => {
  let gameCookieConsent = window.localStorage.getItem("gameCookieConsent");
  
  let profileKey = ProfileKey.get(), handle, myProfile;
  
  if(profileKey && gameCookieConsent) {
    handle = Meteor.subscribe("myProfile", profileKey);
    myProfile = Profiles.findOne({profileKey});
  }
  
  return {
    profileLoading:(handle ? !handle.ready() : true),
    myProfile,
    loggingIn:Meteor.loggingIn(),
    currentUser:Meteor.user(),
    loggingInHold:LoggingInHold.get()
  };
  
})(props => {
  return (
    <ErrorBoundary>
      <App {...props}/>
    </ErrorBoundary>
  );
});

import './push.js';