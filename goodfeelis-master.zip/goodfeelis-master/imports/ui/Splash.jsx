import React from 'react';

import PhoneView from './FlatUI/PhoneView';

let Splash = () => (
    <PhoneView>
        <div style={{width:"100%", height:"100%", background:"linear-gradient(to bottom, #7500e5, #27005b)", display:"flex", alignItems:"center", justifyContent:"center"}}>
            <img style={{width:350, maxWidth:"80%"}} src="/goodfeelis-white.png"/>
        </div>
    </PhoneView>
);

export default Splash;