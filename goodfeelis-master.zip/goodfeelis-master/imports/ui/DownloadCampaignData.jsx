import React from 'react';

const flattenObject = function (obj, prefix="") {
    let entries = Object.entries(obj).map(([a,b]) => ([prefix + a,b]));
    
    let columns = [];

    entries.forEach((entry, I) => {
        if(entry[1] instanceof Date) {
            entry[1] = entry[1].toString();
            columns.push(entry);
        }
        else {
            if(typeof(entry[1]) === "object") {
                columns = columns.concat(flattenObject(entry[1], entry[0] + "-"));
            }
            else {
                columns.push(entry);
            }
        }
    });
    
    return columns;
}

class DownloadCampaignData extends React.Component {
    state = {progress:0};
    
    download = () => {
        this.setState({progress:1, progressMessage:"Downloading data..."});
        Meteor.call("downloadCampaignData", this.props.campaignId, (err, res) => {
            if(err) {
                alert(err.reason);
                this.setState({progress:null});
            }
            else {
                let data = res, progress=1;
                this.setState({progress, progressMax:(data.length + 10), progressMessage:"Exporting data to CSV..."});
                
                
                let rows = [flattenObject(data[0]).map(a => a[0]).join(",")];
                data.forEach(item => {
                    rows.push(flattenObject(item).map(a => a[1]).join(","))
                    progress++;
                    this.setState({progress});
                });
                
                progress += 5;
                
                this.setState({progress, progressMessage:"Creating csv file..."});
                
                const csvText = rows.join("\n");
                
                progress += 4;
                
                this.setState({progress, progressMessage:"Downloading file..."});
                
                const a = document.createElement("a");
                a.href= "data:csv/utf-8;" + encodeURI(csvText);
                a.download = "export.csv";
                
                a.click();
                
                this.setState({progress:this.state.progressMax, progressMessage:"Export complete!"});
            }
        });
    }
    
    render() {
        if(!this.state.progress) {
            return <div>
                {/*<div>
                    <label>From <input id="startDate" type="date"/></label>
                </div>
                <div>
                    <label>To <input id="startDate" type="date"/></label>
                </div>*/}
                <button onClick={this.download}>Download as CSV</button>
            </div>
        }
        
        return <div style={{padding:20}}>
            <progress value={this.state.progress} max={this.state.progressMax || 100}/>
            <div>{this.state.progressMessage}</div>
        </div>
    }
}

export default DownloadCampaignData;