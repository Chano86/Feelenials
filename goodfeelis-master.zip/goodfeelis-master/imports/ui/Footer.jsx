import React from 'react';
import { Meteor } from 'meteor/meteor';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faFacebook, faLinkedin, faInstagram, faTwitter } from '@fortawesome/free-brands-svg-icons';

class Footer extends React.Component {
    

    
    render() {
        return (
            <React.Fragment>
                <div className="FeelenialsFooter">
                    <a target="_blank" href="https://www.facebook.com/feelenials/" className="FooterSocialIcon" ><FontAwesomeIcon icon={faFacebook} fixedWidth/></a>
                    &nbsp;&nbsp;
                    <a target="_blank" href="https://www.linkedin.com/company/feelenials/about/" className="FooterSocialIcon" ><FontAwesomeIcon icon={faLinkedin} fixedWidth/></a>
                    &nbsp;&nbsp;
                    <a target="_blank" href="https://twitter.com/feelenials" className="FooterSocialIcon"><FontAwesomeIcon icon={faTwitter} fixedWidth/></a>
                    &nbsp;&nbsp;
                    <a target="_blank" href="https://www.instagram.com/feelenials/" className="FooterSocialIcon" ><FontAwesomeIcon icon={faInstagram} fixedWidth/></a>
                </div>
            </React.Fragment>
        );        
    }
};

export default Footer;