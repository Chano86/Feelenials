import React from 'react';
import Radio from './FlatUI/Radio';

import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faSearch, faChevronRight, faChevronLeft } from '@fortawesome/free-solid-svg-icons';


import t from './t';

let ProgressBar = ({progress}) => (
    <div style={{marginBottom:25, paddingLeft:25, paddingRight:25}}>
        <div style={{borderRadius:10, backgroundColor:"#eee", width:"100%", height:10}}>
            <div style={{borderRadius:10, backgroundColor:"#7500e5", width:progress + "%", height:10}}/>
        </div>
    </div>    
);

class SocioeconomicData extends React.Component {
    
    state = {}
    
    saveSED = () => {
        let sed = Object.assign({}, this.state);
        
        delete sed.specialGroupDraft;
        delete sed.vulnerableGroupDraft;
        delete sed.informationSourceDraft;
        delete sed.fitnessDraft;
        delete sed.foodQuantity;
        delete sed.foodQuality;
        delete sed.foodAccessibility;
        delete sed.civilStatus;
        delete sed.livingSituation;
        delete sed.pets;
        delete sed.dependencyDraft;
        delete sed.industryDraft;
        
        Meteor.call("saveSED", sed, err => {
            if(err) {
                alert(err.reason);
            }
            else {
                this.props.history.push("/");
            }
        });
        return null;
    }
    
    header = () => {
        return (
            <div style={{paddingBottom:24, fontWeight:"bold", paddingTop:30, display:"flex", flexDirection:"row", justifyContent:"center", alignItems:"center"}}>
                <div onClick={this.props.showSkip ? () => {window.sessionStorage.skipSED = "1";window.location.reload()} : () => this.props.history.goBack()} style={{width:50, fontWeight:"normal", textAlign:"left", paddingLeft:25}}>
                    {this.props.showSkip ? t("Skip") : <FontAwesomeIcon icon={faChevronLeft}/>}
                </div>
                <div style={{width:1, flexGrow:1, textAlign:"center"}}>
                    {t("Socioeconomic Data")}
                </div>
                <div style={{width:50, textAlign:"right"}}>
                </div>
            </div>            
        );
    }
    
    render() {
        
        if(!this.state.specialGroup) {
            return (
                <div style={{fontFamily:"Rubik", height:"100%", display:"flex", flexDirection:"column"}}>
                    <div style={{height:1, flexGrow:1, overflow:"auto"}}>
                        {this.header()}
                        
                        <ProgressBar progress={0}/>
                        
                        <div style={{paddingLeft:25, paddingRight:25}}>
                            <div style={{fontWeight:"bold", fontSize:18, lineHeight:"24px", color:"#41017b"}}>
                                {t("Are you part of any of these groups?")}
                            </div>
                        </div>
                        <div style={{paddingLeft:25, paddingRight:25}}>
                            <Radio
                                options={[
                                    {value:"frontlineWorker", label:t("Frontline Worker (Public Servant)")},
                                    {value:"essentialWorker", label:t("Essential Worker")},
                                    {value:"testedPositiveAsymptomatic", label:t("Tested Positive and Asymptomatic")},
                                    {value:"testedPositiveWithSymptoms", label:t("Tested Positive with Symptoms")},
                                    {value:"recoveredFromVirus", label:t("Recovered From Virus")},
                                    {value:"recoveredFromVirusSufferingEmotionallyPsychologically", label:t("Suffering Emotionally/Psychologically after Recovering From Virus")},
                                    {value:"elderlyPeople", label:t("Elderly")},
                                    {value:"caregiver", label:t("Caregiver of Children/Elderly")},
                                    {value:"None of the above", label:t("None of the above")},
                                ]}
                                onChangeValue={specialGroupDraft => this.setState({specialGroupDraft})}
                                value={this.state.specialGroupDraft}
                            />
                        </div>
                    </div>
                    <div style={{height:85, flexGrow:0, display:"flex", flexDirection:"row", alignItems:"center", justifyContent:"space-between"}}>
                        <div style={{cursor:"pointer", borderRadius:23, color:"white", display:"flex", alignItems:"center", justifyContent:"center", marginLeft:24, height:45, width:145, backgroundColor:"#dadada"}}>{t("Back")}</div>
                        
                        <div onClick={() => {
                            if(!this.state.specialGroupDraft) {
                                return alert(t("Please select an answer for the question"));
                            }
                            this.setState({specialGroup:this.state.specialGroupDraft})
                        }} style={{cursor:"pointer", borderRadius:23, color:"white", display:"flex", alignItems:"center", justifyContent:"center", marginRight:24, height:45, width:145, background:"linear-gradient(250deg, #41017b 0%, #7500e5)"}}>{t("Next")}</div>
                    </div>
                </div>
            );            
        }
        
        if(!this.state.vulnerableGroup) {
            return (
                <div style={{fontFamily:"Rubik", height:"100%", display:"flex", flexDirection:"column"}}>
                    <div style={{height:1, flexGrow:1, overflow:"auto"}}>
                        {this.header()}
                        
                        <ProgressBar progress={(1/8)*100}/>
                        
                        <div style={{paddingLeft:25, paddingRight:25}}>
                            <div style={{fontWeight:"bold", fontSize:18, lineHeight:"24px", color:"#41017b"}}>
                                {t("Are you any of these?")}
                            </div>
                        </div>
                        <div style={{paddingLeft:25, paddingRight:25}}>
                            <Radio
                                options={[
                                    {value:"domesticViolence", label:t("Victim of Domestic Violence")},
                                    {value:"disabled", label:t("Disabled")},
                                    {value:"drugAlcoholAdiction", label:t("Addicted to Alcohol or Drugs")},
                                    {value:"refugee", label:t("Refugee")},
                                    {value:"displaced", label:t("Displaced")},
                                    {value:"none", label:t("None of the above")},
                                ]}
                                onChangeValue={vulnerableGroupDraft => this.setState({vulnerableGroupDraft})}
                                value={this.state.vulnerableGroupDraft}
                            />
                        </div>
                    </div>
                    <div style={{height:85, flexGrow:0, display:"flex", flexDirection:"row", alignItems:"center", justifyContent:"space-between"}}>
                        <div style={{cursor:"pointer", borderRadius:23, color:"white", display:"flex", alignItems:"center", justifyContent:"center", marginLeft:24, height:45, width:145, backgroundColor:"#dadada"}}>{t("Back")}</div>
                        
                        <div onClick={() => {
                            if(!this.state.vulnerableGroupDraft) {
                                return alert(t("Please select an answer for the question"));
                            }
                            this.setState({vulnerableGroup:this.state.vulnerableGroupDraft})
                        }} style={{cursor:"pointer", borderRadius:23, color:"white", display:"flex", alignItems:"center", justifyContent:"center", marginRight:24, height:45, width:145, background:"linear-gradient(250deg, #41017b 0%, #7500e5)"}}>{t("Next")}</div>
                    </div>
                </div>
            );            
        }
        
        if(!this.state.informationSource) {
            return (
                <div style={{fontFamily:"Rubik", height:"100%", display:"flex", flexDirection:"column"}}>
                    <div style={{height:1, flexGrow:1, overflow:"auto"}}>
                        {this.header()}
                        
                        <ProgressBar progress={(2/8)*100}/>
                        
                        <div style={{paddingLeft:25, paddingRight:25}}>
                            <div style={{fontWeight:"bold", fontSize:18, lineHeight:"24px", color:"#41017b"}}>
                                {t("What is your primary source of information?")}
                            </div>
                        </div>
                        <div style={{paddingLeft:25, paddingRight:25}}>
                            <Radio
                                options={[
                                    {value:"radio", label:t("Radio")},
                                    {value:"tv", label:t("TV")},
                                    {value:"press", label:t("Press")},
                                    {value:"socialMedia", label:t("Social Media")},
                                    {value:"internet", label:t("Internet")},
                                ]}
                                onChangeValue={informationSourceDraft => this.setState({informationSourceDraft})}
                                value={this.state.informationSourceDraft}
                            />
                        </div>
                    </div>
                    <div style={{height:85, flexGrow:0, display:"flex", flexDirection:"row", alignItems:"center", justifyContent:"space-between"}}>
                        <div style={{cursor:"pointer", borderRadius:23, color:"white", display:"flex", alignItems:"center", justifyContent:"center", marginLeft:24, height:45, width:145, backgroundColor:"#dadada"}}>{t("Back")}</div>
                        
                        <div onClick={() => {
                            if(!this.state.informationSourceDraft) {
                                return alert(t("Please select an answer for the question"));
                            }
                            this.setState({informationSource:this.state.informationSourceDraft});
                        }} style={{cursor:"pointer", borderRadius:23, color:"white", display:"flex", alignItems:"center", justifyContent:"center", marginRight:24, height:45, width:145, background:"linear-gradient(250deg, #41017b 0%, #7500e5)"}}>{t("Next")}</div>
                    </div>
                </div>
            );            
        }
        
        if(!this.state.fitness) {
            return (
                <div style={{fontFamily:"Rubik", height:"100%", display:"flex", flexDirection:"column"}}>
                    <div style={{height:1, flexGrow:1, overflow:"auto"}}>
                        {this.header()}
                        
                        <ProgressBar progress={(3/8)*100}/>
                        
                        <div style={{paddingLeft:25, paddingRight:25}}>
                            <div style={{fontWeight:"bold", fontSize:18, lineHeight:"24px", color:"#41017b"}}>
                                {t("Fitness")}
                            </div>
                        </div>
                        <div style={{paddingLeft:25, paddingRight:25}}>
                            <Radio
                                options={[
                                    {value:"never", label:t("Never Exercised")},
                                    {value:"exercisedBeforeExercisingNow", label:t("Exercised Before Quarantine, And Continuing To Exercise")},
                                    {value:"exercisedBeforeButNotExercisingNow", label:t("Exercised Before Quarantine, But Not Exercising Anymore")},
                                    {value:"didNotExerciseBeforeButExercisingNow", label:t("Didn't Exercise Before Quarantine, But Exercising Now")},
                                ]}
                                onChangeValue={fitnessDraft => this.setState({fitnessDraft})}
                                value={this.state.fitnessDraft}
                            />
                        </div>
                    </div>
                    <div style={{height:85, flexGrow:0, display:"flex", flexDirection:"row", alignItems:"center", justifyContent:"space-between"}}>
                        <div style={{cursor:"pointer", borderRadius:23, color:"white", display:"flex", alignItems:"center", justifyContent:"center", marginLeft:24, height:45, width:145, backgroundColor:"#dadada"}}>{t("Back")}</div>
                        
                        <div onClick={() => {
                            if(!this.state.fitnessDraft) {
                                return alert(t("Please select an answer for the question"));
                            }
                            this.setState({fitness:this.state.fitnessDraft});
                        }} style={{cursor:"pointer", borderRadius:23, color:"white", display:"flex", alignItems:"center", justifyContent:"center", marginRight:24, height:45, width:145, background:"linear-gradient(250deg, #41017b 0%, #7500e5)"}}>{t("Next")}</div>
                    </div>
                </div>
            );            
        }
        
        if(!this.state.nutrition) {
            return (
                <div style={{fontFamily:"Rubik", height:"100%", display:"flex", flexDirection:"column"}}>
                    <div style={{height:1, flexGrow:1, overflow:"auto"}}>
                        {this.header()}
                        
                        <ProgressBar progress={(4/8)*100}/>
                        
                        <div style={{paddingLeft:25, paddingRight:25}}>
                            <div style={{fontWeight:"bold", fontSize:18, lineHeight:"24px", color:"#41017b"}}>
                                {t("Nutrition")}
                            </div>
                        </div>
                        <div style={{height:20}}/>
                        <div style={{paddingLeft:25, paddingRight:25}}>
                            <div style={{fontSize:16, color:"#242424"}}>{t("Food Quality")}</div>
                            <Radio
                                options={[
                                    {value:"high", label:t("High")},
                                    {value:"medium", label:t("Medium")},
                                    {value:"low", label:t("Low")},
                                ]}
                                onChangeValue={foodQuality => this.setState({foodQuality})}
                                value={this.state.foodQuality}
                            />
                        </div>
                        <div style={{paddingLeft:25, paddingRight:25}}>
                            <div style={{fontSize:16, color:"#242424"}}>{t("Food Quantity")}</div>
                            <Radio
                                options={[
                                    {value:"more", label:t("More then normal")},
                                    {value:"same", label:t("Same as normal")},
                                    {value:"less", label:t("Less then normal")},
                                ]}
                                onChangeValue={foodQuantity => this.setState({foodQuantity})}
                                value={this.state.foodQuantity}
                            />
                        </div>
                        <div style={{paddingLeft:25, paddingRight:25}}>
                            <div style={{fontSize:16, color:"#242424"}}>{t("Food Accessibility")}</div>
                            <Radio
                                options={[
                                    {value:"easy", label:t("Easy to access")},
                                    {value:"hard", label:t("Hard to access")},
                                ]}
                                onChangeValue={foodAccessibility => this.setState({foodAccessibility})}
                                value={this.state.foodAccessibility}
                            />
                        </div>                        
                    </div>
                    <div style={{height:85, flexGrow:0, display:"flex", flexDirection:"row", alignItems:"center", justifyContent:"space-between"}}>
                        <div style={{cursor:"pointer", borderRadius:23, color:"white", display:"flex", alignItems:"center", justifyContent:"center", marginLeft:24, height:45, width:145, backgroundColor:"#dadada"}}>{t("Back")}</div>
                        
                        <div onClick={() => {
                            let {foodAccessibility, foodQuantity, foodQuality} = this.state;
                            if(!foodAccessibility || !foodQuality || !foodQuantity) {
                                return alert(t("Please select an answer for every question"));
                            }
                            
                            let nutrition = {foodAccessibility, foodQuantity, foodQuality};
                            this.setState({nutrition});
                        }} style={{cursor:"pointer", borderRadius:23, color:"white", display:"flex", alignItems:"center", justifyContent:"center", marginRight:24, height:45, width:145, background:"linear-gradient(250deg, #41017b 0%, #7500e5)"}}>{t("Next")}</div>
                    </div>
                </div>
            );            
        }  
        
        if(!this.state.household) {
            return (
                <div style={{fontFamily:"Rubik", height:"100%", display:"flex", flexDirection:"column"}}>
                    <div style={{height:1, flexGrow:1, overflow:"auto"}}>
                        {this.header()}
                        
                        <ProgressBar progress={(5/8)*100}/>
                        
                        <div style={{paddingLeft:25, paddingRight:25}}>
                            <div style={{fontWeight:"bold", fontSize:18, lineHeight:"24px", color:"#41017b"}}>
                                {t("Household")}
                            </div>
                        </div>
                        <div style={{height:20}}/>
                        <div style={{paddingLeft:25, paddingRight:25}}>
                            <div style={{fontSize:16, color:"#242424"}}>{t("Civil Status")}</div>
                            <Radio
                                options={[
                                    {value:"single", label:t("Single")},
                                    {value:"partnered", label:t("In a Relationship")},
                                    {value:"openRelationship", label:t("In an Open Relationship")},
                                    {value:"married", label:t("Married")},
                                    {value:"divorced", label:t("Divorced")},
                                    {value:"widowed", label:t("Widowed")},
                                ]}
                                onChangeValue={civilStatus => this.setState({civilStatus})}
                                value={this.state.civilStatus}
                            />
                        </div>
                        <div style={{paddingLeft:25, paddingRight:25}}>
                            <div style={{fontSize:16, color:"#242424"}}>{t("Living Situation")}</div>
                            <Radio
                                options={[
                                    {value:"alone", label:t("Alone")},
                                    {value:"withPartner", label:t("With Partner")},
                                    {value:"withFamily", label:t("With Family")},
                                    {value:"withFriends", label:t("With Friends")},
                                ]}
                                onChangeValue={livingSituation => this.setState({livingSituation})}
                                value={this.state.livingSituation}
                            />
                        </div>
                        <div style={{paddingLeft:25, paddingRight:25}}>
                            <div style={{fontSize:16, color:"#242424"}}>{t("Pets")}</div>
                            <Radio
                                options={[
                                    {value:"none", label:t("None")},
                                    {value:"one", label:t("One")},
                                    {value:"moreThanOne", label:t("More than 1")},
                                ]}
                                onChangeValue={pets => this.setState({pets})}
                                value={this.state.pets}
                            />
                        </div>                        
                    </div>
                    <div style={{height:85, flexGrow:0, display:"flex", flexDirection:"row", alignItems:"center", justifyContent:"space-between"}}>
                        <div style={{cursor:"pointer", borderRadius:23, color:"white", display:"flex", alignItems:"center", justifyContent:"center", marginLeft:24, height:45, width:145, backgroundColor:"#dadada"}}>{t("Back")}</div>
                        
                        <div onClick={() => {
                            let {civilStatus, livingSituation, pets} = this.state;
                            if(!civilStatus || !livingSituation || !pets) {
                                return alert(t("Please select an answer for every question"));
                            }
                            
                            let household = {civilStatus, livingSituation, pets};
                            this.setState({household});
                        }} style={{cursor:"pointer", borderRadius:23, color:"white", display:"flex", alignItems:"center", justifyContent:"center", marginRight:24, height:45, width:145, background:"linear-gradient(250deg, #41017b 0%, #7500e5)"}}>{t("Next")}</div>
                    </div>
                </div>
            );            
        }
        
        if(!this.state.dependency) {
            return (
                <div style={{fontFamily:"Rubik", height:"100%", display:"flex", flexDirection:"column"}}>
                    <div style={{height:1, flexGrow:1, overflow:"auto"}}>
                        {this.header()}
                        
                        <ProgressBar progress={(6/8)*100}/>
                        
                        <div style={{paddingLeft:25, paddingRight:25}}>
                            <div style={{fontWeight:"bold", fontSize:18, lineHeight:"24px", color:"#41017b"}}>
                                {t("Do you have any dependency on others?")}
                            </div>
                        </div>
                        <div style={{paddingLeft:25, paddingRight:25}}>
                            <Radio
                                options={[
                                    {value:"none", label:t("None")},
                                    {value:"psychological", label:t("Psychological")},
                                    {value:"physical", label:t("Physical")},
                                ]}
                                onChangeValue={dependencyDraft => this.setState({dependencyDraft})}
                                value={this.state.dependencyDraft}
                            />
                        </div>
                    </div>
                    <div style={{height:85, flexGrow:0, display:"flex", flexDirection:"row", alignItems:"center", justifyContent:"space-between"}}>
                        <div style={{cursor:"pointer", borderRadius:23, color:"white", display:"flex", alignItems:"center", justifyContent:"center", marginLeft:24, height:45, width:145, backgroundColor:"#dadada"}}>{t("Back")}</div>
                        
                        <div onClick={() => {
                            if(!this.state.dependencyDraft) {
                                return alert(t("Please select an answer for the question"));
                            }
                        
                            this.setState({dependency:this.state.dependencyDraft})
                        }} style={{cursor:"pointer", borderRadius:23, color:"white", display:"flex", alignItems:"center", justifyContent:"center", marginRight:24, height:45, width:145, background:"linear-gradient(250deg, #41017b 0%, #7500e5)"}}>{t("Next")}</div>
                    </div>
                </div>
            );            
        }  
        
        if(!this.state.industry) {
            return (
                <div style={{fontFamily:"Rubik", height:"100%", display:"flex", flexDirection:"column"}}>
                    <div style={{height:1, flexGrow:1, overflow:"auto"}}>
                        {this.header()}
                        
                        <ProgressBar progress={(7/8)*100}/>
                        
                        <div style={{paddingLeft:25, paddingRight:25}}>
                            <div style={{fontWeight:"bold", fontSize:18, lineHeight:"24px", color:"#41017b"}}>
                                {t("What industry do you work in?")}
                            </div>
                        </div>
                        <div style={{paddingLeft:25, paddingRight:25}}>
                            <Radio
                                options={[
                                    {value:"agriculture", label:t("Argriculture, Farming, Plantations, Other Rural Sectors")},
                                    {value:"basicMetalProduction", label:t("Basic Metal Production")},
                                    {value:"catering", label:t("Catering")},
                                    {value:"chemicals", label:t("Chemicals")},
                                    {value:"commerce", label:t("Commerce")},
                                    {value:"construction", label:t("Construction")},
                                    {value:"eCommerce", label:t("E-Commerce")},
                                    {value:"finance", label:t("Financial Services")},
                                    {value:"food", label:t("Food/Drink")},
                                    {value:"tobaccoAlcohol", label:t("Tobacco/Alcohol")},
                                    {value:"woodPaper", label:t("Forestry, Wood, Paper")},
                                    {value:"health", label:t("Health Services")},
                                    {value:"hotelsTourisim", label:t("Hotels/Tourisim")},
                                    {value:"mining", label:t("Mining")},
                                    {value:"engineering", label:t("Mechanical/Electrical Engineering")},
                                    {value:"media", label:t("Media/Journalisim")},
                                    {value:"oil", label:t("Oil/Gas (Production, Refining, etc)")},
                                    {value:"consultancy", label:t("Professional Services/Consultancy")},
                                    {value:"telecom", label:t("Telecommunications")},
                                    {value:"postalDelivery", label:t("Postal/Delivery Services")},
                                    {value:"technology", label:t("IT/Technology")},
                                    {value:"public", label:t("Public Services/Government")},
                                    {value:"shipping", label:t("Shipping/Ports")},
                                    {value:"clothing", label:t("Textiles/Clothing/Leather")},
                                    {value:"transportation", label:t("Transportation")},
                                    {value:"other", label:t("Other")},
                                    {value:"unemployed", label:t("Unemployed")},
                                ]}
                                onChangeValue={industryDraft => this.setState({industryDraft})}
                                value={this.state.industryDraft}
                            />
                        </div>
                    </div>
                    <div style={{height:85, flexGrow:0, display:"flex", flexDirection:"row", alignItems:"center", justifyContent:"space-between"}}>
                        <div style={{cursor:"pointer", borderRadius:23, color:"white", display:"flex", alignItems:"center", justifyContent:"center", marginLeft:24, height:45, width:145, backgroundColor:"#dadada"}}>{t("Back")}</div>
                        
                        <div onClick={() => {
                            if(!this.state.industryDraft) {
                                return alert(t("Please select an answer for the question"));
                            }
                        
                            this.setState({industry:this.state.industryDraft})
                        }} style={{cursor:"pointer", borderRadius:23, color:"white", display:"flex", alignItems:"center", justifyContent:"center", marginRight:24, height:45, width:145, background:"linear-gradient(250deg, #41017b 0%, #7500e5)"}}>{t("Next")}</div>
                    </div>
                </div>
            );            
        }         
        
        
        return this.saveSED();
    }
}

export default SocioeconomicData;