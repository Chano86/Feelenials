import React, {useState} from 'react';

import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faShareAlt } from '@fortawesome/free-solid-svg-icons';
import { faFacebookF, faTwitter, faLinkedinIn } from '@fortawesome/free-brands-svg-icons';
import { withRouter } from "react-router-dom";

import t from './t';
import share from '/imports/api/client/share';

let long = `Hey Family & Friends!

I wanted to share with you how I currently feel with this coronavirus pandemic through the GoodFeelis app. I´m able to keep track of my emotions and share it for a greater social cause at the same time!

Check it out and join the community! 

#GoodFeelis #Feelenials #EmotionalHealth #EmotionalMapping`;

let short = `Remember that emotional health matters, even during a crisis. I'm able to track my emotions using www.goodfeelis.com and share it for a greater social cause at the same time. Come and join us in spreading happiness! #GoodFeelis #Feelenials #EmotionalHealth #EmotionalMapping`;

let ShareButton = withRouter(({color}) => {
    let [showSharePopup, setSharePopup] = useState(false);
    
    let shareUrlsLong = share({text:long, url:"https:///www.goodfeelis.com", title:"GoodFeelis", source:"https:///www.goodfeelis.com"});
    let shareUrlsShort = share({text:short, url:"https:///www.goodfeelis.com", title:"GoodFeelis", source:"https:///www.goodfeelis.com"});
    
    if(showSharePopup) {
        return <div style={{display:"flex", alignItems:"center", justifyContent:"center", zIndex:200, backdropFilter:"blur(12px)", backgroundColor:"rgba(39, 0, 91, 0.5)", position:"absolute", top:0, left:0, width:"100%", height:"100%"}}>
            <div onClick={() => setSharePopup(false)} style={{position:"absolute", top:30, left:25, color:"white"}}>{t("Cancel")}</div>
            <div style={{backgroundColor:"white", borderRadius:20}}>
                <div style={{paddingTop:40, paddingBottom:50, paddingLeft:30, paddingRight:30, fontFamily:"Rubik"}}>
                    <div style={{textAlign:"center", marginBottom:25, fontSize:18, fontWeight:"bold"}}>{t("Share")}</div>
                    
                    <div onClick={() => window.location.href = shareUrlsLong.facebook} style={{cursor:"pointer", fontSize:14, maxWidth:"100%", width:260, borderRadius:19, backgroundColor:"#1877f2", textAlign:"center", paddingTop:10, paddingBottom:10, color:"white"}}>
                        <FontAwesomeIcon icon={faFacebookF} style={{fontSize:12, marginRight:10}}/>{t("Share on Facebook")}
                    </div>
                    <div style={{height:20}}/>
                    <div onClick={() => window.location.href = shareUrlsShort.twitter} style={{fontSize:14, maxWidth:"100%", width:260, borderRadius:19, backgroundColor:"#1da1f2", textAlign:"center", paddingTop:10, paddingBottom:10, color:"white"}}>
                        <FontAwesomeIcon icon={faTwitter} style={{fontSize:12, marginRight:10}}/>{t("Share on Twitter")}
                    </div>
                    <div style={{height:20}}/>
                    <div onClick={() => window.location.href = shareUrlsLong.linkedin} style={{cursor:"pointer", fontSize:14, maxWidth:"100%", width:260, borderRadius:19, backgroundColor:"#0274b3", textAlign:"center", paddingTop:10, paddingBottom:10, color:"white"}}>
                        <FontAwesomeIcon icon={faLinkedinIn} style={{fontSize:12, marginRight:10}}/>{t("Share on LinkedIn")}
                    </div>

                </div>
            </div>
        </div>;
    }
    
    return <div onClick={() => setSharePopup(true)} style={{position:"absolute", top:20, right:20, height:20, width:20, fontSize:20, color:color || "white", zIndex:5}}><FontAwesomeIcon icon={faShareAlt}/></div>;
});

export default ShareButton;