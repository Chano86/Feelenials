import React from 'react';

import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faCheck } from '@fortawesome/free-solid-svg-icons';

import PhoneView from './FlatUI/PhoneView';
import t from './t.js';
import ShareButton from './ShareButton';

let feelings = [
    {name:"frustration", min:0, max:22, emotion:"anger"},
    {name:"annoyance", min:22, max:44, emotion:"anger"},
    {name:"aversion", min:44, max:66, emotion:"disgust"},
    {name:"distress", min:66, max:89, emotion:"disgust"},
    {name:"dislike", min:89, max:111, emotion:"disgust"},
    {name:"denial", min:111, max:134, emotion:"sadness"},
    {name:"depression", min:134, max:157, emotion:"sadness"},
    {name:"helplessness", min:158, max:181, emotion:"sadness"},
    {name:"despair", min:181, max:204, emotion:"sadness"},
    {name:"anxiety", min:204, max:227, emotion:"fear"},
    {name:"panic", min:227, max:249.5, emotion:"fear"},
    {name:"worry", min:249.5, max:272, emotion:"fear"},
    {name:"pride", min:272, max:294, emotion:"enjoyment"},
    {name:"joy", min:295, max:317, emotion:"enjoyment"},
    {name:"pleasure", min:317, max:338, emotion:"enjoyment"},
    {name:"fury", min:339, max:360, emotion:"anger"},
];

import {language} from './t';

let rouletteLangs = ["en", "es"];
let rouletteSrc = "/roulette-en.png";
try {
    if(rouletteLangs.includes(language)) {
        rouletteSrc = "/roulette-" + language + ".png";
    }
}
catch(e) {}


let findClosestEmotion = function (rotation) {
    let closestItem = feelings.find(e => rotation >= e.min && rotation < e.max);
    
    return closestItem ? closestItem.name : "???";
};

let Tick = () => (
    <div style={{height:16, width:16, backgroundColor:"#37fbbb", position:"absolute", top:5, right:2.5, borderRadius:16, display:"flex", alignItems:"center", justifyContent:"center", fontSize:10}}><FontAwesomeIcon icon={faCheck} color="white"/></div>
);

class HowDoYouFeel extends React.Component {
    
    state = {animate:false, rotation:0, feeling:null, emotion:"anger"}
    
    componentDidMount() {
        this.onKeyDownListener = window.addEventListener("keydown", this.onKeyDown);
        this.onResize();
        
        if(window.ResizeObserver) {
            let tlOb = new ResizeObserver(this.onResize);
            tlOb.observe(document.getElementById("EmotionPadTopSection"));
        }
        else {
            window.addEventListener("resize", this.onResize);
        }
    }
    
    onResize = () => {
        let tsElem = document.getElementById("EmotionPadTopSection")
        this.setState({
            topSectionWidth:tsElem.clientWidth,
            topSectionHeight:tsElem.clientHeight,
        });
    }
    
    // componentWillUnmount() {
    //     window.removeEventListener(this.onKeyDownListener);
    // }
    
    componentDidUpdate(oldProps, oldState) {
        if(oldState.emotionName !== this.state.emotionName) {
            window.navigator.vibrate(50);
        }
        if(oldState.rotation !== this.state.rotation) {
            this.onRotationChanged();
        }
    }
    
    snapToEmotion = () => {
        let {rotation} = this.state;
        let emotionName = findClosestEmotion(rotation);
        let emotion = feelings.find(e => e.name === emotionName);
        let center = emotion.min + ((emotion.max - emotion.min)/2);
        
        this.setState({rotation:center});
    }
    
    onTouchStart = (evt) => {
        this.setState({touchStartX:evt.touches[0].clientX});
    }
    
    onTouchMove = (evt) => {
        let {touchStartX, rotation} = this.state;
        evt.preventDefault();
        let change = evt.movementX;
        if(!change && evt.touches) {
            let newX = evt.touches[0].clientX;
            change = ((newX-touchStartX) / 1);
            this.setState({touchStartX:newX});
        }
        let newRotation = (rotation+change);
        
        if(newRotation > 360) {
            newRotation = newRotation - 360;
        }
        
        if(newRotation < 0) {
            newRotation = newRotation + 360;
        }        
        
        this.setState({rotation:newRotation});
    }
    
    onMouseMove = evt => {
        if(this.state.mouseDown) {
            this.onTouchMove(evt);
        }
    }
    
    onMouseDown = (evt) => {
        evt.stopPropagation();
        evt.preventDefault();
        this.setState({mouseDown:true});
    }

    onMouseUp = () => {
        console.log(this.state.rotation);
        this.setState({mouseDown:false});
        this.snapToEmotion();
    }
    
    onTouchEnd = () => {
        this.snapToEmotion();
    }
    
    onKeyDown = (evt) => {
        let {rotation} = this.state;
        if(evt.key === "ArrowRight") {
            rotation = rotation+1;
        }
        if(evt.key === "ArrowLeft") {
            rotation = rotation-1;
        }
        this.setState({rotation});
    }
    
    onRotationChanged = () => {
        // let {rotation} = this.state;
        // let emotionName = findClosestEmotion(rotation);
        // this.setState({emotionName});

        let feelingName = findClosestEmotion(this.state.rotation);
        let feeling = feelings.find(e => e.name === feelingName);
        if(feeling) {
            this.setState({feeling:feelingName, emotion:feeling.emotion});
        }
        this.setState({interactedWith:true});
    }
    
    save = () => {
        let {feeling, emotion} = this.state;
        
        if(!feeling || !emotion) {
            return alert("Please select an emotion");
        }
        
        let symptom = document.getElementById("symptom").value;
        let activity = document.getElementById("activity").value;
        
        if(!symptom || !activity) {
            return alert("Please select your symptom and activity");
        }
        
        let demographicData = JSON.parse(window.localStorage.getItem("demographicData"));
        
        Meteor.call("input:pad", {demographicData, value:{feeling, emotion, symptom, activity}}, err => {
            console.error(err);
            if(err && err.error != "too-many-requests") {
                alert(err.error === 500 ? "Feelenials servers are unable to handle your request right now" : err.reason);
            }
            else {
                this.props.history.push("/report");
            }
        });
    }
    
    render() {
        let {rotation, animate} = this.state;
        let {topSectionWidth, topSectionHeight} = this.state;
        
        return (
            <PhoneView>
                <ShareButton/>
                <div style={{overflow:"hidden", width:"100%", height:"100%"}}>
                    <div className="EmotionPadInputSection" style={{overflow:"auto", width:"100%"}}>
                        <div style={{minHeight:360}} className="EmotionPadTopSection" id="EmotionPadTopSection">
                            <div className="EmotionPadTitle">{t("Hi, how are you feeling right now?")}</div>
                            <div className="EmotionPadSubtitle">{t("Select the feeling you have right now")}</div>
                            <div style={{top:(topSectionHeight*0.375)-45}} className="EmotionPadArrow"><img src="/arrow-roulette@3x.png"/></div>
                            <div style={{top:(topSectionHeight*0.375)-20}} className="EmotionPadRotationHintArrow"><img src="/rotate-arrows@3x.png"/></div>
                            <div className="EmotionPadWheel" style={{top:(topSectionHeight*0.375), width:topSectionWidth, transition:(animate ? "transform ease 0.15s" : ""), transform:`rotate(${rotation}deg)`}} onTouchEnd={this.onTouchEnd} onTouchStart={this.onTouchStart} onMouseLeave={this.onMouseUp} onMouseMove={this.onMouseMove} onMouseDown={this.onMouseDown} onMouseUp={this.onMouseUp} onTouchMove={this.onTouchMove} onDrag={() => false} draggable="false"><img src={rouletteSrc}/></div>
                            <div className="EmotionPadEmoji">
                                <img src={"/wheel-emojis/" + this.state.emotion + "-emotion.svg"}/>
                            </div>
                            <div className="EmotionPadTopSectionInnerShadow"/>
                            {/*<div style={{color:"white", position:"absolute", bottom:10, right:10}}>{findClosestEmotion(rotation)} - {Math.round(rotation)}deg</div>*/}
                        </div>
                        <div className="EmotionPadMiddleSpacer"/>
                        <div className="EmotionPadBottom" id="EmotionPadBottom">
                            <div className="EmotionPadBottomLabel">
                                {t("What symptoms do you have?")}
                            </div>
                            <div className="EmotionPadInfoInput" style={{position:"relative"}}>
                                {!this.state.feeling ?
                                    <select id="symptom" disabled>
                                        <option value="">{t("Please select...")}</option>
                                    </select>                                
                                :
                                    <select id="symptom" onChange={() => this.setState({symptomSet:document.getElementById("symptom").value !== ""})}>
                                        <option value="">{t("Please select...")}</option>
                                        {Meteor.settings.public.symptoms.filter(s => s.feelings.includes(this.state.feeling)).map(({value}) => <option value={value}>{t(value)}</option>)}
                                        <option value="other">{t("Other")}</option>
                                    </select>
                                }
                                {this.state.symptomSet && <Tick/>}
                            </div>
                            
                            <div style={{height:26}}/>
                            
                            <div className="EmotionPadBottomLabel">
                                {t("What are you doing?")}
                            </div>
                            <div className="EmotionPadInfoInput" style={{position:"relative"}}>
                                {!this.state.feeling ?
                                    <select id="symptom" disabled>
                                        <option value="">{t("Please select...")}</option>
                                    </select>                                
                                :
                                    <select id="activity" onChange={() => this.setState({activitySet:document.getElementById("activity").value !== ""})}>
                                        <option value="">{t("Please select...")}</option>
                                        {Meteor.settings.public.activities.map((value) => <option value={value}>{t(value)}</option>)}
                                        <option value="other">{t("Other")}</option>
                                    </select>
                                }
                                {this.state.activitySet && <Tick/>}
                            </div>                    
                            
                            <div style={{height:26}}/>
                            
                            <button onClick={this.save} className={" EmotionPadSaveButton " + (this.state.interactedWith ? "" : " Off ")}>{t("Save Emotion")}</button>
                            
                            <div style={{height:26}}/>
                        </div>
                    </div>
                    <div id="EmotionPadCompleted" className="EmotionPadCompleted">
                        <div style={{textAlign:"center"}}>
                            {t("Emotion Saved!")}
                            <br/><br/>
                            <button onClick={() => this.props.history.push("/report")} className={" EmotionPadCompletedButton "}>{t("View World Report")}</button>
                        </div>
                    </div>
                </div>
            </PhoneView>
        );
    }
}

export default HowDoYouFeel;