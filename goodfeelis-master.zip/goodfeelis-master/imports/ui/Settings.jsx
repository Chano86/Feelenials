import React from 'react';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faIdCard, faFlag, faCheck, faEdit, faUser, faChevronLeft, faShieldAlt, faLock } from '@fortawesome/free-solid-svg-icons';

import { withTracker } from 'meteor/react-meteor-data';

import ResearchCampaigns from '/imports/api/ResearchCampaigns';
import SQs from 'meteor/ndev:security-questions';
import occupations from '/imports/api/occupations.js';
import Radio from './FlatUI/Radio';
import t from './t';

const securityQuestions = [
    "If you could have one super power what would it be?",
    "What was the name of your first pet?",
    "In what city did your parents meet?",
    "What is your favorite color?",
    "What was your favorite subject in high school?",
];

class Settings extends React.Component {
    
    state = {
        section:null,
        age:JSON.parse(window.localStorage.demographicData).age,
        occupation:JSON.parse(window.localStorage.demographicData).occupation
    };
    
    onChangeOccupation = (occupation) => {
        this.setState({occupation, changes:true, changesSaved:false});
    }
    
    onChangeAge = (evt) => {
        let age = evt.target.valueAsNumber;
        this.setState({age, changes:true, changesSaved:false});
    }    
    
    onSaveChanges = () => {
        let demographicData = JSON.parse(window.localStorage.getItem("demographicData"));
        if(this.state.age) {
            demographicData.age = this.state.age;
        }
        if(this.state.occupation) {
            demographicData.occupation = this.state.occupation;
        }
        window.localStorage.setItem("demographicData", JSON.stringify(demographicData));
        Meteor.call("setDemographicData", demographicData);
        
        this.setState({changes:false, changesSaved:true});
    }
    
    saveSecurityQuestions = () => {
        let qaPairs = [
            {q:this.state.sq1, a:document.getElementById("securityQuestion1Answer").value},
            {q:this.state.sq2, a:document.getElementById("securityQuestion2Answer").value},
        ];
        
        if(!qaPairs[0].q) {
            return alert("Please select a question for your first security question");
        }

        if(!qaPairs[1].q) {
            return alert("Please select a question for your second security question");
        }
        
        if(!qaPairs[0].a) {
            return alert("Please enter an answer for your first security question");
        }

        if(!qaPairs[1].a) {
            return alert("Please enter an answer for your second security question");
        }        

        
        SQs.setQuestions(qaPairs).then(() => {
            this.setState({changeSecurityQuestions:false});
        }).catch(e => {
            console.error(e)
            alert(e.reason);
        });
    }
    
    setNewUsername = () => {
        let newUsername = document.getElementById("newUsername").value;
        
        Meteor.call("changeUsername", newUsername, err => {
            if(err) {
                alert(t(err.reason));
            }
            else {
                this.setState({newUsername});
            }
        });
    }
    
    render() {
        let {section, occupation, age} = this.state;
        let {currentUser} = this.props;
        
        currentUser = currentUser || {};
        currentUser.campaigns = currentUser.campaigns || [];
        
        if(section === "campaigns") {
            return (
                <div style={{fontFamily:"Rubik"}}>
                    <div style={{paddingBottom:24, fontWeight:"bold", paddingTop:30, display:"flex", flexDirection:"row", justifyContent:"center", alignItems:"center"}}>
                        <div onClick={() => this.setState({section:null})} style={{width:30, textAlign:"right"}}>
                            <FontAwesomeIcon icon={faChevronLeft}/>
                        </div>
                        <div style={{width:1, flexGrow:1, textAlign:"center"}}>
                            {t("Campaigns you have joined")}
                        </div>
                        <div style={{width:30, textAlign:"right"}}>
                        </div>
                    </div>
                    <div style={{height:15}}/>
                    <div style={{paddingLeft:25, paddingRight:25}}>
                        {this.props.campaigns.map(c => (
                            <div>
                                <div style={{fontSize:24, marginBottom:5}}>{c.name}</div>
                                <div>{c.description}</div>
                            </div>
                        ))}
                    </div>
                </div>
            );              
        }

        if(section === "changeUsername") {
            return (
                <div style={{fontFamily:"Rubik"}}>
                    <div style={{paddingBottom:24, fontWeight:"bold", paddingTop:30, display:"flex", flexDirection:"row", justifyContent:"center", alignItems:"center"}}>
                        <div onClick={() => this.setState({section:null})} style={{width:30, textAlign:"right"}}>
                            <FontAwesomeIcon icon={faChevronLeft}/>
                        </div>
                        <div style={{width:1, flexGrow:1, textAlign:"center"}}>
                            {t("Change your username")}
                        </div>
                        <div style={{width:30, textAlign:"right"}}>
                        </div>
                    </div>
                    <div style={{height:15}}/>
                    <div style={{paddingLeft:25, paddingRight:25}}>
                        <div style={{fontSize:16, color:"#242424", paddingBottom:5}}>{t("Enter your new username...")}</div>
                        <div className="V2Input">
                            <input style={{fontSize:14, paddingBottom:0}} id="newUsername" type="text" className="V2InputElement"/>
                        </div>
                        
                    </div>

                    {this.state.newUsername && <div style={{marginTop:20, paddingLeft:25, paddingRight:25}}>
                        <div style={{borderRadius:20, color:"white", display:"flex", alignItems:"center", justifyContent:"center", textAlign:"center", height:45, background:"#9e9e9e"}}>
                            <FontAwesomeIcon icon={faCheck}/>&nbsp;&nbsp;{t("Your username is now #NAME").replace(/#NAME/, this.state.newUsername)}
                        </div>
                    </div>}   
                    
                    {!this.state.newUsername && <div onClick={this.setNewUsername} style={{marginTop:20, paddingLeft:25, paddingRight:25}}>
                        <div style={{borderRadius:20, cursor:"pointer", color:"white", display:"flex", alignItems:"center", justifyContent:"center", textAlign:"center", height:45, background:"linear-gradient(262deg, #41017b, #7500e5)"}}>
                            {t("Save Changes")}
                        </div>
                    </div>}
                </div>
            );              
        }

        if(section === "security") {
            return (
                <div style={{fontFamily:"Rubik"}}>
                    <div style={{paddingBottom:24, fontWeight:"bold", paddingTop:30, display:"flex", flexDirection:"row", justifyContent:"center", alignItems:"center"}}>
                        <div onClick={this.state.changeSecurityQuestions ? () => {this.setState({changeSecurityQuestions:false})} : () => this.setState({section:null})} style={{width:30, textAlign:"right"}}>
                            <FontAwesomeIcon icon={faChevronLeft}/>
                        </div>
                        <div style={{width:1, flexGrow:1, textAlign:"center"}}>
                            {t("Security")}
                        </div>
                        <div style={{width:30, textAlign:"right"}}>
                        </div>
                    </div>
                    <div style={{height:15}}/>
                    {(currentUser.securityQuestions && !this.state.changeSecurityQuestions) ?
                        <div style={{paddingLeft:25, paddingRight:25}}>
                            <div style={{fontSize:18, color:"#242424", paddingBottom:5}}>{t("Security Questions")}</div>
                            <div style={{fontSize:14, color:"#242424", paddingBottom:0}}>{t(currentUser.securityQuestions[0])}</div>
                            <div style={{height:5}}/>
                            <div style={{fontSize:14, color:"#242424", paddingBottom:0}}>{t(currentUser.securityQuestions[1])}</div>
                            <div onClick={() => this.setState({changeSecurityQuestions:true})} style={{marginTop:20, paddingLeft:0, paddingRight:0}}>
                                <div style={{borderRadius:20, cursor:"pointer", color:"white", display:"inline-flex", paddingLeft:20, paddingRight:20, alignItems:"center", justifyContent:"center", textAlign:"center", height:45, background:"linear-gradient(262deg, #41017b, #7500e5)"}}>
                                    {t("Choose New Security Questions")}
                                </div>
                            </div>                               
                        </div>
                    :
                        <div style={{paddingLeft:25, paddingRight:25}}>
                            <div style={{fontSize:20, fontWeight:"bold", color:"#242424", paddingBottom:10}}>{t("Security Question 1")}</div>
                            <div style={{fontSize:16, color:"#242424", paddingBottom:0}}>{t("Question")}</div>
                            <Radio
                                options={securityQuestions.map(o => ({value:o, label:o}))}
                                onChangeValue={sq1 => this.setState({sq1})}
                                value={this.state.sq1}
                                fullscreen={true}
                                title={t("Security Question")} 
                            />
                            <div style={{height:5}}/>
                            <div style={{fontSize:16, color:"#242424", paddingBottom:5}}>{t("Answer")}</div>
                            <div className="V2Input">
                                <input style={{fontSize:14, paddingBottom:0}} id="securityQuestion1Answer" placeholder={t("Enter your answer...")} type="text" className="V2InputElement"/>
                            </div>
                            
                            <div style={{height:25}}/>
                            
                            <div style={{fontSize:20, fontWeight:"bold", color:"#242424", paddingBottom:10}}>{t("Security Question 2")}</div>
                            <div style={{fontSize:16, color:"#242424", paddingBottom:0}}>{t("Question")}</div>
                            <Radio
                                options={securityQuestions.map(o => ({value:o, label:o}))}
                                onChangeValue={sq2 => this.setState({sq2})}
                                value={this.state.sq2}
                                fullscreen={true}
                                title={t("Security Question")} 
                            />
                            <div style={{height:5}}/>
                            <div style={{fontSize:16, color:"#242424", paddingBottom:5}}>{t("Answer")}</div>
                            <div className="V2Input">
                                <input style={{fontSize:14, paddingBottom:0}} id="securityQuestion2Answer" placeholder={t("Enter your answer...")} type="text" className="V2InputElement"/>
                            </div> 
                            
                            <div style={{height:15}}/>
                            
                            <div style={{fontSize:16, color:"#242424", paddingBottom:0}}>{t("The answers to your security questions are encrypted and cannot be read by anyone")}</div>
                            
                            <div onClick={this.saveSecurityQuestions} style={{marginTop:20}}>
                                <div style={{borderRadius:20, cursor:"pointer", color:"white", display:"flex", alignItems:"center", justifyContent:"center", textAlign:"center", height:45, background:"linear-gradient(262deg, #41017b, #7500e5)"}}>
                                    {t("Save Changes")}
                                </div>
                            </div>                        
                        </div>
                    }
                </div>
            );            
        }
        
        if(section === "profile") {
            return (
                <div style={{fontFamily:"Rubik"}}>
                    <div style={{paddingBottom:24, fontWeight:"bold", paddingTop:30, display:"flex", flexDirection:"row", justifyContent:"center", alignItems:"center"}}>
                        <div onClick={() => this.setState({section:null})} style={{width:30, textAlign:"right"}}>
                            <FontAwesomeIcon icon={faChevronLeft}/>
                        </div>
                        <div style={{width:1, flexGrow:1, textAlign:"center"}}>
                            {t("Your Profile")}
                        </div>
                        <div style={{width:30, textAlign:"right"}}>
                        </div>
                    </div>
                    <div style={{height:15}}/>
                    <div style={{paddingLeft:25, paddingRight:25}}>
                        <div style={{fontSize:16, color:"#242424", paddingBottom:5}}>{t("Occupation")}</div>
                        <Radio
                            options={occupations.map(o => ({value:o, label:t(o)}))}
                            onChangeValue={this.onChangeOccupation}
                            value={occupation}
                            fullscreen={true}
                            title={t("Occupation")}                            
                        />
                        
                        <div style={{height:10}}/>
                        
                        <div style={{fontSize:16, color:"#242424", paddingBottom:5}}>{t("Age")}</div>
                        <div className="V2Input">
                            <input onChange={this.onChangeAge} value={age} style={{fontSize:14, paddingBottom:0}} id="age" placeholder={t("Enter your age...")} type="number" className="V2InputElement"/>
                        </div>
                        
                    </div>

                    {this.state.changesSaved && <div onClick={this.onSaveChanges} style={{marginTop:20, paddingLeft:25, paddingRight:25}}>
                        <div style={{borderRadius:20, color:"white", display:"flex", alignItems:"center", justifyContent:"center", textAlign:"center", height:45, background:"#9e9e9e"}}>
                            {t("Changes Saved")}
                        </div>
                    </div>}   
                    
                    {this.state.changes && <div onClick={this.onSaveChanges} style={{marginTop:20, paddingLeft:25, paddingRight:25}}>
                        <div style={{borderRadius:20, cursor:"pointer", color:"white", display:"flex", alignItems:"center", justifyContent:"center", textAlign:"center", height:45, background:"linear-gradient(262deg, #41017b, #7500e5)"}}>
                            {t("Save Changes")}
                        </div>
                    </div>}
                </div>
            );            
        }
        
        return (
            <div style={{fontFamily:"Rubik"}}>
                <div style={{paddingBottom:24, fontWeight:"bold", paddingTop:30, display:"flex", flexDirection:"row", justifyContent:"center", alignItems:"center"}}>
                    <div style={{width:30, textAlign:"right"}}>
                    </div>
                    <div style={{width:1, flexGrow:1, textAlign:"center"}}>
                        {t("Settings")}
                    </div>
                    <div style={{width:30, textAlign:"right"}}>
                    </div>
                </div>
                <div style={{paddingLeft:25, paddingRight:25}}>
                    {currentUser && <React.Fragment>
                        <h1 style={{marginTop:0, marginBottom:10}}>{t("Hi")}, {currentUser.username}</h1>
                        <div onClick={() => this.setState({section:"profile"})} style={{paddingTop:15, paddingBottom:15, color:"#242424", flexDirection:"row", cursor:"pointer", alignItems:"center"}}>
                            <FontAwesomeIcon icon={faUser} style={{marginRight:10}}/>
                            {t("Your Profile")}
                        </div>
                        <div onClick={() => this.setState({section:"changeUsername"})} style={{paddingTop:15, paddingBottom:15, color:"#242424", flexDirection:"row", cursor:"pointer", alignItems:"center"}}>
                            <FontAwesomeIcon icon={faIdCard} style={{marginRight:10}}/>
                            {t("Change your username")}
                        </div>
                        <div onClick={() => this.setState({section:"security"})} style={{paddingTop:15, paddingBottom:15, color:"#242424", flexDirection:"row", cursor:"pointer", alignItems:"center"}}>
                            <FontAwesomeIcon icon={faShieldAlt} style={{marginRight:10}}/>
                            {t("Security")}
                        </div>
                        <div onClick={() => this.props.history.push("/sed")} style={{paddingTop:15, paddingBottom:15, color:"#242424", flexDirection:"row", cursor:"pointer", alignItems:"center"}}>
                            <FontAwesomeIcon icon={faEdit} style={{marginRight:10}}/>
                            {t("Update my SocioEconomic Data")}
                        </div>
                        {currentUser.campaigns.length > 0 && <div onClick={() => this.setState({section:"campaigns"})} style={{paddingTop:15, paddingBottom:15, color:"#242424", flexDirection:"row", cursor:"pointer", alignItems:"center"}}>
                            <FontAwesomeIcon icon={faFlag} style={{marginRight:10}}/>
                            {t("Campaigns you have joined")} {currentUser.campaigns.length > 0 ? `(${currentUser.campaigns.length})` : ""}
                        </div>}
                    </React.Fragment>}
                    <div onClick={() => {
                        Meteor.logout();
                        window.sessionStorage.clear();
                        window.localStorage.removeItem("skipSED");
                        window.location.href = currentUser ? "/" : "/register";
                    }} style={{paddingTop:15, paddingBottom:15, color:"#242424", flexDirection:"row", cursor:"pointer", alignItems:"center"}}>
                        <FontAwesomeIcon icon={faLock} style={{marginRight:10}}/>
                        {currentUser ? t("Logout") : t("Create Account")}
                    </div>
                </div>
            </div>
        );
    }
}

export default withTracker(() => {
    
    Meteor.subscribe("myCampaigns");
    
    return {
        currentUser:Meteor.user(),
        campaigns:ResearchCampaigns.find().fetch()
    };
})(Settings);