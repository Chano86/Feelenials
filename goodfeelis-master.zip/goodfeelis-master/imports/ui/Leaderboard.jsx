import React from 'react';
import { Meteor } from 'meteor/meteor';
import { withTracker } from 'meteor/react-meteor-data';

import PhoneView from './FlatUI/PhoneView';
import Splash from './Splash.jsx';
import ShareButton from './ShareButton';

import t from './t';

const { POINTS_NAME } = Meteor.settings.public;
const POINTS_NAME_SINGULAR = POINTS_NAME.slice(0, -1);
const PointsName = points => points === 1 ? POINTS_NAME.slice(0, -1) : POINTS_NAME;

let LeaderboardItem = ({position, name, points, me}) => (
    <div className={" LeaderboardItem " + (me ? " leaderboardMe " : "")}>
        <div className="LeaderboardItemPosition" style={{width:25, height:45, display:"flex", alignItems:"center", justifyContent:"center", paddingLeft:20}}>
            {position}
        </div>
        <div style={{fontWeight:"bold", flexGrow:1, paddingLeft:10}}>{name}</div>
        <div style={{justifySelf:"flex-end", paddingRight:25, color:"#41017b", fontSize:16, fontWeight:"bold"}}>{points}</div>
    </div>
);

class MyProfile extends React.Component {
    state = {myLeaderboardPosition:null, forcePrompt:false}
    
    componentDidMount() {
        let profileKey = window.localStorage.getItem("profileKey");
        
        Meteor.call("getLeaderboardPosition", {profileKey}, (err, res) => {
            if(err) {
                console.error(err);
                this.setState({myLeaderboardPosition:"???"});
            }
            else {
                this.setState({myLeaderboardPosition:res.myPosition});
            }
        });
    }
    
    render() {
        let { currentUser, leaderboard } = this.props;
        let { myLeaderboardPosition } = this.state;
        
        currentUser = currentUser || {_id:"anonymous", wisdom:0};
        
        let {wisdom} = currentUser;
        
        if(!leaderboard || leaderboard.length < 3) {
            return <Splash/>;
        }
        
        
        return (
            <PhoneView>
                <ShareButton/>
                <div style={{height:"100%"}}>
                    <div className="LeaderboardTopSection" style={{position:"relative"}}>
                        <div style={{position:"absolute", top:20, left:0, width:"100%", textAlign:"center", color:"white", fontWeight:"bold"}}>{t("Leaderboard")}</div>
                        <img style={{position:"absolute", top:0, left:0, objectFit:"cover", objectPosition:"bottom", height:"100%", width:"100%"}} src="/ray.png"/>
                        <div style={{position:"absolute", top:0, left:0, height:"100%", width:"100%", display:"flex", alignItems:"center", justifyContent:"center"}}>
                            <div>
                                <img src="1stplace.png" style={{marginBottom:-10, width:120, height:"auto"}}/>
                                <div style={{fontSize:16, fontWeight:"bold", color:"white", textAlign:"center"}}>{leaderboard[0].username}</div>
                            </div>
                        </div>
                        <div style={{position:"absolute", top:0, left:0, height:"100%", width:"50%", display:"flex", alignItems:"center", justifyContent:"center"}}>
                            <div>
                                <img src="2ndplace.png" style={{marginBottom:-10, width:80, height:"auto"}}/>
                                <div style={{fontSize:16, color:"white", textAlign:"center"}}>{leaderboard[1].username}</div>
                            </div>
                        </div>
                        <div style={{position:"absolute", top:0, right:0, height:"100%", width:"50%", display:"flex", alignItems:"center", justifyContent:"center"}}>
                            <div>
                                <img src="3rdplace.png" style={{marginBottom:-10, width:80, height:"auto"}}/>
                                <div style={{fontSize:16, color:"white", textAlign:"center"}}>{leaderboard[2].username}</div>
                            </div>
                        </div>
                    </div>
                    <div className="LeaderboardList" style={{paddingTop:10}}>
                        {leaderboard.map(({username, wisdom, _id}, index) => (
                            <LeaderboardItem position={index+1} name={_id === currentUser._id ? t("You") : username} points={wisdom} me={_id === currentUser._id}/>
                        ))}
                        {(currentUser && !leaderboard.find(p => p._id === currentUser._id)) ?
                            <LeaderboardItem me={true} position={currentUser._id !== "anonymous" ? myLeaderboardPosition : "???"} name={t("You")} points={wisdom}/>
                        : null}
                    </div>
                </div>
            </PhoneView>
        );
    }
}

export default withTracker(props => {
    Meteor.subscribe("leaderboard");
    
    return {
        leaderboard:Meteor.users.find({}, {sort:{wisdom:-1}, limit:10}).fetch(),
        currentUser:Meteor.user(),
    }
    
})(MyProfile);