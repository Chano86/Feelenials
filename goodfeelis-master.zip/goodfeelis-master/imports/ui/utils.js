let {URLSearchParams} = window;

// import { isDebug } from './utils.js';
let isDebug = () => new URLSearchParams(window.location.search).get("debug") === "1"

export { isDebug };