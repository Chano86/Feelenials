import React from 'react';
import { withTracker } from 'meteor/react-meteor-data';

import t from './t';
import ShareButton from './ShareButton';

class Home extends React.Component {
    render() {
        let {currentUser, history} = this.props;
        
        if(!currentUser) {
            currentUser = {
                username:"Anonymous"
            };
        }
        
        let dd = JSON.parse(window.localStorage.getItem("demographicData"));
        
        return (
            <div style={{backgroundColor:"#f7f7f7", height:"100%"}}>
                <ShareButton color="#7500e5"/>
                <div className="HomeTop">
                    <div style={{paddingTop:40, textAlign:"center", fontWeight:"bold"}}>{t("Home")}</div>
                    <div style={{paddingTop:25, paddingLeft:30, paddingRight:30}}>
                        <div style={{fontSize:20}}>
                            {currentUser.username}
                        </div>
                        <div style={{paddingTop:10, fontSize:12}}>
                            <span style={{color:"#8d8d8d"}}>{t("Age")}:</span>
                            &nbsp;
                            <span style={{color:"#242424"}}>{dd.age}</span>
                        </div>
                    </div>
                    <div className="HomePill" style={{display:"flex", flexDirection:"row", alignItems:"center"}}>
                        <div style={{fontSize:12, flexGrow:1, width:"50%", display:"flex", alignItems:"center", justifyContent:"center"}}>
                            {t("Feeling")}:&nbsp;<b style={{textTransform:"capitalize"}}>{t(currentUser.latestFeeling) || "???"}</b>
                        </div>
                        <div style={{height:28, flexGrow:0, width:1, backgroundColor:"#dadada"}}/>
                        <div style={{fontSize:12, flexGrow:1, width:"50%", display:"flex", alignItems:"center", justifyContent:"center"}}>
                            {t("Activity")}:&nbsp;<b style={{textTransform:"capitalize"}}>{t(currentUser.latestActivity) || "???"}</b>
                        </div>                        
                    </div>
                </div>
                <div style={{padding:14, paddingTop:25}}>
                    <div style={{backgroundColor:"#ffffff", padding:12.5}}>
                        <div style={{color:"#8d8d8d", fontSize:12}}>{t("It's important that you constantly update your emotion.")} <b>{t("Help us help you!")}</b></div>
                        <div style={{height:14}}/>
                        <div className="HomeEmopadCard" onClick={() => history.push("/")}>
                            <div style={{height:85, display:"flex", flexDirection:"row", alignItems:"center", justifyContent:"space-between"}}>
                                <div style={{paddingLeft:20, color:"white"}}>
                                    <div style={{fontSize:16, fontWeight:"bold"}}>{t("How do you feel?")}</div>
                                    <div style={{fontSize:10}}>{t("Update your emotion")}</div>
                                </div>
                                <div style={{width:"50%", display:"flex", alignItems:"center", height:"100%", overflow:"hidden"}}>
                                    <img style={{height:"225%"}} src="/mini-roulette.png"/>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div style={{height:15}}/>
                    <div style={{backgroundColor:"#ffffff", padding:12.5}}>
                        <div style={{color:"#242424", fontSize:14, fontWeight:"bold"}}>{t("See how you and your world feels!")}</div>
                        <div style={{height:12}}/>
                        <div style={{display:"flex", flexDirection:"row"}}>
                            <div onClick={() => history.push("/report/personal")} style={{width:"50%", backgroundColor:"#37fbbb", padding:10, borderRadius:10, textAlign:"center"}}>
                                <div style={{paddingBottom:10, fontSize:14, color:"#27005b", textAlign:"center", fontWeight:"bold"}}>{t("Personal Report")}</div>
                                <img src="/personal-report.svg"/>
                            </div>
                            <div style={{width:10}}/>
                            <div onClick={() => history.push("/report/global")} style={{cursor:"pointer", width:"50%", backgroundColor:"#37fbbb", padding:10, borderRadius:10, textAlign:"center"}}>
                                <div style={{paddingBottom:10, fontSize:14, color:"#27005b", textAlign:"center", fontWeight:"bold"}}>{t("Global Report")}</div>
                                <img src="/global-report.svg"/>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        );
    }
}

export default withTracker(() => {
    
    return {
        currentUser:Meteor.user()
    };
    
})(Home);