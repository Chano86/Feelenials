import React, { useEffect, useState } from "react";
import { csv } from "d3-fetch";
import { scaleLinear } from "d3-scale";
import ReactTooltip from "react-tooltip";
import {
  ComposableMap,
  Geographies,
  Geography,
  Sphere,
  Graticule, ZoomableGroup
} from "react-simple-maps";
import { geoCentroid, geoPath } from "d3-geo"

import { isDebug } from './utils.js';
import t from './t';

const HEIGHT_RATIO = 0.65;
const CHART_PADDING = 20;
const CHART_MOBILE_SCALE = 65;
const CHART_DESKTOP_SCALE = 150;

const {EMOTION_META, ALLOWED_EMOTIONS} = Meteor.settings.public;

const geoUrl =
  "https://raw.githubusercontent.com/zcreativelabs/react-simple-maps/master/topojson-maps/world-110m.json";

const colorScale = scaleLinear()
  .domain([0.29, 0.68])
  .range(["#ffedea", "#ff5233"]);

let _calculateAspectRatioFit = (srcWidth, srcHeight, maxWidth, maxHeight) => {
  var ratio = Math.min(maxWidth / srcWidth, maxHeight / srcHeight);
  return { width: srcWidth*ratio, height: srcHeight*ratio };
};

let _maintainAspectRatio = (containerHeight, containerWidth) => {
  return _calculateAspectRatioFit(800, 600, containerWidth, containerHeight);
};

class MapChart extends React.Component {
  
  state = {
    content:"",
    width:0,
    height:0,
    coords:[10,0],
    zoomed:false
  }
  
  componentDidMount() {
    this.adjustSize();
    let {width, height} = this.adjustSize();
    this.setState({width, height});
    
    window.panToCountry = (country) => {
      let c = document.getElementById(country);
      if(!c) {
        return;
      }
      
      let wmc = document.getElementById("worldChartContainer");
      
      let {width,height} = c.getBBox();
      
      let m = 0.5*Math.max(wmc.clientWidth/width, wmc.clientHeight/height);
      console.log(m);
      let zoom = Math.max(2, m);
      (zoom < 2) && (zoom = 2);
      
      let coords = JSON.parse(c.attributes.center.value);
      this.setState({coords, zoom, zoomedCountry:country});
    };
    
    window.resetWorldMapPan = () => {
      this.setState({coords:[0,0], zoom:1, zoomedCountry:null});
    };    
  }
  
  adjustSize = () => {
    let elem = document.getElementById("worldChartContainer") || window;
    return _maintainAspectRatio((elem.innerHeight || elem.clientHeight) - 40 /* compensate for title and legend */, (elem.innerWidth || elem.clientWidth));     
  }
  
  shouldComponentUpdate(nextProps, nextState) {
    let {width, height} = this.adjustSize();
    if(width !== this.state.width || height !== this.state.height) {
      return true;
    }
    
    if(nextState.content !== this.state.content) {
      return true;
    }
    
    return true;
  }
  
  componentDidUpdate() {
    if(isDebug()) {
      console.debug("WorldChart:componentDidUpdate:this.props.data", this.props.data);
    }
  }
  
  render() {
    let {data} = this.props;
    let { content, width, height } = this.state;
    
    return (
      <div id="worldChartContainer" style={{height:"100%", width:"100%"}}>
        <ComposableMap data-tip="" scale={3} id="worldChatMap" projectionConfig={{rotation:[0,0,0]}}>
          <ZoomableGroup zoom={this.state.zoom ? this.state.zoom : 1.1} center={this.state.coords}>
            <Geographies geography={geoUrl}>
              {({ geographies }) =>
                geographies.map(geo => {
                  let center = geoCentroid(geo);
                    let countryCode = geo.properties.ISO_A2;
                    let color = this.state.zoomedCountry === countryCode ? "grey" : "#dadada";
                    let emotionTitle = null;
                    let primaryEmotionPercent = null;
                    
                    let countryData = data.find(d => d.country === countryCode);
                    
                    if(countryData) {
                      let emotion = Object.keys(countryData.emotions).filter(e => EMOTION_META.hasOwnProperty(e)).sort((a,b) => countryData.emotions[b] - countryData.emotions[a])[0];
                      let totalEmotions = 0;
                      Object.values(countryData.emotions).forEach(i => {totalEmotions = totalEmotions+i;});
                      primaryEmotionPercent = Math.trunc((countryData.emotions[emotion] / totalEmotions) * 100);
                      color = EMOTION_META[emotion].color;
                      emotionTitle = t(EMOTION_META[emotion].title);
                    }
                    
                    return (
                        <Geography
                          onMouseEnter={() => {
                            const { NAME } = geo.properties;
                            this.setState({content:(emotionTitle ? `${NAME} - ${primaryEmotionPercent}% ${emotionTitle}` : NAME)});
                          }}
                          onMouseLeave={() => {
                            this.setState({content:""});
                          }}                                
                          key={geo.rsmKey}
                          geography={geo}
                          style={{"default":{stroke:"#fff", opacity:((this.state.zoomedCountry && this.state.zoomedCountry !== countryCode) && 0.3)}}}
                          fill={color}
                          id={countryCode}
                          className="mapGeo"
                          center={JSON.stringify(center)}
                        />
                    );
                })
              }
            </Geographies>
          </ZoomableGroup>
        </ComposableMap>
      </div>
    );
  }
};

/*<div>
              {Object.values(EMOTION_META).map(({title, color}) => <div className="LegendItem" style={{display:"inline-block"}} key={title}>
                <div className="LegendCircle" style={{backgroundColor:color}}/>
                <div className="LegendLabel">{title}</div>
              </div>)}
            </div>*/

export default MapChart;
