import React from 'react';

class PhoneView extends React.Component {
    
    state = {};
    
    componentDidMount() {
        this.setState({innerWidth:window.innerWidth});
        
        window.addEventListener("resize", () => {
            this.setState({innerWidth:window.innerWidth});
        });
    }
    
    render() {
        let {children} = this.props;
        let {innerWidth} = this.state;
        
        if(innerWidth > 500) {
            return <div style={{background:this.props.backgroundColor ? "transparent" : "#eee", width:"100%", height:"100%", textAlign:"center"}}>
                <div style={{position:"relative", overflowY:"auto", overflowX:"hidden", textAlign:"left", background:this.props.backgroundColor || "#fff", height:"100%", width:500, display:"inline-block"}}>{children}</div>
            </div>;
        }
        
        return children;
    }
};

export default PhoneView;