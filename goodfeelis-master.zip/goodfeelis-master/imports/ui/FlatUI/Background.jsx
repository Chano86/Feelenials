import React from 'react';

const bgStyles = {
    backgroundSize:"cover",
    backgroundRepeat:"no-repeat",
    width:"100%",
    height:"100%",
    display:"flex",
    alignItems:"center",
    justifyContent:"center"
};

let Background = ({children, color1, color2, angle1, angle2, ratio1, ratio2}) => {
    color1 = color1 || "#ab47bc";
    color2 = color2 || "#99e7d8";
    angle1 = angle1 || "160deg";
    angle2 = angle2 || "25deg";
    ratio1 = ratio1 || 50;
    ratio2 = ratio2 || 30;
    
    let bg1 = `linear-gradient(${angle1}, ${color1} 0%, ${color1} ${ratio1}%, rgba(0,0,0,0.1) ${ratio1}%, transparent ${ratio1 + 1}%)`;
    let bg2 = `linear-gradient(${angle2}, ${color2} 0%, ${color2} ${ratio2}%, rgba(0,0,0,0.1) ${ratio2}%, transparent ${ratio2 + 1}%)`;
    
    return <div style={{...bgStyles, background:bg1}}>
        <div style={{...bgStyles, background:bg2}}>
            {children}
        </div>
    </div>;
};

export default Background;