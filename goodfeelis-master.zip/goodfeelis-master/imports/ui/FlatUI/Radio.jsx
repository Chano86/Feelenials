import React from 'react';

import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faChevronRight, faChevronLeft } from '@fortawesome/free-solid-svg-icons';

import t from '../t';

class Radio extends React.Component {
    
    state = {
        isFullscren:false
    }
    
    render() {
        let {options, value:selected, onChangeValue, fullscreen} = this.props;
        
        if(fullscreen && !this.state.isFullscren) {
            return (
                <div onClick={() => this.setState({isFullscren:true})} style={{paddingTop:15, paddingBottom:15, display:"flex", flexDirection:"row"}}>
                    <div style={{width:1, flexGrow:1, color:"#8d8d8d", fontSize:14}}>
                        {!selected ? 
                            <React.Fragment>{t("Select")} {this.props.title}</React.Fragment>
                        :
                            <React.Fragment>{options.find(r => r.value === selected).label}</React.Fragment>
                        }
                    </div>
                    <div style={{width:10, fontSize:10, textAlign:"right"}}>
                        <FontAwesomeIcon icon={faChevronRight}/>
                    </div>
                </div>
            );
        }
        
        if(this.state.isFullscren) {
            return (
                <div style={{position:"absolute", top:0, left:0, width:"100%", height:"100%", background:"#fff", zIndex:2}}>
                    <div style={{paddingBottom:24, fontWeight:"bold", paddingTop:30, display:"flex", flexDirection:"row", justifyContent:"center", alignItems:"center"}}>
                        <div onClick={() => this.setState({isFullscren:false})} style={{width:30, textAlign:"right"}}>
                            <FontAwesomeIcon icon={faChevronLeft}/>
                        </div>
                        <div style={{width:1, flexGrow:1, textAlign:"center"}}>
                            {this.props.title}
                        </div>
                        <div style={{width:30, textAlign:"right"}}>
                        </div>
                    </div>    
                    <div style={{paddingLeft:25, paddingRight:25}}>
                        <Radio
                            options={options}
                            value={selected}
                            onChangeValue={onChangeValue}
                        />
                    </div>
                </div>
            )
        }
        
        return <div style={{paddingTop:12.5, paddingBottom:12.5}}>{options.map(({value, label}) => {
            let isSelected = value === selected;
            return <div onClick={() => onChangeValue(value)} key={value} style={{paddingTop:7.5, paddingBottom:7.5, display:"flex", flexDirection:"row", alignItems:"center"}}>
                <div style={{cursor:"pointer", width:15, height:15, marginRight:15, border:"1px #707070 solid", borderRadius:"50%", display:"flex", alignItems:"center", justifyContent:"center"}}>
                    {isSelected && <div style={{borderRadius:"50%", height:7, width:7, backgroundColor:"#7500e5"}}/>}
                </div>
                <div style={{fontSize:14, color:"#8d8d8d"}}>{label}</div>
            </div>
        })}</div>
    }
}

export default Radio;