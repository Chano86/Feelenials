import React from 'react';
import { withTracker } from 'meteor/react-meteor-data';

import enableNotifications from './push';
import Analytics from '/imports/api/Analytics';
import { GenericTimeSeriesChart } from './WorldEmotion';

class Admin extends React.Component {
    
    deleteUser = () => {
        let username = document.getElementById("deleteUserUsername").value;
        
        Meteor.call("deleteUser", {username}, err => {
            if(err) {
                alert(err.reason);
            }
            else {
                document.getElementById("deleteUserUsername").value = "";
                alert("Success");
            }
        });
    }
    
    addAdmin = () => {
        let username = document.getElementById("addAdminUsername").value;
        
        Meteor.call("addAdmin", username, err => {
            if(err) {
                alert(err.reason);
            }
            else {
                document.getElementById("addAdminUsername").value = "";
                alert("Success");
            }
        });        
    }
    
    testNotf = () => {
        Meteor.call("testNotf", err => {
            if(err) {
                alert(err.reason);
            }
        });
    }
    
    enableNotf = () => {
        enableNotifications(true).then((a) => {
            alert("Success!");
            this.testNotf();
        }).catch(e => {
            console.error(e);
            alert(e.message);
        });
    }
    
    render() {
        return (
            <div style={{padding:20}}>
                <button onClick={this.enableNotf}>Enable Notifications</button>
                <button onClick={this.testNotf}>Send me a test notification</button>
                <div>
                    <h2>Delete User</h2>
                    <input id="deleteUserUsername" placeholder="Username"/>
                    <button onClick={this.deleteUser}>Submit</button>
                </div>
                <div>
                    <h2>Add Admin</h2>
                    <input id="addAdminUsername" placeholder="Username"/>
                    <button onClick={this.addAdmin}>Submit</button>
                </div>  
                <div>
                    <h2>Total Users: {this.props.totalUsers}</h2>
                    <GenericTimeSeriesChart height={400} title="New Users" data={this.props.userGrowthAnalytics.map(({value, date}) => ({x:date.valueOf(), y:value}))}/>
                    <GenericTimeSeriesChart height={400} title="Recurring Users" data={this.props.activeUsersAnalytics.map(({value, date}) => ({x:date.valueOf(), y:value}))}/>
                    <GenericTimeSeriesChart height={400} title="Visits" series={[
                        {name:"Total Visists", data:this.props.visitsAnalytics.map(({value, date}) => ({x:date.valueOf(), y:value}))},
                        {name:"Logged In Visits", data:this.props.userVisitsByDay.map(({value, date}) => ({x:date.valueOf(), y:value}))}
                    ]}/>
                </div>
            </div>
        );
    }
}

export default withTracker(() => {
    Meteor.subscribe("analytics:admin");
    let userGrowthAnalytics = Analytics.find({type:"usersGainedForDay"}, {sort:{date:1}}).fetch();
    let activeUsersAnalytics = Analytics.find({type:"activeUsersByDay"}, {sort:{date:1}}).fetch();
    
    activeUsersAnalytics.map(a => {
        let match = userGrowthAnalytics.find(m => m.day === a.day);
        let gainedUsers = (match || {value:0}).value;
        a.value = a.value - gainedUsers;
        return a;
    });
    
    let visitsAnalytics = Analytics.find({type:"visitsByDay"}, {sort:{date:1}}).fetch();
    let userVisitsByDay = Analytics.find({type:"userVisitsByDay"}, {sort:{date:1}}).fetch();
    
    let totalUsers = Analytics.findOne({type:"totalUsers"});
    
    return {userVisitsByDay, activeUsersAnalytics, visitsAnalytics, userGrowthAnalytics, totalUsers:(totalUsers ? totalUsers.value : "Loading...")};
})(Admin);