import React, { Component } from 'react';
import { withTracker } from 'meteor/react-meteor-data';
import moment from 'moment';
import ReactApexChart from "react-apexcharts";
import ApexCharts from 'apexcharts';


import EmotionalData from '/imports/api/EmotionalData';
import Analytics from '/imports/api/Analytics';
import WorldEmotion from './WorldEmotion';
import occupations, {_fixTranslation} from '/imports/api/occupations.js';
import Header from '/imports/ui/Header.jsx';
import Footer from '/imports/ui/Footer.jsx';

const {EMOTION_META, ALLOWED_EMOTIONS} = Meteor.settings.public;

class Info extends React.Component {
    constructor(props) {
         super(props);

        this.initDate = new Date();
        
        let series = [];
        
        Object.keys(EMOTION_META).forEach(e => {
            series.push({name:EMOTION_META[e].title, data:[]});
        });
        
        
          this.state = {
            series,
            options: {
              chart: {
                id: 'realtime',
                height: 350,
                type: 'line',
                animations: {
                  enabled: true,
                  easing: 'linear',
                  dynamicAnimation: {
                    speed:1000
                  }
                },
                toolbar: {
                  show: false
                },
                zoom: {
                  enabled: false
                }
              },
              dataLabels: {
                enabled: false
              },
              stroke: {
                curve: 'smooth'
              },
              title: {
                  text:"Real-Time Emotions",
                  align:"center",
                  offsetY:10,
                  style: {
                      fontSize:"20px"
                  }
              },
              markers: {
                size: 0
              },
              xaxis: {
                type: 'datetime',
                range:60*1000
              },
              yaxis: {
                categories:Object.values(EMOTION_META).map(e => e.title),
              },
              legend: {
                show:true
              },
            },
          
          
          };
        }

      
    componentDidUpdate() {
        let {series} = this.state;
        ApexCharts.exec('realtime', 'updateSeries', series);
    }
    
    componentDidMount() {
        window.setInterval(() => {
          let {series} = this.state;
          
          let tick = moment().startOf("second");
          let tickEnd = tick.clone().endOf("second");
          Object.keys(EMOTION_META).forEach((e, index) => {
              series[index].data.push({
                  x:tick.valueOf(),
                  y:this.props.liveData.filter(d => (
                      d.emotion === e &&
                      d.date >= tick.valueOf() &&
                      d.date <= tickEnd.valueOf()
                  )).length
              });
              series[index].data = series[index].data.slice(-60);
          });          
          
          this.setState({date:new Date(), series});
        }, 1000);
    }
      

        render() {
          return (
            <div id="chart">
                <ReactApexChart options={this.state.options} series={this.state.series} type="line" height={350} />
            </div>
        );
    }
}


export default withTracker(() => {
  let liveHandle = Meteor.subscribe("liveData");
  let liveData = EmotionalData.find({}, {sort:{date:-1}}).fetch();
  
  return {
    liveData,
    data:[],
    loading:(!liveHandle.ready())
  };
})(Info);
