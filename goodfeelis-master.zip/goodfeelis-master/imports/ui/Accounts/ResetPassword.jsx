import React from 'react';

import { Meteor } from 'meteor/meteor';
import { Accounts } from 'meteor/accounts-base';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faSync, faUser, faKey } from '@fortawesome/free-solid-svg-icons';
import SQs from 'meteor/ndev:security-questions';

import PhoneView from '../FlatUI/PhoneView';

import { LoggingInHold } from '../App.jsx';

import t from '../t.js';

class Login extends React.Component {
    
    state = {loading:false};
    
    skip = evt => {
        evt.preventDefault();
        this.props.onSkip();
    }
    
    register = evt => {
        evt.preventDefault();
        window.location.href = "/register";
    }
    
    submit = evt => {
        evt.preventDefault();
        
        let username = document.getElementById("username").value;
        
        SQs.startResetPassword({username}).then(questions => {
            this.setState({username, questions});
        }).catch(e => {
            alert(e.reason);
        });
    }
    
    submit2 = evt => {
        evt.preventDefault();
        
        let {username} = this.state;
        
        let answers = [
            document.getElementById("answer1").value,
            document.getElementById("answer2").value,
        ];
        
        SQs.validateAnswers({username}, answers).then(token => {
            this.setState({resetToken:token});
        }).catch(e => {
            alert(e.reason);
        });
    }
    
    submit3 = evt => {
        evt.preventDefault();
        
        let {resetToken} = this.state;
        
        let newPassword = document.getElementById("newPassword").value;
        let confPassword = document.getElementById("confPassword").value;
        
        if(newPassword !== confPassword) {
            return alert("Your passwords do not match");
        }
        
        SQs.resetPassword(resetToken, newPassword).then(() => {
            Meteor.loginWithPassword(this.state.username, newPassword, err => {
                if(err) {
                    alert(err.reason);
                }
                else {
                    window.location.href = "/";
                }
            });
        }).catch(e => {
            alert(e.reason);
        });
    }
    
    render() {
        let {username, resetToken, questions} = this.state;
        
        if(resetToken) {
            return <PhoneView>
                <div className="V2Header">
                    <div className="V2HeaderText">
                        {t("Reset Password")}
                    </div>
                </div>
                <div className="V2Content">
                    <div className="V2Title">
                        {t("Almost Done...")}
                    </div>
                    
                    <div style={{fontSize:16, color:"#242424", paddingBottom:5}}>{t("Enter a new password...")}</div>
                    <div className="V2Input">
                        <FontAwesomeIcon icon={faKey} className="V2InputIcon"/>
                        <input type="password" id="newPassword" className="V2InputElement"/>
                    </div>
                    
                    <div style={{height:20}}/>
                    
                    <div style={{fontSize:16, color:"#242424", paddingBottom:5}}>{t("Enter your new password again...")}</div>
                    <div className="V2Input">
                        <FontAwesomeIcon icon={faKey} className="V2InputIcon"/>
                        <input type="password" id="confPassword" className="V2InputElement"/>
                    </div>
                    
                    <div style={{height:20}}/>
                    
                    {this.state.loading ?
                        <FontAwesomeIcon icon={faSync} spin/>
                    :
                        <button onClick={this.submit3} className="V2Button">{t("Continue")}</button>
                    }
                </div>
            </PhoneView>;              
        }
        
        if(questions) {
            return <PhoneView>
                <div className="V2Header">
                    <div className="V2HeaderText">
                        {t("Reset Password")}
                    </div>
                </div>
                <div className="V2Content">
                    <div className="V2Title">
                        {t("Hi")}, {username}
                    </div>
                    <div style={{fontSize:18, color:"#242424", paddingBottom:5}}>{t("Please answer your security questions to reset your password")}</div>
                    <div style={{height:10}}/>
                    
                    <div style={{fontSize:16, color:"#242424", paddingBottom:5}}>{questions[0]}</div>
                    <div className="V2Input">
                        <FontAwesomeIcon icon={faUser} className="V2InputIcon"/>
                        <input type="text" id="answer1" placeholder={t("Enter your answer...")} className="V2InputElement"/>
                    </div>
                    
                    <div style={{height:20}}/>
                    
                    <div style={{fontSize:16, color:"#242424", paddingBottom:5}}>{questions[1]}</div>
                    <div className="V2Input">
                        <FontAwesomeIcon icon={faUser} className="V2InputIcon"/>
                        <input type="text" id="answer2" placeholder={t("Enter your answer...")} className="V2InputElement"/>
                    </div>
                    
                    <div style={{height:20}}/>
                    
                    {this.state.loading ?
                        <FontAwesomeIcon icon={faSync} spin/>
                    :
                        <button onClick={this.submit2} className="V2Button">{t("Continue")}</button>
                    }
                </div>
            </PhoneView>;            
        }
        
        return <PhoneView>
            <div className="V2Header">
                <div className="V2HeaderText">
                    {t("Reset Password")}
                </div>
            </div>
            <div className="V2Content">
                <div className="V2Title">
                    {t("Reset your password").split(" ").slice(0, 2).join(" ")}<br/>
                    {t("Reset your password").split(" ").slice(2).join(" ")}
                </div>
                <div className="V2Input">
                    <FontAwesomeIcon icon={faUser} className="V2InputIcon"/>
                    <input type="text" id="username" placeholder={t("Enter your username...")} className="V2InputElement"/>
                </div>
                <div style={{height:20}}/>
                
                {this.state.loading ?
                    <FontAwesomeIcon icon={faSync} spin/>
                :
                    <button onClick={this.submit} className="V2Button">{t("Continue")}</button>
                }
            </div>
        </PhoneView>;
    }
    
}

export default Login;