import React from 'react';

import { Meteor } from 'meteor/meteor';
import { Accounts } from 'meteor/accounts-base';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faSync, faUser, faLock } from '@fortawesome/free-solid-svg-icons';

import SwitchLanguageButton from '../SwitchLanguageButton';
import PhoneView from '../FlatUI/PhoneView';

import { LoggingInHold } from '../App.jsx';

import t from '../t.js';

class Login extends React.Component {
    
    state = {loading:false};
    
    skip = evt => {
        evt.preventDefault();
        this.props.onSkip();
    }
    
    register = evt => {
        evt.preventDefault();
        window.location.href = "/register";
    }
    
    submit = evt => {
        evt.preventDefault();
        
        let username = document.getElementById("username").value;
        let password = document.getElementById("password").value;
        
        LoggingInHold.set(true);
        this.setState({loading:true});
        Meteor.loginWithPassword(username, password, err => {
            this.setState({loading:false});
            LoggingInHold.set(false);
            if(err) {
                alert(t(err.reason));
            }
            else {
                if(window.location.pathname === "/login") {
                    window.location.href = "/";
                }
            }
        });
    }
    
    render() {
        
        return <PhoneView>
            <div className="V2Header">
                {/*TODO Caret*/}
                <div className="V2HeaderText">
                    {t("Sign In")}
                </div>
            </div>
            <div className="V2Content">
                <div className="V2Title">
                    {t("Sign in to your account").split(" ").slice(0, 3).join(" ")}<br/>
                    {t("Sign in to your account").split(" ").slice(3).join(" ")}
                </div>
{/*                <div className="V2Subtitle">
                    Enter your personal details and start your journey today
                </div>*/}
                <div className="V2Input">
                    <FontAwesomeIcon icon={faUser} className="V2InputIcon"/>
                    <input type="text" id="username" placeholder={t("Enter a username...")} className="V2InputElement"/>
                </div>
                <div style={{height:40}}/>
                <div className="V2Input">
                    <FontAwesomeIcon icon={faLock} className="V2InputIcon"/>
                    <input autoComplete="new-password" type="password" id="password" placeholder={t("Enter a password...")} className="V2InputElement"/>
                </div>
                <div style={{height:20}}/>
                
                {this.state.loading ?
                    <FontAwesomeIcon icon={faSync} spin/>
                :
                    <button onClick={this.submit} className="V2Button">{t("Continue")}</button>
                }
                
                <div style={{height:60}}/>
                
                <div className="V2Subtitle" style={{textAlign:"center", maxWidth:"100%"}}>
                    {t("Don't have an account?")} <a href="/register">{t("Register")}</a><br/>
                    - {t("or")} -<br/>
                    {t("Forgot your password?")} <a href="/reset-password">{t("Reset it now!")}</a><br/>
                    - {t("or")} -<br/>
                    <a href="#skip" onClick={this.skip}>{t("Continue without account")}</a>
                </div>
                
                <SwitchLanguageButton/>
            </div>
        </PhoneView>;
    }
    
}

// <div>
//     <div onClick={this.register} className="SplashLink">{t("Register")}</div>
//     &nbsp;&nbsp;&nbsp;
//     <div  className="SplashLink">{t("Continue without account")}</div>
// </div>

export default Login;