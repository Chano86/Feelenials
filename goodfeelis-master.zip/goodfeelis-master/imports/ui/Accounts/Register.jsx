import React from 'react';

import { Meteor } from 'meteor/meteor';
import { Accounts } from 'meteor/accounts-base';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faUser, faLock } from '@fortawesome/free-solid-svg-icons';
import { withTracker } from 'meteor/react-meteor-data';

import ResearchCampaigns from '/imports/api/ResearchCampaigns';
import SwitchLanguageButton from '../SwitchLanguageButton';
import PhoneView from '../FlatUI/PhoneView';
import t from '../t';

import { LoggingInHold } from '../App.jsx';

const {REGISTER_NOTICE} = Meteor.settings.public;

class Register extends React.Component {
    
    state = {};
    
    approveCampaign = () => {
        if(this.props.currentUser) {
            Meteor.call("joinCampaignWithCode", this.props.code, err => {
                if(err) {
                    alert(err.reason);
                }
                else {
                    this.props.history.push("/");
                }
            });
        }
        else {
            this.setState({campaignConfirmed:true});
        }
    }
    
    submit = () => {
        let demographicData = null;
        
        let username = document.getElementById("username").value;
        let password = document.getElementById("password").value;
        
        if(username.length < 1) {
            return alert(t("Please make your username at least 1 character long"));
        }
        
        if(password.length < 8) {
            return alert(t("Please make your password at least 8 characters long"));
        }
        
        try {
            if(!demographicData) {
                demographicData = JSON.parse(window.localStorage.getItem("demographicData"));
            }
        }
        catch(e) {
            demographicData = null;
        }
        
        LoggingInHold.set(true);
        
        Accounts.createUser({username, password, demographicData, campaignRegistrationCode:this.props.code || undefined}, err => {
            LoggingInHold.set(false);
            if(err) {
                alert(t(err.reason));
            }
            else {
                window.location.href = "/";
            }
        });
    }
    
    render() {
        let { code, campaignInfo, campaignLoading } = this.props;
        
        
        if(!this.state.campaignConfirmed && code) {
            if(!campaignInfo) {
                if(campaignLoading) {
                    return <h2>Loading...</h2>;
                }
                else {
                    return <h2>The link you are using is invalid. There may be a typo in the link.</h2>;
                }
            }

            console.log(campaignInfo);
            
            return <PhoneView>
                <div style={{display:"flex", alignItems:"center", justifyContent:"center", height:"100%", width:"100%"}}>
                    <div style={{padding:40}}>
                        <div className="V2Title">
                            {t("Join #NAME on GoodFeelis").replace(/#NAME/, campaignInfo.name)}
                        </div>

                        <div style={{fontSize:18}}>
                            {campaignInfo.description}
                        </div>
                        
                        <div style={{height:20}}/>
                        
                        <div style={{fontSize:18}}>
                            {t("Your emotions will be anonymously shared with #NAME").replace(/#NAME/, campaignInfo.name)}
                        </div>
                        
                        <div style={{height:40}}/>
                        
                        <button onClick={this.approveCampaign} className="V2Button">{this.props.currentUser ? t("Join Campaign") : t("Create account")}</button>

                        {!this.props.currentUser && <React.Fragment>
                            <div style={{height:40}}/>
                            
                            <div className="V2Subtitle" style={{textAlign:"center", maxWidth:"100%"}}>{t("Already have an account?")}<a href={"/login/" + campaignInfo.registrationCode}>{t("Sign in")}</a></div>
                            
                            <SwitchLanguageButton/>
                        </React.Fragment>}
                    </div>
                </div>
            </PhoneView>;            
        }
        
        return <PhoneView>
            <div className="V2Header">
                {/*TODO Caret*/}
                <div className="V2HeaderText">
                    {t("Sign Up")}
                </div>
            </div>
            <div className="V2Content">
                <div className="V2Title">
                    {t("Create your account").split(" ").slice(0, 1).join(" ")}<br/>
                    {t("Create your account").split(" ").slice(1).join(" ")}
                </div>
                <div className="V2Subtitle">
                    {t("Sign up and start your journey today")}
                </div>
                <label><b>{t("Stay Anonymous!")}</b> {t("Don't use your real name, or a username you use on other websites")}</label>
                <br/><br/>
                <div className="V2Input">
                    <FontAwesomeIcon icon={faUser} className="V2InputIcon"/>
                    <input type="text" id="username" placeholder={t("Enter a username...")} className="V2InputElement"/>
                </div>
                <div style={{height:40}}/>
                <div className="V2Input">
                    <FontAwesomeIcon icon={faLock} className="V2InputIcon"/>
                    <input autoComplete="new-password" type="password" id="password" placeholder={t("Enter a password...")} className="V2InputElement"/>
                </div>
                <div style={{height:20}}/>
                
                <div className="V2Subtitle">{t(REGISTER_NOTICE)}</div>
                
                <button onClick={this.submit} className="V2Button">{t("Create account")}</button>
                
                <div style={{height:60}}/>
                
                <div className="V2Subtitle" style={{textAlign:"center", maxWidth:"100%"}}>{t("Already have an account?")}<a href="/login">{t("Sign in")}</a></div>
                
                <SwitchLanguageButton/>
            </div>
        </PhoneView>;
    }
    
}

export default withTracker(props => {
    let code, campaignInfo, campaignHandle;
    
    try {
        code = props.match.params.code;
        
        if(code) {
            campaignHandle = Meteor.subscribe("campaignCode", code);
            campaignInfo = ResearchCampaigns.findOne({registrationCode:code.toLowerCase()});
        }
    }
    catch(e) {
        console.error(e);
    }
    
    return {
        code,
        campaignInfo,
        campaignLoading:campaignHandle ? !campaignHandle.ready() : false,
        currentUser:Meteor.user()
    };
    
})(Register);