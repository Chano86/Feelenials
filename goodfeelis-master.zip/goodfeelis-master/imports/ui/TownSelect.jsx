import React from 'react';

import { Meteor } from 'meteor/meteor';
import { Accounts } from 'meteor/accounts-base';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faUser, faCheck } from '@fortawesome/free-solid-svg-icons';

import PhoneView from './FlatUI/PhoneView';
import t from './t';
import occupations from '/imports/api/occupations.js';

import { LoggingInHold } from './App.jsx';

const {REGISTER_NOTICE} = Meteor.settings.public;

class Register extends React.Component {
    
    state = {towns:null, selected:null};
    
    componentDidMount() {
        Meteor.call("getTownList", (err, res) => {
            if(err) {
                // this.onSkip()
            }
            else {
                this.setState({rawTowns:res.towns, towns:res.towns});
            }
        });
    }
    
    onSearch = evt => {
        let {value} = evt.target;
        
        let {rawTowns} = this.state;
        let towns = rawTowns.filter(t => {
            return t.name.toLowerCase().includes(value.toLowerCase());
        });
        this.setState({value, towns});
    }
    
    townMissing = () => {
        Meteor.call("getTownList", this.state.value, (err, res) => {
            if(err) {
                // this.onSkip()
            }
            else {
                this.setState({rawTowns:[...this.state.rawTowns, ...res.towns], towns:[this.state.towns, ...res.towns]});
            }
        });        
    }
    
    submit = () => {
        if(!this.state.selected) {
            return alert("Please select your town");
        }
        
        Meteor.call("setTown", this.state.selected);
    }
    
    render() {
        
        return <PhoneView>
                <div style={{height:"100%", display:"flex", flexDirection:"column"}}>
                    <div style={{padding:20}}>
                        <div className="V2Title">
                            {t("Select your Town")}
                        </div>
                        <div className="V2Subtitle" style={{marginBottom:10}}>
                            {t("This is only collected for the purpose of creating demographic reports")}
                        </div>
                        <div className="V2Input">
                            <input onKeyUp={this.onSearch} placeholder={t("Search...")} type="text" className="V2InputElement"/>
                        </div>
                    </div>
                    <div style={{height:1, flexGrow:1, padding:20, overflow:"auto", paddingTop:0}}>
                        {this.state.towns ?
                            this.state.towns.map(t => <div onClick={() => this.setState({selected:t._id})} style={{cursor:"pointer", color:(this.state.selected === t._id ? "#37fbbb" : undefined), fontSize:17, paddingTop:5, paddingBottom:5}}>
                                {this.state.selected === t._id && <span><FontAwesomeIcon icon={faCheck} style={{color:"#37fbbb"}}/>&nbsp;</span>}
                                {t.name}
                            </div>)
                        : <div>Loading...</div>}
                        
                        <div onClick={this.townMissing} style={{cursor:"pointer", color:"#03a9f4", fontSize:17, paddingTop:5, paddingBottom:5}}>
                            {!this.state.value ?
                                t("If your town is missing, please enter a few letters of the name in the search bar above, then click here")
                            :
                                t("Click here if your town is missing")
                            }
                        </div>
                    </div>
                
                    <div style={{padding:20}}>
                        <div style={{height:10}}/>
                        
                        <button onClick={this.submit} className="V2Button">{t("Continue")}</button>
                    </div>
                </div>
        </PhoneView>;
    }
    
}

export default Register;