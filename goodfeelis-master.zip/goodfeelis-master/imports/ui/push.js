import {language} from './t';

function urlBase64ToUint8Array(base64String) {
  const padding = '='.repeat((4 - base64String.length % 4) % 4);
  const base64 = (base64String + padding)
    .replace(/-/g, '+')
    .replace(/_/g, '/');

  const rawData = window.atob(base64);
  const outputArray = new Uint8Array(rawData.length);

  for (let i = 0; i < rawData.length; ++i) {
    outputArray[i] = rawData.charCodeAt(i);
  }
  return outputArray;
}

const applicationServerKey = urlBase64ToUint8Array(Meteor.settings.public.vapidPublic);
const subscribeOptions = {
  userVisibleOnly: true,
  applicationServerKey
};

let {navigator, Notification} = window;

function askPermission() {
  return new Promise(function(resolve, reject) {
    const permissionResult = Notification.requestPermission(function(result) {
      resolve(result);
    });

    if (permissionResult) {
      permissionResult.then(resolve, reject);
    }
  });
}

let isSubscribed = async function () {
  let registration = await navigator.serviceWorker.register('/service-worker.js');
  let subscription = await registration.pushManager.getSubscription();
  return (subscription !== null ? true : false);
};

let subscribe = async function () {
  if (!('serviceWorker' in navigator)) {
    // Service Worker isn't supported on this browser, disable or hide UI.
    throw new Error("Not Supported");
  }
  
  if (!('PushManager' in window)) {
    // Push isn't supported on this browser, disable or hide UI.
    throw new Error("Not Supported");
  }  
  
  if('Notification' in window) {
    let permissionStatus = await askPermission();
    
    console.log(permissionStatus);
    
    if(permissionStatus !== "granted") {
      throw new Error("Permission Denied");
    }
  }
  
  let registration = await navigator.serviceWorker.register('/sw.js');
  
  let subscription = await registration.pushManager.getSubscription();
  
  if(!subscription) {
    subscription = await registration.pushManager.subscribe(subscribeOptions);
  }

  let stringifiedSubscription = JSON.stringify(subscription);
  
  console.debug("Saving push subscription");
  
  Meteor.call("savePushSub", stringifiedSubscription, language);
};

let has_started_subscribing = false;

let initWebPush = async (force) => {
  if(has_started_subscribing && !force) {
    return;
  }
  has_started_subscribing = true;
  
  await subscribe();
};

export { isSubscribed, subscribe };
export default initWebPush;