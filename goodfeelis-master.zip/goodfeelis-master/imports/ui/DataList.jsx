import React from 'react';
import { withTracker } from 'meteor/react-meteor-data';
import moment from 'moment';

import EmotionalData, { EmotionalDataV2 } from '/imports/api/EmotionalData';
import occupations, {_fixTranslation} from '/imports/api/occupations.js';
import Header from '/imports/ui/Header.jsx';
import Footer from '/imports/ui/Footer.jsx';

const {EMOTION_META, ALLOWED_EMOTIONS} = Meteor.settings.public;

class Info extends React.Component {
  state = {
    date:new Date()
  }
  
  componentDidMount() {
    this.interval = setInterval(() => {
      this.setState({date:new Date()});
    }, 5000);
  }
  
  componentWillUnmount() {
    clearInterval(this.interval);
  }
  
  render() {
    let { listData, loading } = this.props;
    
    if(loading) {
      return <div style={{height:"100%"}}>
        <Header {...this.props} showCapture={true}/>
        <div className="UploadContainer">
          <div className="UploadCard">
            <div style={{padding:10, textAlign:"center"}}>
              <img src="/loader.gif" className="UploaderLoader"/>
              <h3 style={{fontWeight:"normal"}}>Loading the world report...</h3>
            </div>
          </div>
        </div>
        <Footer/>
      </div>;
    }
    
    return (
      <div>
        <div className="FooterReadyContainer">
          <div>
            <table>
              <tr>
                <th>Time</th>
                <th>Value</th>
                <th>Smiling</th>
                <th>Gender</th>
                <th>Age</th>
                <th>Occupation</th>
                <th>Country</th>
                <th>Activity</th>
                <th>Symptom</th>
                <th>Source</th>
                <th>Location</th>
              </tr>
              {listData.map(d => {
                let fromNow = moment(d.date).from(this.state.date);
                return (
                  <tr>
                    <td>{fromNow === "in a few seconds" ? "just now" : fromNow}</td>
                    <td>{JSON.stringify(d.value)}</td>
                    <td>{d.smiling ? "Yes" : "No"}</td>
                    <td>{d.meta.gender}</td>
                    <td>{d.meta.age}</td>
                    <td>{d.meta.occupation}</td>
                    <td>{!d.meta.location.country ? "Unknown" : d.meta.location.country}</td>
                    <td>{d.meta && d.meta.symptom}</td>
                    <td>{d.meta && d.meta.activity}</td>
                    <td>{d.sourceName}</td>
                    <td>{d.meta.city}, {d.meta.state}</td>
                  </tr>
                );
              })}
            </table>
          </div>
        </div>
        <Footer/>
      </div>
    );
  }
}

export default withTracker(() => {
  let listHandle = Meteor.subscribe("listData");
  
  return {
    listData:EmotionalDataV2.find({}, {sort:{date:-1, limit:100}}).fetch(),
    loading:!listHandle.ready()
  };
})(Info);
