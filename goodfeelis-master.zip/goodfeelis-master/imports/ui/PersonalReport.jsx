import React from 'react';
import { withTracker } from 'meteor/react-meteor-data';
import Chart from "react-apexcharts";
import { ReactiveVar } from 'meteor/reactive-var';
import moment from 'moment';

import { EmotionalDataV2 } from '/imports/api/EmotionalData';
import PhoneView from './FlatUI/PhoneView';
import { ReportHeader } from './Report';
import t from './t';

let ReportView = new ReactiveVar("day");
const {EMOTION_META} = Meteor.settings.public;

let PIE_OPTIONS = {
    labels:Object.values(EMOTION_META).map(e => e.title),
    legend: {
        show:false
    },
    dataLabels: {
        enabled:false
    },
};

const LINE_CHART_OPTIONS = {
    chart: {
        type:"line",
        toolbar:{
            show:false
        }
    },
    animations: {
        enabled: true,
        easing: 'linear',
        dynamicAnimation: {
          speed: 1000
        }
    },                    
    stroke: {
        curve: 'smooth'
    },
    xaxis: {
        // type:"datetime",
        // labels: {
        //     hideOverlappingLabels:false,
        //     showDuplicates:true,
        //     show:true,
        //     datetimeFormatter: {
        //         day:"ddd"
        //     }
        // }
    },
    grid: {
        padding: {
            right:20,
            left:20
        }
    }
};

let days = [];
let day = moment().subtract(8, "days").startOf("day");
for(let i=0;i<9;i++) {
    days.push(day.toDate());
    day.add(1, "day");
}
console.log(days);

class PersonalReport extends React.Component {
    render() {
        let {myEmotionalData, currentUser, reportView} = this.props;
        
        let primaryActivity, primaryActivityPercent, primaryFeeling, primaryFeelingPercent, series=[];
        if(currentUser) {
            let activities = {}, feelings = {}, total = 0;
            
            myEmotionalData.forEach(({meta, value}) => {
                activities[meta.activity] = activities[meta.activity] || 0;
                activities[meta.activity]++;
                feelings[value.feeling] = feelings[value.feeling] || 0;
                feelings[value.feeling]++;
                total++
            });
            
            primaryActivity = Object.keys(activities).sort((a,b) => activities[b] - activities[a])[0];
            primaryActivityPercent = activities[primaryActivity] / total;
    
            primaryFeeling = Object.keys(feelings).sort((a,b) => feelings[b] - feelings[a])[0];
            primaryFeelingPercent = feelings[primaryFeeling] / total;
            
            if(reportView === "day") {
                series = Object.keys(EMOTION_META).map(key => {
                    return myEmotionalData.filter(d => d.value.emotion === key).length;
                });
            }
            else {
                Object.keys(EMOTION_META).forEach(emotion => {
                    series.push({
                        name:t(EMOTION_META[emotion].title),
                        data:days.map(date => ({x:t(moment(date).format("ddd")), y:myEmotionalData.filter(d => (d.value.emotion === emotion && d.date >= date && d.date <= moment(date).endOf("day").toDate())).length}))
                    });
                });
            }
        }
        else {
            primaryFeeling = "Worry";
            primaryFeelingPercent = 0.75;
            
            primaryActivity = "Working from home";
            primaryActivityPercent = 0.25;
            
            series = [10, 20, 30, 40, 50];
        }
        
        return (
            <PhoneView>
                <ReportHeader active="personal"/>
                {!currentUser && <div style={{position:"absolute", top:0, left:0, backgroundColor:"rgba(255,255,255,0.75)", marginTop:85, height:"calc(100% - 50px - 85px)", width:"100%", zIndex:2, marginBottom:50, display:"flex", justifyContent:"center", alignItems:"center"}}>
                    <div style={{maxWidth:400, textAlign:"center"}}>
                        <div>{t("You are using GoodFeelis without an account. Create an account to use the Personal Report.")}</div>
                        <br/>
                        <button onClick={() => {window.sessionStorage.clear();window.location.reload()}} className={" EmotionPadSaveButton "}>Create Account</button>
                    </div>
                </div>}
                <div style={{paddingTop:25, paddingBottom:25, gap:20, display:"flex", justifyContent:"center", flexDirection:"row"}}>
                    <div onClick={() => ReportView.set("day")} style={{marginLeft:10, marginRight:10, fontWeight:"bold", fontSize:10, lineHeight:"18px", textAlign:"center", color:reportView === "day" ? "white" : "#8d8d8d", width:80, height:18, backgroundColor:reportView === "day" ? "#27005b" : "#f7f7f7", borderRadius:9}}>
                      {t("Day")}
                    </div>
                    <div onClick={() => ReportView.set("week")} style={{marginLeft:10, marginRight:10, fontWeight:"bold", fontSize:10, lineHeight:"18px", textAlign:"center", color:reportView === "week" ? "white" : "#8d8d8d", width:80, height:18, backgroundColor:reportView === "week" ? "#27005b" : "#f7f7f7", borderRadius:9}}>
                      {t("Week")}
                    </div>
                    {/*<div style={{marginLeft:10, marginRight:10, fontWeight:"bold", fontSize:10, lineHeight:"18px", textAlign:"center", color:"#8d8d8d", width:80, height:18, backgroundColor:"#f7f7f7", borderRadius:9}}>
                      Month
                    </div>*/}
                </div>
                {reportView === "day" ?
                    <div style={{display:"flex", flexDirection:"row", justifyContent:"center", alignItems:"stretch"}}>
                        <div style={{flexGrow:1, paddingLeft:30}}>
                            <Chart style={{width:"100%", height:"100%"}} options={PIE_OPTIONS} series={series} type="donut" width="100%"/>
                        </div>
                        <div style={{paddingTop:20, paddingBottom:20, width:120, display:"flex", flexDirection:"column", justifyContent:"space-evenly"}}>
                          {Object.values(EMOTION_META).map(({title, color}) => <div className="LegendItem" style={{display:"inline-block"}} key={title}>
                            <div className="LegendCircle" style={{backgroundColor:color}}/>
                            <div className="LegendLabel">{t(title)}</div>
                          </div>)}
                        </div>                    
                    </div>
                :
                    <div>
                        <Chart options={LINE_CHART_OPTIONS} series={series} type="line"/>
                    </div>
                }
                <div style={{display:"flex", flexDirection:"row", justifyContent:"center", paddingTop:15}}>
                    <div style={{width:"50%", paddingRight:5, paddingLeft:24}}>
                        <div style={{paddingBottom:5, color:"#8d8d8d", fontSize:10, textAlign:"center"}}>{t("Feeling")}</div>
                        <div className="ReportHalfRect">
                        {primaryActivity ?
                            <div>
                                <div style={{fontWeight:"bold", fontSize:16, lineHeight:"18px"}}>{Math.trunc(primaryFeelingPercent*100)}%</div>
                                <div style={{height:6}}/>
                                <div style={{fontSize:12, lineHeight:"12px", textTransform:"capitalize"}}>{t(primaryFeeling)}</div>
                            </div>
                        :
                            <div>{t("No Data")}</div>
                        }
                        </div>
                    </div> 
                    <div style={{width:"50%", paddingLeft:5, paddingRight:24}}>
                        <div style={{paddingBottom:5, color:"#8d8d8d", fontSize:10, textAlign:"center"}}>{t("Activity")}</div>
                        <div className="ReportHalfRect">
                        {primaryActivity ?
                            <div>
                                <div style={{fontWeight:"bold", fontSize:16, lineHeight:"18px"}}>{Math.trunc(primaryActivityPercent*100)}%</div>
                                <div style={{height:6}}/>
                                <div style={{fontSize:12, lineHeight:"12px"}}>{t(primaryActivity)}</div>
                            </div>
                        :
                            <div>{t("No Data")}</div>
                        }
                        </div>
                    </div> 
                </div>                
            </PhoneView>
        );
    }
}

export default withTracker(() => {
    let reportView = ReportView.get();
    
    let handle = Meteor.subscribe("myEmotionSubmissions");
    let myEmotionalData = EmotionalDataV2.find({}).fetch();
    
    return {
        currentUser:Meteor.user(),
        myEmotionalData,
        loading:!handle.ready(),
        reportView
    };
})(PersonalReport);