import React from 'react';

import t from './t';

const DOT_SIZE = 40;

const colors = {
    happy:"#4caf50",
    angry:"#f44336",
    sad:"#2196f3",
    surprised:"#ffeb3b"
};

class EmoPad extends React.Component {
    
    state = {
        lastEmotionPadSend:window.localStorage.getItem("lastEmotionPadSend") ? Number(window.localStorage.getItem("lastEmotionPadSend")) : -1,
        currentTime:new Date().valueOf(),
        dragging:false, clientX:0, clientY:0, emotions:{happy:0, sad:0, angry:0, surprised:0}
    }
    
    savePad = (value) => {
        let demographicData = JSON.parse(window.localStorage.getItem("demographicData"));
        
        Meteor.call("input:pad", {value, demographicData}, err => {
            if(err) {
                if(err.error === "too-many-requests") {
                    alert(t("You just sent an emotion, you can send another one in a few minutes"));
                }
                else {
                    alert(t(err.reason));
                }
            }
            else {
                window.localStorage.setItem("lastEmotionPadSend", new Date().valueOf());
                this.props.onSave();
            }
        });
    }
  
    componentDidMount() {
        let bounds = this.getBounds();
        
        this.setState({
            clientX:bounds.left.min + ((bounds.left.max - bounds.left.min)/2) - 2,
            clientY:bounds.top.min + ((bounds.top.max - bounds.top.min)/2) - 2
        });
        
        document.addEventListener("dragover", function(event) {
          event.preventDefault();
        });
        
        this.interval = window.setInterval(() => {
            this.setState({currentTime:new Date().valueOf()});
        }, 1500);
    }
    
    componentWillUnmount() {
        clearInterval(this.interval);
    }
    
    getBounds = () => {
        let padElement = document.getElementById("EmoPad");
        let bounds = {
            left: {
                min:padElement.offsetLeft,
                max:(padElement.offsetLeft + padElement.clientWidth) - 22
            },            
            top: {
                min:padElement.offsetTop,
                max:(padElement.offsetTop + padElement.clientHeight) - 22
            },
        }
        
        return bounds;
    }
    
    onTouchMove = evt => {
        if(!evt) {
            return;
        }
        
        let bounds = this.getBounds();
        
        let { clientX, clientY } = evt.hasOwnProperty("clientX") ? evt : evt.nativeEvent.touches[0];
        clientX = clientX - 10;
        clientY = clientY - 10;
        
        if(clientX <= bounds.left.min) {
            clientX = bounds.left.min;
        }
        if(clientX >= bounds.left.max) {
            clientX = bounds.left.max;
        }
        if(clientY <= bounds.top.min) {
            clientY = bounds.top.min;
        }
        if(clientY >= bounds.top.max) {
            clientY = bounds.top.max;
        }        
        
        
        
        
        let xCenter = bounds.left.min + ((bounds.left.max - bounds.left.min)/2);
        let yCenter = bounds.top.min + ((bounds.top.max - bounds.top.min)/2);
        
        let x = (clientX) - xCenter;
        let y = (clientY) - yCenter;
        
        // clientX = bounds.left.min + ((bounds.left.max - bounds.left.min)*(Math.abs(y)/114))
        // clientX = clientX*0.1;
        
        let happy = Math.max(0, Math.trunc(((x*-1) + (y*-1)) / 2) / 114);
        let sad = Math.max(0, Math.trunc(((x*-1) + (y)) / 2) / 114);
        let angry = Math.max(0, Math.trunc(((x) + (y*-1)) / 2) / 114);
        let surprised = Math.max(0, Math.trunc(((x) + (y)) / 2) / 114);
        
        let color = "#eee";
        if(happy >= 0.5) {
            color = colors.happy;
        }
        if(sad >= 0.5) {
            color = colors.sad;
        }
        if(angry >= 0.5) {
            color = colors.angry;
        }
        if(surprised >= 0.5) {
            color = colors.surprised;
        }
        
        this.setState({emotions:{happy, sad, angry, surprised}, color, x, y, clientX, clientY});
    }
    
    save = () => {
        let {emotions} = this.state;
        
        let total = emotions.happy + emotions.sad + emotions.angry + emotions.surprised;
        
        let value = [
            {Type:"HAPPY", Confidence:(emotions.happy/total)*100},
            {Type:"SAD", Confidence:(emotions.sad/total)*100},
            {Type:"ANGRY", Confidence:(emotions.angry/total)*100},
            {Type:"SURPRISED", Confidence:(emotions.surprised/total)*100},
        ];
        
        this.savePad(value);
    }
    
    onDrag = evt => {
        this.onTouchMove(evt);
    }
    
    onDragStart = () => {
        this.setState({dragging:true});
    }
    
    onDragEnd = evt => {
        this.onTouchMove(evt);
        this.setState({dragging:false});
    }   
    
    onDragOver = evt => {
        evt.preventDefault();
    }
    
    render() {
        let { lastEmotionPadSend, currentTime, emotions, color, x, y, clientX, clientY } = this.state;
        let cannotSend = lastEmotionPadSend >= (currentTime-31000);
        
        return (
            <div>
                <div id="EmoPad" className="EmoPad" style={{boxShadow:`
                    ${colors.happy} -20px -20px 10px ${(emotions.happy * 20)-DOT_SIZE}px,
                    ${colors.sad} -20px 20px 10px ${(emotions.sad * 20)-DOT_SIZE}px,
                    ${colors.angry} 20px -20px 10px ${(emotions.angry * 20)-DOT_SIZE}px,
                    ${colors.surprised} 20px 20px 10px ${(emotions.surprised * 20)-DOT_SIZE}px
                `}} onDragOver={this.onDragOver}>
                    <div onDragStart={this.onDragStart} onDragEnd={this.onDragEnd} style={{boxShadow:(this.state.dragging ? "none" : undefined), zIndex:2, top:clientY, left:clientX, cursor:"move"}} draggable="true" onTouchMove={this.onTouchMove} className="EmoPadButton"/>
                    <div style={{zIndex:1, width:"100%", height:"100%"}}>
                        <div style={{width:"100%", height:"100%", position:"relative"}}>
                            {cannotSend ?
                                <div style={{flexDirection:"column", display:"flex", alignItems:"center", justifyContent:"center", position:"absolute", width:"100%", height:"100%", zIndex:5, backgroundColor:"rgba(255,255,255,0.75)"}}>
                                    <div style={{fontSize:25}}>You just sent an emotion</div>
                                    <div style={{fontSize:15}}>You can send another one in a few minutes</div>
                                </div>
                            : null}
                            <div style={{top:10, left:10, position:"absolute"}}>{t("Happy")}</div>
                            <div style={{top:10, right:10, position:"absolute"}}>{t("Angry")}</div>
                            <div style={{bottom:10, right:10, position:"absolute"}}>{t("Surprised")}</div>
                            <div style={{bottom:10, left:10, position:"absolute"}}>{t("Sad")}</div>
                        </div>
                    </div>
                </div>
                <br/><br/>
                <div>
                  <div style={{maxWidth:450, width:"100%", display:"inline-block"}}>
                    <div onClick={this.save} style={{display:"inline-block", width:"50%", verticalAlign:"top"}}>
                      <div style={{padding:10}}>
                        <div style={{paddingTop:5, paddingBottom:5, boxShadow:"0px 0px 20px -5px rgba(0,0,0,0.5)", borderRadius:25,  cursor:"pointer", display:"flex", alignItems:"center", justifyContent:"center", fontSize:20}}>
                          Save Emotion
                        </div>
                      </div>
                    </div>
                  </div>
                </div>             
            </div>
        );
    }
}

export default EmoPad;