const OFFLINE_VERSION = 1;
const CACHE_NAME = "offline";
const OFFLINE_URL = 'offline.html';

self.addEventListener("push", event => {
    let data = event.data.json();
    self.registration.showNotification(data.title, {body:data.body});
});

self.addEventListener('notificationclick', function(event) {
  event.notification.close();
  event.waitUntil(self.clients.openWindow('/'));
});

self.addEventListener("install", event => {
  event.waitUntil((async () => {
    const cache = await caches.open(CACHE_NAME);
    await cache.add(new Request(OFFLINE_URL, {cache:'reload'}));
  })());
});

self.addEventListener("active", event => {
  event.waitUntil((async () => {
    if('navigationPreload' in self.registration) {
      await self.registration.navigationPreload.enable();
    }
  })());
  self.clients.claim();
});

self.addEventListener('fetch', event => {
  if(event.request.mode === "navigate") {
    event.respondWith((async () => {
      try {
        const networkResponse = await fetch(event.request);
        return networkResponse;
      }
      catch (e) {
        const cache = await caches.open(CACHE_NAME);
        const cachedResponse = await cache.match(OFFLINE_URL);
        return cachedResponse;
      }
    })());
  }
});